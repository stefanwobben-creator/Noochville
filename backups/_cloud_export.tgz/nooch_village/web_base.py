"""Basis web-chrome + HTML-escaping — de gedeelde bouwstenen voor álle actieve views.

Geëxtraheerd uit de legacy `cockpit.py` (`_e`/`_banner`/`_page` + de basis-chrome `_FONTS`/`_CSS`)
zodat de views hier uit importeren i.p.v. uit de 4018-regel-legacy-module. Puur herordening,
geen gedragswijziging.

BEWUST geen afhankelijkheid op andere nooch_village-modules — alleen stdlib `html` — zodat hier
nooit een circulaire import kan ontstaan (dit is de bodem van de import-graaf).
"""
from __future__ import annotations
import html


def _e(x) -> str:
    return html.escape("" if x is None else str(x))


# ── Nooch design system (tokens uit nooch-shop/assets/design-tokens.css) ──────

_FONTS = (
    '<link rel="preconnect" href="https://fonts.googleapis.com">'
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
    '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?'
    'family=Bricolage+Grotesque:wght@600;800&family=DM+Sans:wght@400;500;700&display=swap">'
)

_CSS = """
:root{
 --ink:#1B1B1B;--gray:#4A4A4A;--subtle:#7A7A7A;--muted:#9A9483;
 --green:#1F9D55;--green-dark:#14713C;--green-tint:#D3EFDD;
 --cream:#FCFAF4;--cream-2:#FBF6EA;--cream-3:#FFF7E8;--sand:#F1ECDF;--surface:#fff;
 --yellow:#FFCE2E;--yellow-light:#FFF1B8;--coral:#FF6B5B;--border:#DDD4C0;--error-tint:#FDEAEA;
 --neon:#2bff6f;   /* call bar: speaking-glow (enige bar-specifieke token) */
 --font-display:'Bricolage Grotesque',system-ui,sans-serif;
 --font-body:'DM Sans',system-ui,sans-serif;
 --radius:9px;--radius-pill:999px;
 --shadow:0 1px 2px rgba(27,27,27,.06),0 2px 8px rgba(27,27,27,.04);
}
*{box-sizing:border-box}
/* Toetsenbord-zichtbaarheid: één focusregel voor de hele app. :focus-visible i.p.v. :focus,
   zodat muisklikken geen ring tekenen maar Tab-navigatie altijd zichtbaar is (WCAG 2.4.7). */
:focus-visible{outline:2px solid var(--green-dark);outline-offset:2px}
/* Het `hidden`-attribuut moet ALTIJD winnen van een author `display:`-regel (bijv. .kc-radio{display:block}),
   anders werkt geen enkele hidden-gebaseerde show/hide (categorie-filter, .kc-mode, .kc-cond, .tile-back-flip). */
[hidden]{display:none!important}
body{font-family:var(--font-body);font-size:14px;line-height:1.5;color:var(--ink);
 background:var(--cream);margin:0;padding:1.6rem 2rem;max-width:1180px}
h1{font-family:var(--font-display);font-weight:800;font-size:1.5rem;margin:0}
h2{font-family:var(--font-display);font-weight:800;font-size:.95rem;text-transform:uppercase;
 letter-spacing:.03em;margin:1.8rem 0 .5rem;color:var(--green-dark)}
a{color:var(--green-dark)}
.bar{color:var(--gray);margin:.4rem 0 1.2rem;font-size:13px}
.badge{font-size:.66rem;text-transform:uppercase;letter-spacing:.05em;font-weight:700;
 padding:.18rem .55rem;border-radius:var(--radius-pill);vertical-align:middle;margin-left:.4rem}
.badge.ro{background:var(--sand);color:var(--gray)}
.badge.rw{background:var(--green-tint);color:var(--green-dark)}
table{border-collapse:collapse;width:100%;font-size:13px;background:var(--surface);
 border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow)}
th,td{border-bottom:1px solid var(--border);padding:.5rem .6rem;text-align:left;vertical-align:top}
th{background:var(--cream-2);font-family:var(--font-display);font-weight:700;
 text-transform:uppercase;font-size:11px;letter-spacing:.03em;color:var(--gray)}
tr:last-child td{border-bottom:none}
tr.archived td{opacity:.45}
tr.st-pending td{background:var(--yellow-light)}
tr.st-blocked td{background:var(--error-tint)}
tr.st-running td{background:var(--green-tint)}
tr.st-future td{opacity:.55}
.chip{display:inline-block;background:var(--green-tint);color:var(--green-dark);
 border-radius:var(--radius-pill);padding:.1rem .55rem;margin:.06rem;font-size:12px}
.muted{color:var(--muted)}
.btn{font-family:var(--font-body);font-weight:600;font-size:12px;border:1px solid rgba(27,27,27,.14);
 border-radius:var(--radius-pill);background:transparent;color:var(--ink);
 padding:.3rem .85rem;margin:.12rem;cursor:pointer;display:inline-block;text-decoration:none}
.btn:hover{background:rgba(27,27,27,.05)}
.btn.ok{background:var(--green);border-color:var(--green);color:#fff}
.btn.ok:hover{background:var(--green-dark);border-color:var(--green-dark)}
.btn.no{background:#fff;border-color:var(--coral);color:var(--coral)}
.tension{background:var(--cream-3);border:1px solid var(--border);border-radius:var(--radius);
 padding:.7rem .9rem;margin:.6rem 0 1.4rem}
details{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
 margin:.5rem 0;padding:.3rem .9rem;box-shadow:var(--shadow)}
details[open]{padding-bottom:.8rem}
details>summary{cursor:pointer;font-family:var(--font-display);font-weight:700;padding:.45rem 0}
.pf label{display:block;margin:.6rem 0 .2rem;font-size:13px;color:var(--gray)}
.pf input,.pf select{width:100%;padding:.45rem;border:1px solid var(--border);
 border-radius:var(--radius);font:inherit;background:#fff}
.flash{background:var(--green-tint);border:1px solid var(--green);color:var(--green-dark);
 border-radius:var(--radius);padding:.5rem .8rem;margin:.4rem 0 1rem;font-weight:600}
.flash.err{background:var(--error-tint);border-color:var(--coral);color:#A8322A}
/* Fullscreen-overlay (bv. de Snake-easter-egg): draait als iframe OP de huidige pagina i.p.v. een
   navigatie. Dat patroon ontstond om de call bar niet weg te gooien; die is 11 aug 2026 uit de
   shell gehaald en de bijbehorende verberg-regel hier met 'm mee. De overlay-aanpak zelf blijft —
   een navigatie voor een easter-egg is nog steeds zonde. */
.snake-overlay{position:fixed;inset:0;z-index:1000;border:0;background:transparent}
.snake-frame{width:100%;height:100%;border:0;background:transparent}
"""


def _field(label: str, name: str, *, kind: str = "text", value: str = "",
           fid: str = "", required: bool = False, placeholder: str = "",
           attrs: str = "", label_cls: str = "att-lbl") -> str:
    """Label + veld als onlosmakelijk paar: de <label for> wijst ALTIJD naar de veld-id.

    Dit is de structurele fix voor het patroon "label zonder for / input zonder id"
    (label-klik doet niets, screenreader ziet een los veld). Gebruik deze helper voor
    elk nieuw formulierveld; losse <label>/<input>-paren worden door de ratchet
    (tests/test_ui_ratchets.py) op hun huidige aantal bevroren.

    kind: een input-type ("text", "email", "number", "date", …) of "textarea".
    fid:  expliciete id; default "f-<name>". Meerdere velden met dezelfde name op één
          pagina? Geef dan zelf een unieke fid mee.
    attrs: extra rauwe attributen (bv. "min='0' step='1'" of "form='filepost'").
    """
    fid = fid or f"f-{name}"
    req = " required" if required else ""
    ph = f' placeholder="{_e(placeholder)}"' if placeholder else ""
    extra = f" {attrs}" if attrs else ""
    lab = f'<label class="{_e(label_cls)}" for="{_e(fid)}">{_e(label)}</label>'
    if kind == "textarea":
        veld = (f'<textarea id="{_e(fid)}" name="{_e(name)}"{ph}{req}{extra}>'
                f'{_e(value)}</textarea>')
    else:
        veld = (f'<input type="{_e(kind)}" id="{_e(fid)}" name="{_e(name)}" '
                f'value="{_e(value)}"{ph}{req}{extra}>')
    return lab + veld


def _banner(msg) -> str:
    if not msg:
        return ""
    cls = "flash err" if str(msg).lstrip().startswith("✗") else "flash"
    return f'<div class="{cls}">{_e(msg)}</div>'


# Verborgen easter-egg-trigger op elke ingelogde cockpit-pagina (login gebruikt _page NIET): de
# Konami-code of 5× klikken op de paginatitel opent Snake. Self-contained (geen imports) en zonder
# preventDefault, zodat pijltjestoetsen op echte pagina's niet gekaapt worden.
#
# Snake opent als IN-PAGE OVERLAY (fullscreen iframe /snake) i.p.v. een navigatie: zo overleeft de
# call bar-iframe (geen full-page nav → verbinding + audio lopen door). body.overlay-open verbergt de
# bar; de snake-pagina meldt sluiten via postMessage (× of Escape). /snake zit achter de sessie-auth.
_KONAMI_TRIGGER = """<script>(function(){
 function openSnake(){
   if(document.getElementById('snake-overlay'))return;
   var ov=document.createElement('div');ov.id='snake-overlay';ov.className='snake-overlay';
   var fr=document.createElement('iframe');fr.className='snake-frame';fr.src='/snake';fr.title='Snaker';
   fr.setAttribute('allow','autoplay');
   fr.addEventListener('load',function(){try{fr.contentWindow.focus();}catch(e){}});
   ov.appendChild(fr);document.body.appendChild(ov);document.body.classList.add('overlay-open');
 }
 function closeSnake(){var ov=document.getElementById('snake-overlay');if(ov)ov.remove();
   document.body.classList.remove('overlay-open');}
 window.addEventListener('message',function(e){
   if(e.origin!==location.origin)return;
   if((e.data||{}).type==='snake-close')closeSnake();
 });
 var K=['arrowup','arrowup','arrowdown','arrowdown','arrowleft','arrowright','arrowleft','arrowright','b','a'],b=[];
 addEventListener('keydown',function(e){ b.push((e.key||'').toLowerCase()); if(b.length>K.length)b.shift();
   if(b.length===K.length&&K.every(function(k,i){return b[i]===k;})){b=[];openSnake();} });
 var h=document.querySelector('h1'); if(h){var c=0,t; h.addEventListener('click',function(){
   c++; clearTimeout(t); t=setTimeout(function(){c=0;},1500); if(c>=5){c=0;openSnake();} });}
})();</script>"""


def _page(title: str, inner: str) -> str:
    # <main> als landmark om de pagina-inhoud: screenreaders en toetsenbord-gebruikers kunnen
    # direct naar de inhoud springen. De chrome (Noochie-rail, call bar) wordt door _send ná
    # </main> geïnjecteerd en blijft zo buiten de hoofdinhoud.
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{_e(title)}</title>{_FONTS}<style>{_CSS}</style></head>'
            f'<body><main>{inner}</main>{_KONAMI_TRIGGER}</body></html>')
