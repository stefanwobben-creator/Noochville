from __future__ import annotations
import os, json
from datetime import datetime
from nooch_village.skills import Skill
from nooch_village.llm import reason
from nooch_village.grounding import ground_field_note
from nooch_village.evidence_ledger import EvidenceLedger

MISSION = (
    "Nooch.earth bewijst dat ethisch en duurzaam ondernemen winstgevend is. "
    "Kernwaarden: meliorisme (altijd beter), ubuntu (succes samen met klant, producent, planeet), "
    "geen externaliteiten (geen plastic, geen leer, in Europa geproduceerd, op bestelling), transparantie. "
    "Doel: organische groei richting 1000 klanten per jaar via missie-gedreven keywords."
)


class FieldNoteSkill(Skill):
    name = "field_note"
    cost = "free"
    side_effect_free = False
    description = "Duidt de groei-data tegen de Nooch-missie en schrijft een Field Note. Senst verval."

    def run(self, payload: dict, context) -> dict:
        plausible = payload.get("plausible", {})
        trends = payload.get("trends", {})
        # `prose` poort de dure LLM-duiding. Standaard True (backward-compat); de puls zet 'm wekelijks.
        prose = payload.get("prose", True)
        today = datetime.now().strftime("%Y-%m-%d")

        # --- tension-detectie: vergelijk bezoekers met de vorige puls (ALTIJD, goedkoop, geen LLM) ---
        visitors = self._visitors(plausible)
        baseline_path = os.path.join(context.data_dir, "last_pulse.json")
        last = json.load(open(baseline_path)) if os.path.exists(baseline_path) else {}
        last_visitors = last.get("visitors")
        tension, reason_txt = False, ""
        if visitors is not None and last_visitors:
            drop = (last_visitors - visitors) / last_visitors
            if drop >= 0.15:
                tension = True
                reason_txt = f"Bezoekers gedaald van {last_visitors} naar {visitors} ({drop:.0%})."
        if visitors is not None:
            json.dump({"visitors": visitors, "date": today}, open(baseline_path, "w"))

        # --- ruwe data ALTIJD wegschrijven (goedkoop, bouwt dagelijks historie op) ---
        out_dir = os.path.join(context.data_dir, "output")
        os.makedirs(out_dir, exist_ok=True)
        raw_path = os.path.join(out_dir, f"pulse_raw_{today}.json")
        with open(raw_path, "w") as f:
            json.dump({"plausible": plausible, "trends": trends}, f, ensure_ascii=False, indent=2)

        # --- de dure LLM-duiding (proza) is gepoort: standaard wekelijks, niet elke dag ---
        if not prose:
            return {"path": None, "tension": tension, "reason": reason_txt,
                    "grounded": None, "issues": [], "prose": False}

        body = self._compose(plausible, trends, visitors, last_visitors, tension, reason_txt)

        # Grondings-poort (De Kroniek): een LLM-duiding mag geen cijfers/datums verzinnen die niet uit de
        # data volgen. Ongegrond → MARKEREN i.p.v. schoon publiceren (de mens ziet dat 't onbetrouwbaar is).
        issues = ground_field_note(body, plausible, today)
        if issues:
            body = ("> ⚠️ ONGEGROND — deze Field Note bevat data die niet uit de bron volgt:\n"
                    + "".join(f">  - {i}\n" for i in issues) + ">\n\n" + body)

        path = os.path.join(out_dir, f"field_note_{today}.md")
        with open(path, "w") as f:
            f.write(body)

        # Onthouden: leg de grondings-uitkomst vast in de Kroniek (fail-safe — nooit de puls breken).
        try:
            led = EvidenceLedger(os.path.join(context.data_dir, "evidence_ledger.jsonl"))
            led.record(role_id="website_watcher", skill="field_note", query=today, source="grounding",
                       status="fout" if issues else "bevestigd", result_ref=os.path.basename(path),
                       meta={"issues": issues} if issues else None)
        except Exception:
            pass

        return {"path": path, "tension": tension, "reason": reason_txt,
                "grounded": not issues, "issues": issues, "prose": True}

    # --- helpers ---
    def _visitors(self, plausible):
        try:
            return int(plausible["results"]["visitors"]["value"])
        except Exception:
            return None

    def _data_block(self, plausible, trends):
        return json.dumps({"plausible": plausible, "trends": trends}, ensure_ascii=False, indent=2)

    def _compose(self, plausible, trends, visitors, last_visitors, tension, reason_txt):
        today = datetime.now().strftime("%Y-%m-%d")
        # 1. Probeer LLM-redenering
        prompt = (
            f"You are Corry Coconut, website watcher of Nooch.earth. Mission:\n{MISSION}\n\n"
            f"Here is today's growth data (JSON):\n{self._data_block(plausible, trends)}\n\n"
            "Write a Field Note in English (max 250 words). Voice: sober and factual, no marketing "
            "language, no exaggeration. Interpretation is allowed, but only where it follows "
            "directly from the data. Name only fields that are actually in the data; leave empty "
            "fields out and invent nothing.\n\n"
            "Cover three points:\n"
            "(1) What stands out in the traffic and the trends. Weave in the concrete data: "
            "visitors, average visit duration, busiest pages, main traffic sources, strongest "
            "countries, notable UTM or campaign sources, and the rising or falling search terms "
            "with their interest values.\n"
            "(2) What this means for mission-driven growth — grounded in the numbers from point 1.\n"
            "(3) The most important action for tomorrow."
        )
        # Grounding-call: de Field Note is de stem van de rol die hem schrijft, dus zijn
        # persona mag het model kiezen.
        _ladder = None
        try:
            from nooch_village.llm_keuze import llm_voorkeur
            _ladder = llm_voorkeur(context, getattr(context, "field_note_role", "analyst"),
                                   "skill_field_note")
        except Exception:
            pass
        llm = reason(prompt, call_site="skill_field_note", ladder=_ladder)
        header = f"# Field Note {today}\n\n"
        if tension:
            header += f"> ⚠️ SPANNING: {reason_txt}\n\n"
        if llm:
            return header + llm + "\n"

        # 2. Deterministische terugval (werkt altijd, ook zonder LLM-key)
        lines = [header, "## Verkeer (Plausible)"]
        if "error" in plausible:
            lines.append(f"- Geen data: {plausible['error']}")
        else:
            lines.append(f"- Bezoekers (7d): {visitors if visitors is not None else 'onbekend'}"
                         + (f" (vorige puls: {last_visitors})" if last_visitors else ""))
        lines.append("\n## Trends")
        kw = (trends or {}).get("keywords", {})
        if not kw or "error" in (trends or {}):
            lines.append(f"- Geen trends-data: {(trends or {}).get('error', 'leeg')}")
        else:
            for k, v in kw.items():
                if "error" in v:
                    lines.append(f"- **{k}**: fout ({v['error']})")
                else:
                    rel = ", ".join(
                        r["query"] if isinstance(r, dict) else r
                        for r in v.get("top_related", [])
                    ) or "geen"
                    lines.append(f"- **{k}**: interesse {v.get('interest_latest')} ({v.get('direction')}); "
                                 f"opkomend: {rel}")
        lines.append("\n## Duiding")
        if tension:
            lines.append(f"- {reason_txt} Onderzoek welke missie-pagina terugloopt.")
        else:
            lines.append("- Geen alarmsignaal in het verkeer.")
        lines.append("- (Zet een LLM-key in .env voor een rijkere, missie-gedreven duiding.)")
        return "\n".join(lines) + "\n"
