"""views/founder_flow.py — het scherm van de graduele-autonomie-trainingslus.

Vormgeving: strikt hergebruik van het bestaande vocabulaire (`.card`, `.chip`, `.btn`, `.cl-bar`,
`.c2-sec`, `.pill`, `.muted`). Geen nieuw klasse-prefix, geen inline style, geen eigen CSS-blob —
de ratchet-guards bewaken dat, maar de reden is inhoudelijk: dit scherm is een lijst met knoppen,
en daar bestaat al een vormtaal voor.

Twee dingen die de VIEW moet afdwingen, niet alleen de logica:

1. **Blind-eerst is afwezigheid, geen verstopping.** Op niveau A/B en in de auditsteekproef staat
   het AI-voorstel niet in de HTML. Niet `hidden`, niet gedimd — er niet. Een voorstel dat in de
   broncode staat, is een voorstel dat lekt, en dan meet de lus de echo van de AI in plaats van
   het oordeel van de mens.
2. **Correctie kost één klik, net als goedkeuren.** Beide zijn één submit-knop in hetzelfde
   formulier. Zodra corrigeren twee klikken of een tekstveld kost, krijg je stilzwijgende
   instemming — en een meting die te mooi is om waar te zijn.

Op A/B zijn de knoppen bewust neutraal (`.btn`, geen `.btn ok`): daar mag niets naar een antwoord
duwen. Op C/D krijgt het AI-voorstel wél de primaire kleur — dáár ís het de default, en dat mag je
dan ook eerlijk laten zien (UX_PATTERNS §6: alleen sturen als je bewust stuurt).
"""
from __future__ import annotations

import time

from nooch_village import founder_flow as ff
from nooch_village.cockpit2_util import _DS_LINK, _nav
from nooch_village.web_base import _banner, _e, _page

RITMES = ("dag", "week")
_RITME_LABEL = {"dag": "Daily — short round", "week": "Weekly — full queue"}


def _pct(x: float) -> str:
    return f"{x * 100:.0f}%"


def _terug(ritme: str) -> str:
    return f"/founder?ritme={ritme}"


def _hidden(csrf_token: str, ritme: str, **velden) -> str:
    rijen = [f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>",
             f"<input type='hidden' name='next' value='{_e(_terug(ritme))}'>"]
    rijen += [f"<input type='hidden' name='{_e(k)}' value='{_e(v)}'>" for k, v in velden.items()]
    return "".join(rijen)


# ── De onthulling na een blinde beslissing ───────────────────────────────────

def _onthulling(onthuld: str, csrf_token: str, ritme: str) -> str:
    """Wat de AI zou hebben gezegd, ná de menselijke beslissing.

    Dit is de tegenhanger van blind-eerst: de founder wordt niet gestuurd, maar leert wél. Op
    niveau A blijft het bij de constatering (daar beslist hij en verder niemand). Vanaf B mag hij
    met één klik alsnog het AI-voorstel overnemen — die klik wordt als correctie gelogd en telt,
    juist omdat hij besmet is, NIET mee in de meting."""
    delen = (onthuld or "").split("|")
    if len(delen) != 5:
        return ""
    taak, item, mens, ai, niveau = delen
    if taak not in ff.TAKEN or mens not in ff.OORDELEN[taak]:
        return ""
    mens_l = _e(ff.OORDEEL_LABEL.get(mens, mens))
    if ai not in ff.OORDELEN[taak]:
        return (f"<div class='card'><div class='ptitle'>You: {mens_l}</div>"
                f"<p class='muted'>The AI had no proposal for this item, so this decision does "
                f"not count towards the measurement.</p></div>")
    eens = mens == ai
    ai_l = _e(ff.OORDEEL_LABEL.get(ai, ai))
    chip = ("<span class='chip green'>agreed</span>" if eens
            else "<span class='chip amber'>disagreed</span>")
    knop = ""
    if not eens and niveau != "A" and csrf_token:
        knop = (f"<form method='post' action='/action'>"
                f"{_hidden(csrf_token, ritme, taak=taak, item=item, oordeel=ai, correctie='1')}"
                f"<button class='btn sm' type='submit' name='action' value='ff_beslis'>"
                f"take the AI's answer instead</button></form>")
    return (f"<div class='card'>{chip} <span class='ptitle'>You: {mens_l} · AI: {ai_l}</span>"
            f"<p class='muted'>Recorded blind — the proposal was computed before you decided but "
            f"only shown afterwards, so this example counts towards the measurement.</p>"
            f"{knop}</div>")


# ── De kop van een taak: niveau, meting, promotie ────────────────────────────

def _meterkaart(data_dir: str, taak: str, niveau: str, labels: list[dict], cfg: dict,
                csrf_token: str, ritme: str, niveaus: "ff.NiveauStore | None" = None,
                audit_open: int = 0) -> str:
    meting = ff.overeenstemming(labels, taak, cfg["venster"])
    kan, reden = ff.promoveerbaar(labels, taak, niveau, cfg)
    # Dezelfde vensterbegrenzing als de demotie-poort, anders waarschuwt het scherm over iets
    # anders dan waarop het systeem terugvalt.
    sinds = ff.laatste_wissel(niveaus, taak) if niveaus is not None else 0.0
    afwijking = ff.drift(labels, taak, niveau, cfg, sinds=sinds)

    meetregel = (
        f"agreement <b>{_pct(meting['ratio'])}</b> "
        f"(95% lower bound {_pct(meting['lo'])}) over {meting['n']} blind example(s) · "
        f"bar {_pct(cfg['lat'])}, minimum {int(cfg['min_n'])}"
        if meting["n"] else
        f"no blind examples yet · bar {_pct(cfg['lat'])}, minimum {int(cfg['min_n'])}")

    knoppen = ""
    if csrf_token:
        if kan:
            knoppen += (
                f"<form method='post' action='/action'>"
                f"{_hidden(csrf_token, ritme, taak=taak)}"
                f"<button class='btn ok sm' type='submit' name='action' value='ff_promote'>"
                f"promote to {ff.volgende(niveau)}</button></form>")
        if niveau != "A":
            knoppen += (
                f"<form method='post' action='/action'>"
                f"{_hidden(csrf_token, ritme, taak=taak)}"
                f"<button class='btn sm' type='submit' name='action' value='ff_demote'>"
                f"step back to {ff.vorige(niveau)}</button></form>")
    poort = "" if kan else f"<p class='muted'>Promotion blocked: {_e(reden)}</p>"
    waarschuwing = f"<div class='flash err'>{_e(afwijking)}</div>" if afwijking else ""

    return (f"<div class='card'>"
            f"<div class='ptitle'>Level {_e(niveau)} "
            f"<span class='pill'>{_e(ff.NIVEAU_UITLEG[niveau])}</span></div>"
            f"<p class='muted'>{meetregel}</p>"
            f"{waarschuwing}{_terugvalregel(taak, niveau, cfg, labels, sinds, audit_open)}"
            f"{poort}{knoppen}"
            f"{_laatste_wissel_regel(niveaus, taak)}"
            f"{_weekregel(labels, taak)}</div>")


def _terugvalregel(taak: str, niveau: str, cfg: dict, labels: list[dict], sinds: float,
                   audit_open: int) -> str:
    """Wat de terugval-poort nu ziet, en waar hij op wacht.

    De auditsteekproef is de enige schone meetreeks zodra de AI zelf werkt; blijft die liggen,
    dan stopt drift met zichtbaar zijn. Dat mag geen stille toestand zijn, dus het scherm zegt
    hoeveel er wacht en hoeveel oordelen de poort nog nodig heeft."""
    if niveau not in ("C", "D"):
        return ""
    drempel = int(cfg["min_n"])
    gedaan = ff.overeenstemming(labels, taak, cfg["venster"], sinds=sinds)["n"]
    wachtend = (f" · {audit_open} audit item(s) waiting for you" if audit_open else "")
    return (f"<p class='muted'>Automatic step-back is armed: this task drops a level as soon as "
            f"the blind audit sample would no longer earn it — same bar ({_pct(cfg['lat'])}) and "
            f"same evidence as promotion. Judged since the last level change: "
            f"{gedaan}/{drempel} needed{wachtend}.</p>")


def _laatste_wissel_regel(niveaus, taak: str) -> str:
    """De laatste tree-wissel met zijn reden — een automatische terugval mag niet stil gebeuren."""
    if niveaus is None:
        return ""
    rijen = niveaus.historie(taak)
    if not rijen:
        return ""
    r = rijen[-1]
    hoe = "automatically" if r.get("door") == "auto" else f"by {r.get('door', '?')}"
    return (f"<p class='muted'>Last change: {_e(r.get('van', ''))} → {_e(r.get('naar', ''))} "
            f"{_e(hoe)} — {_e(r.get('reden', ''))}</p>")


def _weekregel(labels: list[dict], taak: str) -> str:
    """De succesmetriek: founder-minuten per week, en welk aandeel de AI overnam.

    Het getal dat moet dalen staat vooraan. Zonder weken toont hij dat er nog niets te zien is —
    'leeg' is iets anders dan 'nul' (UX_PATTERNS §7)."""
    cijfers = ff.weekcijfers(labels, taak)
    if not cijfers:
        # De naam van de metriek staat er ook zonder data: "leeg" is iets anders dan "nul", en een
        # metriek die pas verschijnt als hij gevuld is, valt niet op als hij wegblijft.
        return "<p class='muted'>Founder minutes per week: nothing measured yet.</p>"
    stukken = " · ".join(
        f"{_e(c['week'])} <b>{c['minuten']} min</b> "
        f"({c['beslissingen']} decision(s), AI {_pct(c['ai_aandeel'])})"
        for c in cijfers)
    richting = ff.trend(cijfers)
    staart = f" <span class='pill'>{_e(richting)}</span>" if richting else ""
    return f"<p class='muted'>Founder minutes per week: {stukken}{staart}</p>"


# ── Eén item ─────────────────────────────────────────────────────────────────

def _knoppen(taak: str, item: dict, toon_voorstel: bool, csrf_token: str, ritme: str,
             correctie: bool = False) -> str:
    """Elke keuze is één submit-knop in hetzelfde formulier: goedkeuren en corrigeren kosten
    exact evenveel. Alleen als het voorstel zichtbaar is krijgt het de primaire kleur."""
    if not csrf_token:
        return "<p class='muted'>Read-only — log in to decide.</p>"
    knoppen = ""
    for oordeel in ff.OORDELEN[taak]:
        primair = " ok" if (toon_voorstel and oordeel == item.get("ai")) else ""
        label = ff.OORDEEL_LABEL.get(oordeel, oordeel)
        knoppen += (f"<button class='btn{primair} sm' type='submit' name='oordeel' "
                    f"value='{_e(oordeel)}'>{_e(label)}</button>")
    extra = {"correctie": "1"} if correctie else {}
    return (f"<form method='post' action='/action'>"
            f"{_hidden(csrf_token, ritme, taak=taak, item=item['item'], **extra)}"
            f"<input type='hidden' name='action' value='ff_beslis'>"
            # Server-gestempeld: hieruit volgen de founder-minuten. De client kiest het moment
            # niet — hij krijgt het mee en stuurt het terug.
            f"<input type='hidden' name='getoond' value='{time.time():.0f}'>"
            f"{knoppen}</form>")


def _itemkaart(taak: str, item: dict, niveau: str, audit: bool, csrf_token: str,
               ritme: str) -> str:
    toon = ff.toont_voorstel_vooraf(niveau, audit)
    kop = ""
    if audit and niveau in ("C", "D"):
        kop = "<span class='chip amber'>audit sample</span> "
    detail = f"<p class='muted'>{_e(item.get('detail', ''))}</p>" if item.get("detail") else ""
    bron = ""
    if item.get("context"):
        bron = f"<span class='pill'>{_e(item['context'])}</span>"
    if item.get("link"):
        bron += (f" <a href='{_e(item['link'])}' target='_blank' rel='noopener'>source ↗</a>")

    if toon and item.get("ai"):
        voorstel = (f"<p class='muted'>The AI proposes <b>"
                    f"{_e(ff.OORDEEL_LABEL.get(item['ai'], item['ai']))}</b> — "
                    f"{_e(item.get('ai_waarom', ''))}</p>")
    elif toon:
        voorstel = "<p class='muted'>The AI has no proposal for this item — you decide.</p>"
    else:
        # Blind: geen voorstel in de HTML. Alleen de belofte dat het er ná de beslissing is.
        voorstel = "<p class='muted'>You decide first; the AI's proposal follows afterwards.</p>"

    return (f"<div class='card'>{kop}<span class='ptitle'>{_e(item.get('titel', ''))}</span> {bron}"
            f"{detail}{voorstel}"
            f"{_knoppen(taak, item, toon, csrf_token, ritme)}</div>")


def _ai_gedaan(labels: list[dict], taak: str, niveau: str, csrf_token: str, ritme: str,
               maximaal: int = 8) -> str:
    """Niveau C: wat de AI zelf afhandelde, mét een correctie op één klik.

    Op D staat dit blok er bewust NIET — dat is precies het verschil tussen 'jij auditeert' en
    'stil'. De auditsteekproef blijft op beide niveaus doorlopen, dus meten doen we hoe dan ook."""
    if niveau != "C":
        return ""
    rijen = [r for r in labels if r.get("taak") == taak and r.get("mens") is None]
    rijen.sort(key=lambda r: r.get("ts", 0), reverse=True)
    if not rijen:
        return ""
    kaarten = ""
    for r in rijen[:maximaal]:
        gedaan = _e(ff.OORDEEL_LABEL.get(r.get("ai"), r.get("ai") or "?"))
        item = {"item": r.get("item", ""), "ai": r.get("ai")}
        kaarten += (
            f"<div class='card'><span class='chip muted'>done by the AI</span> "
            f"<span class='ptitle'>{_e(r.get('titel') or r.get('item', ''))}</span> "
            f"<span class='pill'>{gedaan}</span>"
            f"{_knoppen(taak, item, True, csrf_token, ritme, correctie=True)}</div>")
    return (f"<div class='c2-sec'><h3>Handled by the AI — audit</h3>"
            f"<p class='muted'>One click corrects any of these; the correction is recorded.</p>"
            f"{kaarten}</div>")


# ── Eén taak ─────────────────────────────────────────────────────────────────

_RADAR_VIEWS = ("trend", "nieuw")
_RADAR_VIEW_LABEL = {"trend": "Trends — topics by distinct sources",
                     "nieuw": "New content — one judgement each"}


def _trendkaart(c: dict, besluit: dict | None, niveau: str, venster: int,
                csrf_token: str, ritme: str) -> str:
    """Eén onderwerp: wat het is, uit hoeveel VERSCHILLENDE bronnen het komt, en of dat stijgt.

    Het aantal bronnen staat vooraan omdat dat het getal is dat iets betekent; het aantal signalen
    staat er als context naast. Acht vermeldingen uit één feed lezen hier als "1 source", en dat
    is precies de bedoeling."""
    t = c["trend"]
    chip = {"stijgend": "<span class='chip green'>rising</span>",
            "dalend": "<span class='chip muted'>falling</span>",
            "stabiel": "<span class='chip outline'>steady</span>"}.get(t["richting"], "")
    open_n = len(c.get("open") or [])
    regel = (f"<b>{t['bronnen']} source(s)</b> · {t['signalen']} signal(s) in the last "
             f"{venster} days (previous period: {t['eerder_bronnen']} source(s), "
             f"{t['eerder_signalen']} signal(s))")
    staart = f" · {open_n} still open" if open_n else " · nothing open"

    knoppen = ""
    if besluit:
        keuze = "made into a project" if besluit.get("keuze") == "project" else "on the watch list"
        knoppen = f"<p class='muted'>You already put this {_e(keuze)}.</p>"
    elif csrf_token:
        rol = (c["leden"][0].get("role") or "") if c.get("leden") else ""
        bewijs = " · ".join(sorted(set(
            str(i.get("source") or i.get("feed") or "") for i in c["leden"]))[:8])
        velden = _hidden(csrf_token, ritme, sleutel=c["sleutel"], onderwerp=c["onderwerp"],
                         rol=rol, bewijs=f"{t['bronnen']} sources: {bewijs}")
        knoppen = (f"<form method='post' action='/action'>{velden}"
                   f"<input type='hidden' name='action' value='ff_cluster'>"
                   f"<button class='btn sm' type='submit' name='keuze' value='project'>"
                   f"make it a project</button>"
                   f"<button class='btn sm' type='submit' name='keuze' value='watch'>"
                   f"watch</button></form>")

    # Invouwen is zichtbaar en omkeerbaar: de bekende signalen staan er, uitklapbaar, nooit weg.
    # Alleen vanaf C — op A/B zou dit het AI-oordeel verraden vóór de founder blind besloot.
    gevouwen = ""
    if niveau in ("C", "D") and c.get("ingevouwen"):
        rijen = "".join(f"<li>{_e(i.get('content', '')[:140])} "
                        f"<span class='pill'>{_e(i.get('source') or i.get('feed') or '')}</span></li>"
                        for i in c["ingevouwen"])
        gevouwen = (f"<details><summary>{len(c['ingevouwen'])} folded — already known to us"
                    f"</summary><ul class='clean'>{rijen}</ul>"
                    f"<p class='muted'>Folded means counted, not deleted: these still feed the "
                    f"source counter and stay in the radar.</p></details>")

    return (f"<div class='card'>{chip} <span class='ptitle'>{_e(c['onderwerp'])}</span>"
            f"<p class='muted'>{regel}{staart}</p>{knoppen}{gevouwen}</div>")


def _radar_trendview(st, data_dir: str, niveau: str, csrf_token: str, ritme: str) -> str:
    from nooch_village import founder_taken

    beeld = founder_taken.radar_beeld(st, data_dir)
    if not beeld["clusters"]:
        return "<p class='muted'>No signals in the window yet.</p>"
    besluiten = st.radar_besluiten.alles()
    kaarten = "".join(_trendkaart(c, besluiten.get(c["sleutel"]), niveau, beeld["venster"],
                                  csrf_token, ritme)
                      for c in beeld["clusters"][:12])
    # Eerlijk over welke laag het deed: 'lexicaal' betekent dat er woorden zijn geteld, geen
    # betekenis vergeleken. Dat verandert wat je uit een cluster mag afleiden.
    uitleg = ("grouped by meaning (embeddings)" if beeld["modus"] == "semantisch"
              else "grouped by word overlap — no embeddings available, so topics are coarser")
    return (f"<p class='muted'>{len(beeld['clusters'])} topic(s), {uitleg}. "
            f"A topic rises when it reaches more distinct sources than in the previous "
            f"{beeld['venster']} days — repeats from one feed do not count twice.</p>{kaarten}")


def _taaksectie(st, data_dir: str, taak: str, niveau: str, labels: list[dict], cfg: dict,
                csrf_token: str, ritme: str, niveaus=None, radar_view: str = "trend") -> str:
    from nooch_village import founder_taken

    if taak == ff.RADAR:
        picker = "".join(
            f"<a class='cl-filter{' on' if v == radar_view else ''}' "
            f"href='/founder?ritme={ritme}&radar={v}'>{_e(_RADAR_VIEW_LABEL[v])}</a>"
            for v in _RADAR_VIEWS)
        kop = (f"<div class='c2-sec'><h3>{_e(ff.TAAK_LABEL[taak])}</h3>"
               f"{_meterkaart(data_dir, taak, niveau, labels, cfg, csrf_token, ritme, niveaus, 0)}"
               f"<div class='cl-bar'>{picker}</div>")
        if radar_view == "trend":
            # De trend is berekend, geen oordeel: geen trede, geen label, alleen tonen.
            return kop + _radar_trendview(st, data_dir, niveau, csrf_token, ritme) + "</div>"
        return kop + "</div>" + _radar_wachtrij(st, data_dir, taak, niveau, labels, cfg,
                                                csrf_token, ritme)

    blok = _wachtrijblok(st, data_dir, taak, niveau, labels, cfg, csrf_token, ritme)
    return (f"<div class='c2-sec'><h3>{_e(ff.TAAK_LABEL[taak])}</h3>"
            f"{_meterkaart(data_dir, taak, niveau, labels, cfg, csrf_token, ritme, niveaus, blok['audit_open'])}"
            f"{blok['run']}{blok['kaarten']}{blok['staart']}</div>"
            f"{_ai_gedaan(labels, taak, niveau, csrf_token, ritme)}")


def _wachtrijblok(st, data_dir: str, taak: str, niveau: str, labels: list[dict], cfg: dict,
                  csrf_token: str, ritme: str) -> dict:
    """De wachtrij van één taak: kaarten, staart, de run-knop en hoeveel audit-items er wachten."""
    from nooch_village import founder_taken

    items = founder_taken.wachtrij(st, data_dir, taak, labels, niveau)
    cap = int(cfg.get("dag_cap", 5)) if ritme == "dag" else len(items)
    # De auditsteekproef staat vooraan in de dagronde: dat zijn de items die de terugval-poort
    # voeden, en een korte ronde die ze achteraan laat liggen maakt drift onmeetbaar.
    if niveau in ("C", "D"):
        items.sort(key=lambda i: not ff.in_auditsteekproef(taak, i["item"],
                                                           cfg.get("audit_pct", 0)))
    audit_open = sum(1 for i in items
                     if ff.in_auditsteekproef(taak, i["item"], cfg.get("audit_pct", 0)))
    getoond, rest = items[:cap], max(0, len(items) - cap)

    kaarten = ""
    for it in getoond:
        audit = ff.in_auditsteekproef(taak, it["item"], cfg.get("audit_pct", 0))
        kaarten += _itemkaart(taak, it, niveau, audit, csrf_token, ritme)
    if not getoond:
        kaarten = "<p class='muted'>Nothing waiting.</p>"
    staart = (f"<p class='muted'>{rest} more waiting — the weekly round shows them all.</p>"
              if rest else "")
    run = ""
    if niveau in ("C", "D") and items and csrf_token:
        run = (f"<form method='post' action='/action'>"
               f"{_hidden(csrf_token, ritme, taak=taak)}"
               f"<button class='btn sm' type='submit' name='action' value='ff_run'>"
               f"let the AI work through the queue</button></form>")
    return {"kaarten": kaarten, "staart": staart, "run": run, "audit_open": audit_open}


def _radar_wachtrij(st, data_dir: str, taak: str, niveau: str, labels: list[dict], cfg: dict,
                    csrf_token: str, ritme: str) -> str:
    """De nieuwheids-wachtrij: één oordeel per signaal — is dit nieuwe inhoud?"""
    blok = _wachtrijblok(st, data_dir, taak, niveau, labels, cfg, csrf_token, ritme)
    uitleg = ("<p class='muted'>Every open signal is here — the AI's novelty call stays hidden "
              "until you have judged, so the queue itself gives nothing away.</p>"
              if niveau in ("A", "B") else
              "<p class='muted'>Only the signals the AI reads as new content. What it folded "
              "sits under its topic in the trend view, counted and reversible.</p>")
    return (f"<div class='c2-sec'>{uitleg}{blok['run']}{blok['kaarten']}{blok['staart']}</div>"
            f"{_ai_gedaan(labels, taak, niveau, csrf_token, ritme)}")


# ── Projectvoorstellen: het dorp stelt voor, jij beslist ─────────────────────

# Herkomst → leesbaar label. Verhuisd uit views/projects.py toen de review-baan hierheen kwam.
_VOORSTEL_BRON = {"proposal:radar": "approved signal", "proposal:kroniek": "gap in the Chronicle"}


def _voorstellen_sectie(st, csrf_token: str, ritme: str, username: str | None) -> str:
    """De voorstellen die op jouw oordeel wachten, dorpsbreed.

    Stond tot 11 aug 2026 op de projecten-tab, in twee smaken (rol én cirkel). Daar moest je per
    rol en per cirkel langs om te zien wat er lag, en zag je nooit het totaal — terwijl dit precies
    het soort beslissing is waar deze flow voor bestaat.

    BEWUST GEEN rijpheidsniveau. De andere flow-taken meten of de AI het menselijke oordeel
    reproduceert; hier is geen AI-voorstel om tegen af te zetten (het dorp stelt het project vóór,
    het beoordeelt het niet). Een trede erop plakken zou een meting suggereren die er niet is —
    zelfde reden als bij de cluster-actie in de trend-view.

    De knoppen verschijnen alleen als deze kijker ook echt mag beslissen: de dispatch-tak poort op
    rolvervuller-of-Circle-Lead, en een knop mag nooit iets beloven wat de dispatch weigert."""
    from nooch_village.cockpit2 import _role_gate

    voorstellen = [p for p in st.projects.all()
                   if p.get("status") == "proposed" and not p.get("archived")]
    if not voorstellen:
        return (f"<div class='c2-sec'><h3>Proposals</h3>"
                f"<p class='muted'>Nothing awaiting your judgement.</p></div>")

    kaarten = ""
    for p in sorted(voorstellen, key=lambda x: x.get("created_at") or 0, reverse=True):
        eigenaar = p.get("owner") or "?"
        rec = st.records.get(eigenaar)
        naam = getattr(getattr(rec, "definition", None), "name", "") or eigenaar
        bron = _VOORSTEL_BRON.get(p.get("origin", ""), "the village")
        mag = csrf_token and _role_gate(eigenaar, username, st) is None
        if mag:
            velden = _hidden(csrf_token, ritme, pid=p["id"])
            knoppen = (f"<form method='post' action='/action'>{velden}"
                       f"<button class='btn ok sm' type='submit' name='action' "
                       f"value='proj_proposal_accept'>accept</button>"
                       f"<button class='btn sm' type='submit' name='action' "
                       f"value='proj_proposal_reject' "
                       f"onclick=\"return confirm('Reject this proposal? It will not come back.')\">"
                       f"reject</button></form>")
        else:
            knoppen = ("<p class='muted'>Only the role filler or Circle Lead of this role can "
                       "decide on this one.</p>")
        kaarten += (f"<div class='card'>"
                    f"<span class='ptitle'>"
                    f"<a href='/project?pid={_e(p['id'])}'>{_e(_scope(p) or '—')}</a></span> "
                    f"<span class='pill'>{_e(bron)}</span> "
                    f"<span class='pill'>{_e(naam)}</span>{knoppen}</div>")
    return (f"<div class='c2-sec'><h3>Proposals — awaiting your judgement "
            f"({len(voorstellen)})</h3>"
            f"<p class='muted'>The village proposes; you decide. Nothing here is on the board or "
            f"being worked on. Accepting puts it in Future on the role's board; rejecting is "
            f"remembered, so the same source will not propose it again.</p>{kaarten}</div>")


def _scope(p: dict) -> str:
    sc = p.get("scope")
    if isinstance(sc, dict):
        return " · ".join(f"{k}: {v}" for k, v in sc.items())
    return str(sc or "")


# ── De pagina ────────────────────────────────────────────────────────────────

def render_founder_flow(st, data_dir: str, *, csrf_token: str = "", msg: str = "",
                        ritme: str = "dag", onthuld: str = "", radar_view: str = "trend",
                        username: str | None = None) -> str:
    ritme = ritme if ritme in RITMES else "dag"
    radar_view = radar_view if radar_view in _RADAR_VIEWS else "trend"
    niveaus = ff.NiveauStore(f"{data_dir}/{ff.NIVEAU_BESTAND}")
    labels = ff.alle(data_dir)
    cfg = ff.instellingen(data_dir)

    picker = "".join(
        f"<a class='cl-filter{' on' if r == ritme else ''}' href='/founder?ritme={r}'>"
        f"{_e(_RITME_LABEL[r])}</a>" for r in RITMES)

    secties = "".join(
        _taaksectie(st, data_dir, taak, niveaus.niveau(taak), labels, cfg[taak], csrf_token,
                    ritme, niveaus, radar_view)
        for taak in ff.TAKEN)

    main = (
        f"<div class='c2-main'><div class='c2-bar'><a href='/admin'>← people</a></div>"
        f"<h1>Founder Flow <span class='chip'>training loop</span></h1>"
        f"{_banner(msg)}"
        f"<p class='muted'>Every decision here becomes a labelled example. Each task climbs "
        f"A → B → C → D on its own, and only when the measured agreement between the AI's "
        f"proposal and your judgement clears the bar on a held-out sample.</p>"
        f"<div class='cl-bar'>Rhythm: {picker}</div>"
        f"{_onthulling(onthuld, csrf_token, ritme)}"
        f"{secties}"
        f"{_voorstellen_sectie(st, csrf_token, ritme, username)}</div>")
    return _page("Founder Flow", f"{_DS_LINK}{_nav()}<div class='c2-wrap'>{main}</div>")
