"""Overview-views — brok 10 van de cockpit2-split."""
from __future__ import annotations

import json
import time
import urllib.parse
from typing import TYPE_CHECKING

from nooch_village.web_base import _e, _page, _banner
from nooch_village.cockpit2_util import (
    _DS_LINK,
    _name, _initials, _tabbar, _avatar, _age, _md, md_editor,
    _psec, _person_name, _ICON_ADD_EMOJI,
    _IC_CHECK, _IC_CLOCK, _IC_LINK, _IC_TARGET, _nav,)
from nooch_village.views.feed import _mentionables
from nooch_village.views.checklists import _checklists_tab_html, _cl_row
from nooch_village.views.metrics import _metrics_tab_html, _METRICS_JS
from nooch_village.views.metrics2 import render_metrics2_tab, render_metrics2_person
from nooch_village.views.strategy import _strategy_tab_html
from nooch_village.views.backlog import render_backlog_tab
from nooch_village.views.projects import (
    _projects_tab_html, _scope_text, _person_projects_tab_html, _modal_html,
)
from nooch_village import org, ai_match, artefacts, epic, acc_ids, skill_meta, skill_links, skill_labels
from nooch_village.ai_tasks import KIND_AUTONOOM, KIND_MIDDEL
from nooch_village.registry_factory import shared_registry
from nooch_village.radar_store import feeds_for_role
from nooch_village.cockpit2_util import _CIRCLE_TABS, _ROLE_TABS, _PERSON_TABS, WEBSITE_DEVELOPER_ROLE

if TYPE_CHECKING:
    from nooch_village.cockpit2 import _Stores

def _filler_html(st: _Stores, node_id: str, rec) -> str:
    fillers = st.assign.fillers_of(node_id, record=rec)
    if not fillers:
        return "<span class='muted'>Not filled yet.</span>"
    out = []
    for f in fillers:
        if f.type == "person":
            p = st.people.get(f.id)
            nm = p.name if p else f.id
            out.append(f"<span class='person'><span class='av'>{_e(_initials(nm))}</span>"
                       f"<a href='/person?id={_e(f.id)}'>{_e(nm)}</a></span>")
        else:
            pa = st.personas.get(f.id)
            nm = (pa.name if pa else f.id) + " (AI)"
            out.append(f"<span class='person'><span class='av ai'>AI</span>{_e(nm)}</span>")
    return "<div>" + " &nbsp; ".join(out) + "</div>"


def _members_of_circle(st: _Stores, circle_id: str) -> list:
    seen, ppl = set(), []
    anchors = [circle_id] + [r.id for r in org.roles_of(st.records.all(), circle_id)]
    for aid in anchors:
        rec = st.records.get(aid)
        for f in st.assign.fillers_of(aid, record=rec):
            if f.type == "person" and f.id not in seen:
                seen.add(f.id)
                p = st.people.get(f.id)
                if p:
                    ppl.append(p)
    return sorted(ppl, key=lambda p: p.name)


def _tree_html(st: _Stores, current_id: str) -> str:
    recs = st.records.all()
    # De cirkel die de huidige node bevat (en zijn ouders) staat open; de rest ingeklapt (native
    # <details>, geen JS, geen persistentie). Zo blijft de boom overzichtelijk bij 20+ rollen.
    ancestors = set(org.breadcrumb(recs, current_id)) if current_id else set()

    def kids_of(rec):
        # Kernrollen (Lead/Rep/Secretary/Facilitator) niet in de navigatie: die zie je via de
        # cirkel -> Rollen. Houdt de boom rustig.
        return sorted([k for k in org.children_of(recs, rec.id)
                       if org.is_circle(k) or _name(k).strip().lower() not in _CORE_ROLE_NAMES],
                      key=lambda r: (not org.is_circle(r), _name(r).lower()))

    def node_li(rec, depth: int) -> str:
        is_c = org.is_circle(rec)
        cls = ("c" if is_c else "") + (" here" if rec.id == current_id else "")
        link = f"<a class='{cls}' href='/node?id={_e(rec.id)}'"
        if not is_c:
            return f"<li>{link}>{_e(_name(rec))}</a></li>"
        inner = "".join(node_li(k, depth + 1) for k in kids_of(rec))
        if depth == 0:
            # De anchor (Mother Earth) blijft een vaste kop, niet inklapbaar.
            return f"<li>{link}>{_e(_name(rec))}</a><ul>{inner}</ul></li>"
        # Sub-cirkel (Nooch e.d.) inklapbaar; open als de huidige node erin zit. Klik op de naam
        # navigeert (stopPropagation → geen toggle), klik op de caret klapt in/uit.
        # Noochville staat altijd standaard open (de thuisbasis), ook zonder huidige node erin.
        op = " open" if (rec.id in ancestors
                         or _name(rec).strip().lower() == "noochville") else ""
        summ = f"{link} onclick='event.stopPropagation()'>{_e(_name(rec))}</a>"
        return (f"<li><details class='tree-c'{op}><summary>{summ}</summary>"
                f"<ul>{inner}</ul></details></li>")

    body = "".join(node_li(r, 0) for r in org.roots(recs)) or "<li class='muted'>empty</li>"
    return f"<div class='tree'><h3>Organization</h3><ul>{body}</ul></div>"


def _ai_chip(st: _Stores, t) -> str:
    pa = st.personas.get(t.agent)
    nm = pa.name if pa else t.agent
    skill = f" · {_e(t.wat)}" if t.wat else ""
    return f"<span class='chip'>🤖 {_e(nm)}{skill}</span>"


def _link_chip(t) -> str:
    """Een gekoppeld dorpsmiddel: mensentaal voorop, de technische capability eronder."""
    dom = skill_meta.schrijft_in_domein(t.skill)
    mark = f" <span class='muted'>· domain {_e(dom)}</span>" if dom else ""
    return (f"<span class='chip'>🔗 {_e(skill_labels.label(t.skill))}</span>"
            f"<span class='muted'> {_e(t.skill)}</span>{mark}")


def _middel_picker(st: _Stores, rec, role_id: str, acc_id: str, hid) -> str:
    """Picker voor dorpsmiddelen op deze belofte.

    Alleen skills die de rol nog niet via deze accountability voert, en alleen skills die de
    domeinpoort doorlaten: een beslis-skill verschijnt niet eens in de lijst bij een rol die het
    domein niet houdt. De poort in de dispatch is de tweede sleutel (verdediging in de diepte).
    """
    if rec is None:
        return ""
    try:
        namen = sorted(shared_registry().names())
    except Exception:                              # fail-closed: liever geen picker dan een lege belofte
        return "<p class='muted'>The resources catalog is briefly unavailable.</p>"
    al = {t.skill for t in skill_links.links_for_acc(st.ai, role_id, acc_id)}
    kies = [n for n in namen if n not in al and skill_meta.koppelbaar(n, rec)[0]]
    if not kies:
        return "<p class='muted'>No resource left to link here.</p>"
    opts = "".join(
        f"<option value='{_e(n)}'>{_e(skill_labels.label(n))} — {_e(n)}"
        f"{' (heavy: grant via governance)' if skill_meta.is_zwaar(n) else ''}</option>"
        for n in kies)
    return (f"<div class='pf'><form method='post' action='/action'>{hid()}"
            f"<label class='att-lbl' for='f-skilllink'>Link a village resource to this commitment</label>"
            f"<select id='f-skilllink' name='skill'>{opts}</select>"
            f"<button class='btn' type='submit' name='action' value='skilllink_add'>"
            f"Link resource</button></form></div>")


def _suggest_for_acc(st: _Stores, role_id: str, acc_id: str, acc_text: str):
    """Welke (AI, skill) past bij deze accountability en is nog niet gekoppeld. Voedt het cadeautje.
    Matching loopt via ai_match (lexicaal + concept + optioneel gecachet LLM-oordeel)."""
    attached = {(t.agent, t.wat) for t in st.ai.for_acc(role_id, acc_id)}
    return ai_match.suggest(st.personas.all(), acc_text, attached, st.match)


def _acc_row(st: _Stores, rec, i: int, text: str, csrf_token: str) -> str:
    """Eén accountability-regel. Is er AI op gekoppeld, dan tonen we dat SUBTIEL (één 🤖-marker,
    klikbaar om te beheren); het 'wat' staat gebundeld in het AI-overzicht onder de rol. Zo niet
    dubbel. Het 🎁 verschijnt alleen als er een passende, nog niet gekoppelde AI-skill is."""
    aid = acc_ids.acc_id_at(rec.definition, i)
    alle = st.ai.for_acc(rec.id, aid)
    tasks = [t for t in alle if t.kind == KIND_AUTONOOM]
    links = [t for t in alle if t.kind == KIND_MIDDEL]
    url = f"/aitask?role={_e(rec.id)}&acc_id={_e(aid)}"
    marker = ""
    if tasks:
        if csrf_token:
            marker = (f"<a class='ai-on js-modal' href='{url}' data-href='{url}' "
                      f"title='AI-empowered — manage'>🤖</a>")
        else:
            marker = "<span class='ai-on' title='AI-empowered'>🤖</span>"
    aff = ""
    if csrf_token and _suggest_for_acc(st, rec.id, aid, text):
        aff = (f"<a class='ai-gift js-modal' href='{url}' data-href='{url}' "
               f"title='An AI skill can carry out this accountability autonomously'>🎁</a>")
    # De middelen onder de belofte: mensentaal voorop, de technische capability klein erachter.
    mid = ""
    if links:
        chips = "".join(f"<span class='chip'>🔗 {_e(skill_labels.label(t.skill))}</span>"
                        f"<span class='muted'> {_e(t.skill)}</span>" for t in links)
        mid = f"<div class='muted'>{chips}</div>"      # bestaande klasse; geen nieuwe CSS
    return (f"<div class='accrow'><div class='acc-text'>{_e(text)}{mid}</div>"
            f"<div class='acc-ai'>{marker}{aff}</div></div>")


def _role_ai_overview(st: _Stores, rec, csrf_token: str = "") -> str:
    """Overzicht (één keer, niet per accountability herhaald): wat doet elke AI autonoom in DEZE rol.
    Gegroepeerd per agent -> per skill de accountabilities die hij dekt."""
    tasks = [t for t in st.ai.for_role(rec.id) if t.kind == KIND_AUTONOOM]
    if not tasks:
        return ""
    by_agent: dict[str, dict[str, list]] = {}
    for t in tasks:
        acc_txt = acc_ids.text_for(rec.definition, t.acc_id) or "—"
        by_agent.setdefault(t.agent, {}).setdefault(t.wat or "—", []).append(acc_txt)
    blocks = ""
    for agent, skills in by_agent.items():
        pa = st.personas.get(agent)
        nm = pa.name if pa else agent
        rows = ""
        for wat, acclist in skills.items():
            uniq = ", ".join(dict.fromkeys(acclist))
            rows += f"<li><b>{_e(wat)}</b> <span class='muted'>· {_e(uniq)}</span></li>"
        manage = ""
        if csrf_token:
            first = acc_ids.acc_id_at(rec.definition, 0)
            url = f"/aitask?role={_e(rec.id)}&acc_id={_e(first)}"
            manage = f" <a class='flink js-modal' href='{url}' data-href='{url}'>manage</a>"
        blocks += (f"<div class='ai-ov'><div class='ai-ov-h'>{_avatar(nm, True)}"
                   f"<b>{_e(nm)}</b> <span class='muted'>does autonomously in this role:</span>{manage}</div>"
                   f"<ul class='clean ai-ov-list'>{rows}</ul></div>")
    return f"<div class='c2-sec'><h3>AI in this role</h3>{blocks}</div>"


def _epic_earth_html() -> str:
    """Live NASA-EPIC-aardbol: de laatste frames gestapeld, met een klein script dat ze traag
    doorloopt (zachte draaiing), plus een UTC-onderschrift. Alleen bestaande + de goedgekeurde
    .epic-* klassen, geen inline styles. Fail-closed: geen frames → nette melding."""
    frames = epic.latest_frames()
    if not frames:
        return "<div class='card muted'>Live earth image (NASA EPIC) is briefly unavailable.</div>"
    imgs = "".join(
        f"<img class='epic-frame{' on' if i == len(frames) - 1 else ''}' "
        f"src='/epic/frame?image={_e(f['image'])}&date={_e(f['date'])}' "
        f"data-cap='{_e(f['caption'])} UTC' alt='Earth from NASA EPIC (DSCOVR)' loading='lazy'>"
        for i, f in enumerate(frames))
    cap0 = f"{_e(frames[-1]['caption'])} UTC"
    # Wachtindicator: draaiende 🌍 + tekst, zichtbaar tot het beeld binnen is (JS zet .loaded op load).
    loader = ("<div class='epic-loading'><span class='epic-globe' aria-hidden='true'>🌍</span>"
              "<span class='epic-load-txt'>Mother Earth is loading…</span></div>")
    js = ("<script>(function(){var w=document.currentScript.parentNode;"
          "var earth=w.querySelector('.epic-earth');"
          "var on=earth?earth.querySelector('.epic-frame.on'):null;"
          "function done(){if(earth)earth.classList.add('loaded');}"
          "if(on){if(on.complete)done();else{on.addEventListener('load',done);on.addEventListener('error',done);}}"
          "else{done();}"
          "var fr=w.querySelectorAll('.epic-frame'),cap=w.querySelector('.epic-cap');"
          "if(fr.length<2)return;var i=fr.length-1;"
          "setInterval(function(){fr[i].classList.remove('on');i=(i+1)%fr.length;"
          "fr[i].classList.add('on');if(cap)cap.textContent='Live: '+fr[i].getAttribute('data-cap');},5000);"
          "})();</script>")
    return (f"<div class='epic-earth'>{loader}{imgs}</div>"
            f"<div class='epic-cap'>Live: {cap0}</div>{js}")


def _overview_html(st: _Stores, rec, csrf_token: str = "") -> str:
    d = rec.definition
    is_c = org.is_circle(rec)
    parts = [f"<div class='c2-sec'><h3>Purpose</h3><div>{_e(d.purpose) or '<span class=muted>—</span>'}</div></div>"]
    if is_c:
        # Strategie geïntegreerd in overview (aparte strategy-tab vervallen). Purpose staat
        # hierboven al → chain overslaan.
        parts.append(_strategy_tab_html(st, rec, with_purpose_chain=False))
    doms = d.domains or []
    doms_list = ("<ul class='clean'>" + "".join(f"<li>{_e(x)}</li>" for x in doms) + "</ul>") if doms else ""
    if not getattr(rec, "parent", None):     # anchor (Mother Earth) → live aardbol; geen "Geen domein."
        domains_inner = _epic_earth_html() + doms_list
    else:
        domains_inner = doms_list or "<span class='muted'>No domain.</span>"
    parts.append(f"<div class='c2-sec'><h3>Domains</h3>{domains_inner}</div>")
    accs = d.accountabilities or []
    if not is_c:
        parts.append("<div class='c2-sec'><h3>Accountabilities</h3>"
                     + ("".join(_acc_row(st, rec, i, a, csrf_token) for i, a in enumerate(accs))
                        if accs else "<span class='muted'>No accountabilities.</span>") + "</div>")
        parts.append(_role_ai_overview(st, rec, csrf_token))
    elif accs:
        parts.append("<div class='c2-sec'><h3>Accountabilities</h3><ul class='clean'>"
                     + "".join(f"<li>{_e(x)}</li>" for x in accs) + "</ul></div>")
    if not is_c:
        parts.append(f"<div class='c2-sec'><h3>Role Fillers</h3>{_filler_html(st, rec.id, rec)}</div>")
    return "".join(parts)


def _fillsummary(st: _Stores, rec) -> str:
    fs = st.assign.fillers_of(rec.id, record=rec)
    if not fs:
        return "— not filled"
    names = []
    for f in fs:
        if f.type == "person":
            p = st.people.get(f.id); names.append(p.name if p else f.id)
        else:
            names.append("AI")
    return "· " + ", ".join(names)


_CORE_ROLE_NAMES = {"circle lead", "lead link", "facilitator", "secretary", "secretaris",
                    "rep link", "circle rep", "cross link"}


# Genderneutraal 'persoon + toevoegen'-icoon (silhouet + plus), kleurt mee met currentColor.
_ICON_ADD_PERSON = (
    "<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' "
    "stroke-width='2' stroke-linecap='round' stroke-linejoin='round' aria-hidden='true'>"
    "<circle cx='9' cy='8' r='3.2'/>"
    "<path d='M3.5 20c0-3.2 2.5-5.6 5.5-5.6s5.5 2.4 5.5 5.6'/>"
    "<path d='M18.5 8.5v5M16 11h5'/></svg>")

# Reactie toevoegen: neutrale lijn-smiley met plus (zelfde stijl als persoon-toevoegen).


def _fillers_block(st: _Stores, role) -> str:
    """Rechts uitgelijnde rolvervullers; bij 3+ gestapelde avatars + '+ nog N'."""
    fillers = st.assign.fillers_of(role.id, record=role)
    resolved = []
    for f in fillers:
        if f.type == "person":
            p = st.people.get(f.id)
            resolved.append((p.name if p else f.id, False, f.id))
        else:
            pa = st.personas.get(f.id)
            resolved.append(((pa.name if pa else f.id), True, f.id))
    if not resolved:
        return "<span class='muted' style='font-size:.8rem'>not filled</span>"
    if len(resolved) >= 3:
        avs = "".join(f"<span class='stack-av'>{_avatar(n, ai)}</span>" for n, ai, fid in resolved[:3])
        extra = f"<span class='muted' style='font-size:.82rem'>+ {len(resolved)-3} more</span>" if len(resolved) > 3 else ""
        return f"<div class='fillers stack'>{avs}{extra}</div>"
    rows = ""
    for n, ai, fid in resolved:
        # De AI-inwoner is nu een klikbaar dossier i.p.v. platte tekst — dat is de ingang
        # naar /inwoner vanaf de rol-pagina.
        nm = (f"<a href='/person?id={_e(fid)}'>{_e(n)}</a>" if not ai
              else f"<a href='/inwoner?id={_e(fid)}'>{_e(n)}</a> (AI)")
        rows += f"<div class='fperson'>{_avatar(n, ai)}<span>{nm}</span></div>"
    return f"<div class='fillers'>{rows}</div>"


def _role_row(st: _Stores, role, csrf_token: str) -> str:
    purpose = role.definition.purpose or ""
    pur = f"<div class='muted rrole-pur'>{_e(purpose)}</div>" if purpose else ""
    assign = ""
    if csrf_token:
        url = f"/rolefillers?role={_e(role.id)}"
        assign = (f"<a class='manage-ico js-modal' href='{url}' data-href='{url}' "
                  f"title='manage role fillers'>{_ICON_ADD_PERSON}</a>")
    return (f"<div class='rrole'>"
            f"<div class='rrole-info'><a href='/node?id={_e(role.id)}'>{_e(_name(role))}</a>{pur}</div>"
            f"<div class='rrole-fill'>{_fillers_block(st, role)}</div>"
            f"<div class='rrole-act'>{assign}</div></div>")


def _roles_html(st: _Stores, rec, csrf_token: str = "") -> str:
    recs = st.records.all()
    subs = sorted(org.subcircles_of(recs, rec.id), key=lambda r: _name(r).lower())
    roles = sorted(org.roles_of(recs, rec.id), key=lambda r: _name(r).lower())
    core = [r for r in roles if _name(r).strip().lower() in _CORE_ROLE_NAMES]
    rest = [r for r in roles if _name(r).strip().lower() not in _CORE_ROLE_NAMES]
    out = []
    if core:
        out.append("<div class='c2-sec'><h3>Core roles</h3>"
                   + "".join(_role_row(st, r, csrf_token) for r in core) + "</div>")
    out.append("<div class='c2-sec'><h3>Roles</h3>"
               + ("".join(_role_row(st, r, csrf_token) for r in rest)
                  if rest else "<span class='muted'>No roles.</span>") + "</div>")
    if subs:
        out.append("<div class='c2-sec'><h3>Subcircles</h3><ul class='clean'>"
                   + "".join(f"<li><a href='/node?id={_e(s.id)}'>{_e(_name(s))}</a> "
                             f"<span class='chip'>circle</span></li>" for s in subs) + "</ul></div>")
    return "".join(out)


def _members_html(st: _Stores, rec, csrf_token: str = "") -> str:
    # Deelnemerbeheer (toevoegen/verwijderen/wijzigen) zit op de admin-pagina (/admin),
    # niet hier. Members toont alleen wie deze cirkel vervullen.
    ppl = _members_of_circle(st, rec.id)
    admin = ("<p class='muted' style='font-size:.8rem;margin-top:.8rem'>"
             "Add or manage people? → <a href='/admin'>People (admin)</a></p>"
             if csrf_token else "")
    if not ppl:
        return ("<div class='c2-sec'><h3>Members</h3><span class='muted'>No people.</span>"
                f"{admin}</div>")
    cells = "".join(
        f"<div class='card'><span class='person'><span class='av'>{_e(_initials(p.name))}</span>"
        f"<a href='/person?id={_e(p.id)}'>{_e(p.name)}</a></span></div>" for p in ppl)
    return f"<div class='c2-sec'><h3>Members ({len(ppl)})</h3>{cells}{admin}</div>"


def render_admin(st: _Stores, csrf_token: str = "", msg: str = "") -> str:
    """Admin-pagina 'Deelnemers': mensen toevoegen, wijzigen (naam/e-mail), wachtwoord
    resetten en verwijderen. Login vereist (route niet publiek). Eén plek voor people-beheer,
    los van de Members-tab van een cirkel."""
    people = st.people.all()
    rw = bool(csrf_token)

    def _status(p):
        if getattr(p, "last_login", 0):
            return f"<span class='chip green'>active</span> <span class='muted'>· {_e(_age(p.last_login))}</span>"
        if getattr(p, "password_hash", ""):
            return "<span class='chip outline'>invited</span>"
        return "<span class='chip muted'>no access</span>"

    rows = ""
    for p in people:
        nrol = len(st.assign.roles_of("person", p.id))
        if rw:
            edit = (
                f"<form method='post' action='/action' class='fieldform' style='gap:.4rem'>"
                f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
                f"<input type='hidden' name='pid' value='{_e(p.id)}'>"
                f"<input type='hidden' name='next' value='/admin'>"
                f"<input type='text' name='name' value='{_e(p.name)}' aria-label='name'>"
                f"<input type='email' name='email' value='{_e(p.email)}' aria-label='email'>"
                f"<button class='btn ok sm' type='submit' name='action' value='person_edit'>save</button>"
                f"</form>")
            pw = (f"<form method='post' action='/action' style='display:inline'>"
                  f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
                  f"<input type='hidden' name='pid' value='{_e(p.id)}'>"
                  f"<button class='btn sm' type='submit' name='action' value='person_reset_password'>"
                  f"reset password</button></form>")
            warn = (f" — also removes {nrol} role assignment(s)" if nrol else "")
            rm = (f"<form method='post' action='/action' style='display:inline'>"
                  f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
                  f"<input type='hidden' name='pid' value='{_e(p.id)}'>"
                  f"<input type='hidden' name='next' value='/admin'>"
                  f"<button class='dellink' type='submit' name='action' value='person_remove' "
                  f"onclick=\"return confirm('Delete {_e(p.name)}?{warn}')\">delete</button></form>")
            actions = f"<div class='admin-act'>{pw} {rm}</div>"
        else:
            edit = f"<b>{_e(p.name)}</b> <span class='muted'>· {_e(p.email) or 'no email'}</span>"
            actions = ""
        rows += (f"<div class='admin-row'><div class='admin-main'>{edit}</div>"
                 f"<div class='admin-meta'>{_status(p)} <span class='muted'>· {nrol} role(s)</span>"
                 f"{actions}</div></div>")

    add = ""
    if rw:
        add = (
            f"<details class='c2-add' open style='margin-bottom:1rem'>"
            f"<summary style='cursor:pointer;font-weight:600'>+ Add person</summary>"
            f"<form method='post' action='/action' style='margin-top:.75rem;display:grid;gap:.5rem;max-width:380px'>"
            f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
            f"<input type='hidden' name='action' value='person_add'>"
            f"<input type='hidden' name='next' value='/admin'>"
            f"<input type='text' name='voornaam' placeholder='First name' required>"
            f"<input type='text' name='achternaam' placeholder='Last name' required>"
            f"<input type='email' name='email' placeholder='Email address' required>"
            f"<button class='btn ok' type='submit'>Add</button>"
            f"</form></details>")

    css = ("<style>"
           ".admin-row{display:flex;justify-content:space-between;align-items:center;gap:1rem;"
           "flex-wrap:wrap;padding:.55rem 0;border-bottom:1px solid var(--border)}"
           ".admin-main{flex:1 1 340px;min-width:0}"
           ".admin-main .fieldform input[name=name]{flex:0 1 11rem}"
           ".admin-main .fieldform input[name=email]{flex:1 1 13rem}"
           ".admin-meta{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;font-size:.85rem}"
           ".admin-act{display:inline-flex;gap:.4rem;margin-left:.4rem}"
           "</style>")
    main = (f"<div class='c2-main'><div class='c2-bar'><a href='/'>← home</a></div>"
            f"<h1>People <span class='chip'>admin</span></h1>"
            # Mensen staan hier; de AI-inwoners hebben hun eigen dossier-overzicht.
            f"<p class='muted'><a href='/inwoners'>→ Inhabitants (AI personas)</a> · "
            f"<a href='/founder'>→ Founder Flow (autonomy training loop)</a></p>{_banner(msg)}"
            f"<p class='muted'>Add, edit, reset password or remove people. "
            f"This page requires login.</p>{add}"
            f"<div class='c2-sec'><h3>People ({len(people)})</h3>{rows or '<span class=muted>No one yet.</span>'}</div></div>")
    inner = (f"{_DS_LINK}{css}"
             f"{_nav()}"
             f"<div class='c2-wrap'>{main}</div>")
    return _page("People — admin", inner)


def _att_html(st: _Stores, rec, kind: str, leeg: str) -> str:
    items = st.att.list(rec.id, kind)
    if not items:
        return (f"<p class='muted'>{_e(leeg)}</p>"
                "<p class='muted' style='font-size:.8rem'>Storage already works; entry/display "
                "(and the meeting link) is still to come.</p>")
    out = "<ul class='clean'>"
    for a in items:
        meta = ""
        if a.meta:
            meta = " <span class='pill'>" + _e(", ".join(f"{k}: {v}" for k, v in a.meta.items())) + "</span>"
        out += f"<li><b>{_e(a.title) or '—'}</b>{meta}<br><span class='muted'>{_e(a.body)}</span></li>"
    return out + "</ul>"

# ── Artefact-tabs (Notes / Policies / Tools) ────────────────────────────────
# Twee secties per tab: "Van deze rol" (eigen artefacten, edit alleen voor de vervuller) en
# "Geldend hier" (geërfd + governance-owned, read-only met herkomst). Alles afgeleid uit de
# domein-/erf-query (artefacts.own_and_inherited); niks handmatig gecureerd.
_KIND_ICON = {"note": "📄", "policy": "📜", "tool": "🛠"}
_KIND_LABEL = {"note": "Note", "policy": "Policy", "tool": "Tool"}
_KIND_TAB = {"note": "notes", "policy": "policies", "tool": "tools"}


def _tab_for(kind: str) -> str:
    return _KIND_TAB.get(kind, "notes")


def _dt(ts) -> str:
    try:
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(float(ts)))
    except (TypeError, ValueError):
        return "—"


def _can_edit_artefacts(st: _Stores, rec, csrf_token: str, username: str | None) -> bool:
    """Mag de huidige kijker artefacten van deze rol bewerken? Vereist een schrijf-sessie
    (csrf_token) én — via can_write_artefact — vervuller of Circle Lead zijn. "guest" (auth uit)
    mag alles, net als in de rest van de cockpit."""
    if not csrf_token:
        return False
    if username == "guest":
        return True
    actor = st.people.by_email(username) if username else None
    return bool(actor) and artefacts.can_write_artefact("person", actor.id, rec.id, st.records, st.assign)


def _artefact_versions_html(a) -> str:
    vs = getattr(a, "versions", None) or []
    if not vs:
        return ""
    rows = ""
    for v in vs:
        gref = f" · gov:{_e(v['governance_ref'])}" if v.get("governance_ref") else ""
        rows += (f"<li><span class='muted'>v{v.get('version_nr')} · {_dt(v.get('ts'))} · "
                 f"{_e(v.get('actor_id') or '—')} · {_e(v.get('change_note') or '')}{gref}</span></li>")
    return (f"<details class='c2-hist'><summary class='muted'>"
            f"historie ({len(vs)})</summary><ul class='clean'>{rows}</ul></details>")


def _domain_field(domains: list) -> str:
    """Domein-keuze voor een policy-add-form. Eén domein → vaste regel (hidden input, geen dropdown);
    twee of meer → een select. Bron: de écht via governance toegewezen `definition.domains`."""
    if len(domains) == 1:
        d = domains[0]
        return (f"<label class='att-lbl'>Domain</label>"
                f"<div class='muted'>{_e(d)}</div>"
                f"<input type='hidden' name='domain' value='{_e(d)}'>")
    opts = "".join(f"<option value='{_e(d)}'>{_e(d)}</option>" for d in domains)
    return f"<label class='att-lbl'>Domain</label><select name='domain'>{opts}</select>"


def _artefact_add_form(rec, kind: str, csrf_token: str, domains: list | None = None) -> str:
    dom = _domain_field(domains or []) if kind == "policy" else ""
    urlf = (f"<label class='att-lbl'>URL</label>"
            f"<input type='url' name='url' placeholder='https://…'>" if kind == "tool" else "")
    return (f"<details class='qadd qadd-top'><summary>+ Add {_e(_KIND_LABEL[kind])}</summary>"
            f"<form method='post' action='/action' class='qadd-form'>"
            f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
            f"<input type='hidden' name='owner' value='{_e(rec.id)}'>"
            f"<input type='hidden' name='kind' value='{_e(kind)}'>"
            f"<input type='hidden' name='next' value='/node?id={_e(rec.id)}&tab={_tab_for(kind)}'>"
            f"<label class='att-lbl'>Title</label><input name='title' required>"
            f"{dom}"
            f"<label class='att-lbl'>Body</label>{md_editor('body')}"
            f"{urlf}"
            f"<div class='qadd-row'>"
            f"<button class='btn ok' type='submit' name='action' value='artefact_add'>Add</button>"
            f"<button type='button' class='qadd-x' onclick=\"this.closest('details').open=false\" "
            f"aria-label='cancel'>✕</button></div></form></details>")


def _artefact_edit_form(a, csrf_token: str) -> str:
    urlf = (f"<label class='att-lbl'>URL</label>"
            f"<input type='url' name='url' value='{_e(a.url)}'>" if a.kind == "tool" else "")
    return (f"<details class='qadd'><summary class='muted'>edit</summary>"
            f"<form method='post' action='/action' class='qadd-form'>"
            f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
            f"<input type='hidden' name='aid' value='{_e(a.id)}'>"
            f"<input type='hidden' name='next' value='/node?id={_e(a.anchor)}&tab={_tab_for(a.kind)}'>"
            f"<label class='att-lbl'>Title</label><input name='title' value='{_e(a.title)}'>"
            f"<label class='att-lbl'>Body</label>{md_editor('body', a.body)}"
            f"{urlf}"
            f"<div class='qadd-row'>"
            f"<button class='btn ok sm' type='submit' name='action' value='artefact_edit'>Save</button>"
            f"<button type='button' class='qadd-x' onclick=\"this.closest('details').open=false\" "
            f"aria-label='cancel'>✕</button></div></form></details>")


def _artefact_archive_form(a, csrf_token: str) -> str:
    return (f"<form method='post' action='/action'>"
            f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
            f"<input type='hidden' name='aid' value='{_e(a.id)}'>"
            f"<input type='hidden' name='next' value='/node?id={_e(a.anchor)}&tab={_tab_for(a.kind)}'>"
            f"<button class='dellink' type='submit' name='action' value='artefact_archive' "
            f"onclick=\"return confirm('Archive {_e(a.title or a.id)}?')\">archive</button></form>")


def _laatst_gewijzigd(a) -> str:
    return (f"<div class='muted'>last edited: "
            f"{_dt(getattr(a, 'updated_at', 0))}</div>")


def _artefact_id_chip(a) -> str:
    """Stabiel, verwijsbaar id (policy: {DOMEINSLUG}-{NNN}) als code-chip."""
    return f"<code class='pill'>{_e(a.id)}</code>"


def _artefact_head(a, *, extra: str = "") -> str:
    icon = _KIND_ICON.get(a.kind, "")
    dom = (f" <span class='chip muted'>{_e(a.domain)}</span>"
           if a.kind == "policy" and getattr(a, "domain", "") else "")
    head = f"<div class='ptitle'>{icon} {_artefact_id_chip(a)} {_e(a.title) or _e(a.id)}{dom}{extra}</div>"
    if a.kind == "tool" and a.url:
        head += (f"<div class='muted'>"
                 f"<a href='{_e(a.url)}' target='_blank' rel='noopener'>{_e(a.url)}</a></div>")
    return head


def _artefact_own_card(a, csrf_token: str, can_edit: bool) -> str:
    body = f"<div class='att-body'>{_md(a.body)}</div>" if a.body else ""
    actions = ""
    if can_edit:
        # Bewerk-formulier op volledige kaartbreedte (eigen blok, NIET als smal flex-item in een .qadd-row
        # náást 'archiveren'); 'archiveren' als losse actie eronder.
        actions = (f"{_artefact_edit_form(a, csrf_token)}"
                   f"<div class='qadd-row'>{_artefact_archive_form(a, csrf_token)}</div>")
    return (f"<div class='card'>{_artefact_head(a)}{body}{_laatst_gewijzigd(a)}"
            f"{_artefact_versions_html(a)}{actions}</div>")


def _artefact_inherited_card(it) -> str:
    a = it["artefact"]
    badge = (f" <a class='chip' href='/node?id={_e(it['origin_id'])}&tab={_tab_for(a.kind)}' "
             f"title='click = go to the source role'>via {_e(it['origin_name'])}</a>")
    body = f"<div class='att-body'>{_md(a.body)}</div>" if a.body else ""
    return f"<div class='card'>{_artefact_head(a, extra=badge)}{body}{_laatst_gewijzigd(a)}</div>"


def _artefact_tab_html(st: _Stores, rec, kind: str, csrf_token: str, username: str | None,
                       *, titel: str, leeg: str) -> str:
    can_edit = _can_edit_artefacts(st, rec, csrf_token, username)
    oi = artefacts.own_and_inherited(rec.id, kind, st.records, st.att)

    # Policies zijn geen verbod maar een voorwaarde, en zijn governance-eigendom: één regel boven de
    # lijst i.p.v. een badge/slotje per item.
    kop = ("<p class='muted'>All policies below are "
           "governance-owned.</p>" if kind == "policy" else "")

    own = "".join(_artefact_own_card(a, csrf_token, can_edit) for a in oi["own"])
    own = own or f"<div class='card muted'>{_e(leeg)}</div>"

    add = ""
    if can_edit:
        if kind == "policy":
            # Een policy kan alleen op een domein dat de rol écht via governance bezit.
            domains = list(getattr(rec.definition, "domains", None) or [])
            if domains:
                add = _artefact_add_form(rec, kind, csrf_token, domains)
            else:
                add = ("<div class='card muted'>This role has no domain yet — first assign one "
                       "via governance, then you can create a policy on that domain here.</div>")
        else:
            add = _artefact_add_form(rec, kind, csrf_token)
    sec_own = f"<div class='c2-sec'><h3>From this role</h3>{own}{add}</div>"

    inh = "".join(_artefact_inherited_card(it) for it in oi["inherited"])
    inh = inh or "<div class='card muted'>Nothing applies here from above.</div>"
    sec_inh = (f"<div class='c2-sec'><h3>Applies here</h3>"
               f"<p class='muted'>Inherited from parent roles/circles "
               f"(read-only) — edit at the source.</p>{inh}</div>")
    return f"<h2>{_e(titel)}</h2>{kop}{sec_own}{sec_inh}"


# IA-fase 2: een tool "woont" onder zijn eigenaar-rol. Deze registry hangt de tool-schermen als
# kaart op de Tools-tab van de juiste rol (via Deelnemers → rol → Tools). De schermen blijven losse
# routes; hier maken we ze vindbaar vanuit de rol. In fase 3 worden de keyword-tools rol-lenzen op
# één gedeelde datalaag. Sleutel = record-id van de rol.
# Fase 3: de keyword-tools zijn rol-LENZEN op één gedeelde datalaag (/keywords?lens=…). Elke rol
# ziet dezelfde laag door zijn eigen bril, dus niet vier losse cijferbronnen.
_ROLE_TOOLS = {
    "mother_earth__nooch__marketing_lead": [
        ("Linkbuilding", "Pitch or ignore linkbuilding targets", "/linkbuilding"),
        ("Keywords — volume & direction", "What you make content for", "/keywords?lens=marketing")],
    # De convergentie-check is automatisch (nieuwe woorden dragen 28 dagen een ster op de
    # woordenschat) en signalen zijn ontsloten via de Kennisbank — dus hier alleen nog het
    # ene Library-oppervlak.
    "librarian": [
        ("Library", "Approved words, ranked by opportunity", "/woordenschat"),
        ("Oracle", "What the organization knows — signals and versioned insights", "/kennisbank")],
    "concurrent_scout": [
        ("Keywords — analysis", "Opportunity + suggestions, ranked", "/keywords?lens=trends")],
    "harry_hemp": [
        ("Long-term trends", "Structural rise versus blip (trend reindexing)", "/keywords?lens=scientist")],
    # De claims-toets hoort bij compliance, niet bij de website-rol: cureren van de
    # claims-database en de wekelijkse site-check zijn compliance-domein (claims-database).
    "compliance": [
        ("Claims-checker", "EmpCo/ACM check on text or page — red, orange, green", "/claims")],
}


def _role_tools_html(rec) -> str:
    """De tool-schermen die onder deze rol wonen, als kaarten bovenaan de Tools-tab. Geen
    eigenaar-mapping → lege string (dan toont de tab alleen radar + artefact-tools)."""
    tools = _ROLE_TOOLS.get(getattr(rec, "id", ""), [])
    if not tools:
        return ""
    cards = "".join(
        f"<a class='card' href='{href}'><b>🛠 {_e(label)}</b>"
        f"<div class='muted'>{_e(desc)}</div></a>"
        for label, desc, href in tools)
    return (f"<div class='c2-sec'><h3>This role's tools</h3>"
            f"<div class='tile-grid'>{cards}</div></div>")


def _ritme_html(st: _Stores, rec) -> str:
    """Het terugkerende ritme van deze rol: wat draait er vanzelf, wanneer draaide het laatst,
    en wat kwam eruit.

    Waarom dit blok bestaat: een rol die 'elke week scant' is een belofte. Zonder zichtbare
    laatste run moet je erop vertrouwen. Staat de puls over tijd, dan tonen we DAT — een oude
    datum die er nog netjes uitziet wekt precies het verkeerde vertrouwen."""
    from nooch_village.role_rhythm import ritmes_voor
    ritmes = ritmes_voor(getattr(rec, "id", ""), rec, st.dd)
    if not ritmes:
        return ""
    rijen = ""
    for r in ritmes:
        if r["overtijd"]:
            chip = f"<span class='chip coral'>⚠ {_e(r['overtijd_tekst'])}</span>"
        elif r["laatst"]:
            chip = f"<span class='chip'>{_e(r['laatst'])}</span>"
        else:
            chip = "<span class='chip muted'>not run yet</span>"
        rijen += (f"<div class='c2-sec'><b>{_e(r['naam'])}</b> {chip}"
                  f"<div class='muted'>{_e(r['uitkomst'])}</div></div>")
    return f"<div class='c2-sec'><h3>Recurring rhythm</h3>{rijen}</div>"


def _radar_verwijzing(st: _Stores, rec) -> str:
    """De radar verhuisde van de rol-pagina's naar de centrale Signalen-pagina van de
    library (founder, 19 jul): rollen halen hun informatie voortaan uit de kennisbank
    (kennis-eerst). Voor rollen die een feed hadden blijft hier één rustige verwijzing."""
    if not feeds_for_role(rec.id, st.dd):
        return ""
    return ("<div class='c2-sec'><p class='muted'>🛰 Radar signals now live centrally at "
            "<a href='/signals'>Signals (library)</a>; this role reads its context from the "
            "<a href='/kennisbank'>knowledge base</a>.</p></div>")


def render_node(st: _Stores, node_id: str, tab: str, csrf_token: str = "", msg: str = "",
                group: str = "", clf: str = "due", mw: str = "7d", username: str | None = None,
                van: str = "", tot: str = "", compare: bool = False) -> str:
    rec = st.records.get(node_id)
    if rec is None:
        return _page("Not found", "<p>Node not found.</p><p><a href='/'>← home</a></p>")
    is_c = org.is_circle(rec)
    tabs = _CIRCLE_TABS if is_c else _ROLE_TABS
    if tab not in tabs:
        tab = "overview"
    recs = st.records.all()
    crumb = " › ".join(
        f"<a href='/node?id={_e(i)}'>{_e(_name(st.records.get(i)))}</a>"
        for i in org.breadcrumb(recs, node_id))
    chip = "<span class='chip'>circle</span>" if is_c else "<span class='chip'>role</span>"

    if tab == "overview":
        content = _overview_html(st, rec, csrf_token)
    elif tab == "strategy":
        content = _strategy_tab_html(st, rec)
    elif tab == "roles":
        content = _roles_html(st, rec, csrf_token)
    elif tab == "members":
        content = _members_html(st, rec, csrf_token)
    elif tab == "notes":
        if rec.id == WEBSITE_DEVELOPER_ROLE:
            # De Notes-tab van de Website Developer is de Backlog Builder.
            content = render_backlog_tab(st, rec, csrf_token, username)
        else:
            content = _artefact_tab_html(st, rec, "note", csrf_token, username,
                                         titel="Notes", leeg="No notes on this role/circle yet.")
    elif tab == "tools":
        content = (_role_tools_html(rec)
                   + _ritme_html(st, rec)
                   + _radar_verwijzing(st, rec)
                   + _artefact_tab_html(st, rec, "tool", csrf_token, username,
                                        titel="Tools", leeg="No tools on this role/circle yet."))
    elif tab == "metrics":
        # Het nieuwe metrics-scherm (catalogus + dashboard + segmentatie + vergelijken), ingebed als
        # node-tab. Vervangt het oude _metrics_tab_html; KPI-aanmaken loopt via de rijke composer.
        content = render_metrics2_tab(st, rec, csrf_token, win=mw, compare=compare, van=van, tot=tot)
    elif tab == "checklists":
        content = _checklists_tab_html(st, rec, csrf_token, flt=clf)
    elif tab == "projects":
        content = _projects_tab_html(st, rec, csrf_token, group=group, username=username)
    elif tab == "policies":
        content = _artefact_tab_html(st, rec, "policy", csrf_token, username,
                                     titel="Policies", leeg="No policies on this role/circle yet.")
    else:
        content = ""      # onbekende tab (niet in de tab-lijst) → geen inhoud

    # Meetings zijn een CIRKEL-functie (een rol heeft geen governance/tactical meeting).
    if is_c and csrf_token:
        rov_url = f"/roloverleg2?circle={_e(node_id)}"
        from nooch_village.views.roloverleg import _rov_items
        open_cls = "btn ok" if _rov_items(st, node_id) else "btn"   # groen = lopend roloverleg
        wo_url = f"/werkoverleg?circle={_e(node_id)}"
        wo_cls = "btn ok" if st.werk.is_open(node_id) else "btn"    # groen = lopend werkoverleg
        meet = (f"<div class='c2-meet'>"
                f"<a class='{open_cls} js-modal' href='{rov_url}' data-href='{rov_url}'>Governance meeting</a>"
                f"<a class='{wo_cls} js-modal' href='{wo_url}' data-href='{wo_url}'>Tactical meeting</a></div>")
    else:
        meet = ""
    # Breadcrumb weggehaald (founder 23 jul): de hiërarchie staat al in de organisatieboom-rail rechts.
    main = (f"<div class='c2-main'>"
            f"<h1>{_e(_name(rec))} {chip}</h1>{_banner(msg)}{meet}"
            f"{_tabbar(node_id, tabs, tab)}{content}</div>")
    rail = f"<div class='c2-rail'>{_tree_html(st, node_id)}</div>"
    modal = _modal_html(json.dumps(_mentionables(st)[0])) if csrf_token else ""
    inner = (f"{_DS_LINK}"
             f"{_nav()}"
             f"<div class='c2-wrap'>{main}{rail}</div>{modal}")
    return _page(_name(rec), inner)


def _person_context_tab_html(st: _Stores, filler_type: str, pid: str) -> str:
    """Union van de context-notes (kind='note') over de rollen die deze filler vervult. Eén lijst,
    tools en docs door elkaar, met een visueel onderscheid op subtype (leeg/ontbrekend → 'doc')."""
    rows, total = "", 0
    for rid in sorted(set(st.assign.roles_of(filler_type, pid))):
        orec = st.records.get(rid)
        owner = _e(_name(orec) if orec else rid)
        for a in st.att.list(rid, "note"):
            total += 1
            sub = (getattr(a, "subtype", "") or "doc")
            icon = "🛠" if sub == "tool" else "📄"
            title = _e(a.title or (a.body[:60] if a.body else "(no title)"))
            rows += (f"<li>{icon} <span class='chip muted'>{_e(sub)}</span> {title} "
                     f"<span class='muted'>· {owner}</span></li>")
    body = (f"<ul class='clean'>{rows}</ul>" if rows
            else "<span class='muted'>No context notes on this person's roles.</span>")
    return f"<div class='c2-sec'><h3>Context ({total})</h3>{body}</div>"


def _person_metrics_tab_html(st: _Stores, filler_type: str, pid: str) -> str:
    """Aggregatie-lens: DEZELFDE metric-render als op rol-niveau (het nieuwe metrics-scherm, mét
    grafieken), per rol die deze filler vervult. Read-only, dus geen '+ KPI maken'/data-invoer. Geen
    tweede render — een KPI/grafiek die je op een rol toevoegt, verschijnt hier automatisch
    (reference, not copy)."""
    out = ""
    for rid in sorted(set(st.assign.roles_of(filler_type, pid))):
        rec = st.records.get(rid)
        if rec is None or not st.metrics.tiles_of(rid):
            continue
        base = f"/node?id={_e(rid)}&tab=metrics"
        out += (f"<h4 class='muted'>{_e(_name(rec))}</h4>"
                + render_metrics2_person(st, rec, base))
    if not out:
        return ("<div class='c2-sec'><span class='muted'>No metrics on this person's "
                "roles.</span></div>")
    return out + _METRICS_JS      # één keer de kaart-omdraai-JS voor alle rol-tegels samen


def _person_checklists_tab_html(st: _Stores, filler_type: str, pid: str, csrf: str) -> str:
    """Union van checklists.for_node(rid) over de rollen, gegroepeerd per rol. Hergebruikt _cl_row:
    die toont het target_type-label ("Alle leden" bij all = cirkel-verplichting, de rol bij role) en
    de afvink-form ALLEEN met csrf (conform effective_csrf). Geen per-lid-status; wie afvinkte staat
    in reports.by. Afvinken loopt via cl_report, achter de is_role_filler/Circle-Lead-gate."""
    sections, total = "", 0
    for rid in sorted(set(st.assign.roles_of(filler_type, pid))):
        items = st.checklists.for_node(rid)
        if not items:
            continue
        orec = st.records.get(rid)
        owner = _e(_name(orec) if orec else rid)
        rows = "".join(_cl_row(st, it, csrf) for it in items)
        sections += f"<h4 class='muted' style='margin:.6rem 0 .2rem'>{owner}</h4>{rows}"
        total += len(items)
    body = (sections if sections
            else "<span class='muted'>No checklist items on this person's roles.</span>")
    return f"<div class='c2-sec'><h3>Checklist ({total})</h3>{body}</div>"


def render_person(st: _Stores, pid: str, tab: str = "rollen", username: str | None = None,
                  csrf_token: str = "") -> str:
    """Persoon/AI-role-filler-view: read-only aggregatie-lens over de rollen die iemand vervult,
    met de rol-view-chrome (tabs via _tabbar(base="/person")). Vult rollen/projecten/context; de
    overige tabs zijn read-only placeholders. Geen schrijfacties, geen csrf. `username` = de sessie
    (voor de context-drempel); GEEN persoons-gate — de context-tab hangt op 'is er een sessie',
    niet op 'ben jij deze persoon'. Handelt zowel een mens (people) als een AI-inwoner (personas) af."""
    p = st.people.get(pid)
    if p is not None:
        filler_type, name, subtitle = "person", p.name, (p.email or "no email")
        avatar = f"<span class='av' style='width:28px;height:28px'>{_e(_initials(p.name))}</span>"
        chip = ""
    else:
        pa = st.personas.get(pid)
        if pa is None:
            return _page("Not found", "<p>Person not found.</p><p><a href='/'>← home</a></p>")
        filler_type, name = "persona", pa.name
        subtitle = "AI inhabitant" + (f" · {pa.mbti}" if pa.mbti else "")
        avatar = "<span class='av ai' style='width:28px;height:28px'>AI</span>"
        chip = "<span class='chip'>AI</span>"

    if tab not in _PERSON_TABS:
        tab = "rollen"
    role_ids = st.assign.roles_of(filler_type, pid)

    if tab == "rollen":
        # Eén blok per rol, uitklapbaar (<details>, geen JS) naar de accountabilities van de rol
        # (rec.definition.accountabilities). set() = "toon elke rol één keer", geen dedup-magie.
        uniek = sorted(set(role_ids))
        blocks = ""
        for rid in uniek:
            rec = st.records.get(rid)
            if rec is None:
                continue
            crumb = " › ".join(_e(_name(st.records.get(i)))
                               for i in org.breadcrumb(st.records.all(), rid)[:-1])
            crumb_html = f" <span class='muted'>· {crumb}</span>" if crumb else ""
            accs = rec.definition.accountabilities or []
            acc_html = ("<ul class='clean'>" + "".join(f"<li>{_e(a)}</li>" for a in accs) + "</ul>"
                        if accs else "<span class='muted'>No accountabilities.</span>")
            blocks += (f"<details class='c2-acc'><summary>"
                       f"<a href='/node?id={_e(rid)}'>{_e(_name(rec))}</a>{crumb_html} "
                       f"<span class='muted' style='font-size:.75rem'>· {len(accs)} accountabilities"
                       f"</span></summary>{acc_html}</details>")
        content = (f"<div class='c2-sec'><h3>Roles ({len(uniek)})</h3>"
                   + (blocks if blocks else "<span class='muted'>No roles.</span>") + "</div>")
    elif tab == "projecten":
        # Hergebruikt de kanban-component (_projects_board), gefilterd op mijn rollen; csrf → drag-drop.
        content = _person_projects_tab_html(st, filler_type, pid, csrf_token)
    elif tab == "context":
        # AUTHZ: iedereen-ingelogd — de context-tab is zichtbaar voor elk INGELOGD village-lid, niet
        # voor anonieme guests. Drempel op "is er een sessie", niet op "ben jij deze persoon" (geen
        # persoons-gate). "guest" (auth uit) en geen sessie → geen inhoud.
        if not username or username == "guest":
            content = "<div class='c2-sec'><p class='muted'>Log in to see context.</p></div>"
        else:
            content = _person_context_tab_html(st, filler_type, pid)
    elif tab == "metrics":
        # Read-only union van de rol-metrics; schrijven blijft op rol-niveau (geen knop hier).
        content = _person_metrics_tab_html(st, filler_type, pid)
    elif tab == "checklist":
        # Union van de rol-checklists; afvinken via cl_report achter de is_role_filler-gate.
        # Afvink-form alleen met csrf (effective_csrf) — guest/niet-ingelogd → geen knop.
        content = _person_checklists_tab_html(st, filler_type, pid, csrf_token)
    else:
        content = ("<div class='c2-sec'><p class='muted'>Read-only aggregation lens over the roles "
                   "this person fills. This tab follows in a separate task.</p></div>")

    main = (f"<div class='c2-main'><h1>{avatar} {_e(name)} {chip}</h1>"
            f"<div class='muted'>{_e(subtitle)}</div>"
            f"{_tabbar(pid, _PERSON_TABS, tab, base='/person')}{content}</div>")
    rail = f"<div class='c2-rail'>{_tree_html(st, '')}</div>"
    # Kaart-klik op het kanban-bord opent de project-detail-modal, net als op de node-view.
    modal = _modal_html(json.dumps(_mentionables(st)[0])) if csrf_token else ""
    inner = (f"{_DS_LINK}"
             f"{_nav()}"
             f"<div class='c2-wrap'>{main}{rail}</div>{modal}")
    return _page(name, inner)


def render_patterns(csrf_token: str = "") -> str:
    """Levende styleguide: elk atoom/molecuul één keer. Bron van waarheid; geen losse varianten."""
    def sec(title, body):
        return f"<div class='c2-sec'><h3>{_e(title)}</h3><div style='display:flex;gap:.5rem;flex-wrap:wrap;align-items:center'>{body}</div></div>"
    buttons = ("<button class='btn ok'>Primary</button>"
               "<button class='btn'>Neutral</button>"
               "<button class='btn no'>Danger</button>"
               "<button class='btn ok sm'>Primary sm</button>"
               "<button class='btn sm'>Neutral sm</button>"
               "<button class='btn ghost sm'>Ghost sm</button>"
               "<a class='dellink' href='#'>delete</a>")
    chips = ("<span class='chip green'>green</span><span class='chip muted'>muted</span>"
             "<span class='chip outline'>outline</span><span class='chip coral'>coral</span>"
             "<span class='chip coral-solid'>Overdue</span><span class='chip'>tint (default)</span>"
             "<span class='badge ro'>read</span><span class='badge rw'>edit</span>")
    cards = (f"<button class='acard'>{_IC_CLOCK}<span>Date</span></button>"
             f"<button class='acard'>{_IC_CHECK}<span>Checklist</span></button>"
             f"<button class='acard acard-off' disabled>{_IC_TARGET}<span>Goals</span></button>")
    att = f"<div class='attcard'><span class='att-ic'>{_IC_LINK}</span><a class='att-name' href='#'>example attachment</a></div>"
    due = (f"<span class='chip outline'>{_IC_CLOCK}25 Jun 2026</span>"
           f"<span class='chip coral'>{_IC_CLOCK}1 Jan 2020</span><span class='chip coral-solid'>Overdue</span>")
    av = _avatar("Stefan Wobben", False) + _avatar("Codie", True)
    icons = (f"<span class='manage-ico' title='add person'>{_ICON_ADD_PERSON}</span>"
             f"<span class='manage-ico' title='add reply'>{_ICON_ADD_EMOJI}</span>")
    body = (sec("Buttons — atom: .btn [.ok|.no] [.sm] [.ghost] + .dellink", buttons)
            + sec("Line icons (neutral, currentColor)", icons)
            + sec("Status & chips & badges", chips)
            + sec("Action-cards (molecule)", cards)
            + sec("Attachment card", att)
            + sec("Deadline-chip", due)
            + sec("Avatar", av))
    main = (f"<div class='c2-main'><h1>Patterns</h1>"
            f"<p class='muted'>Living reference. Use these atoms and molecules; don't invent variants.</p>{body}</div>")
    inner = (f"{_DS_LINK}"
             f"{_nav('patterns')}"
             f"<div class='c2-wrap'>{main}</div>")
    return _page("Patterns", inner)




def render_rolefillers(st: _Stores, role_id: str, csrf_token: str = "", fragment: bool = False) -> str:
    rec = st.records.get(role_id)
    if rec is None:
        return ("<p class='muted'>Unknown role.</p>" if fragment
                else _page("Not found", "<p>Unknown.</p>"))
    back = f"/node?id={(rec.parent or rec.id)}&tab=roles"

    def hid():
        return (f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
                f"<input type='hidden' name='role' value='{_e(role_id)}'>"
                f"<input type='hidden' name='next' value='{_e(back)}'>")

    fillers = st.assign.fillers_of(role_id, record=rec)
    rows = ""
    for f in fillers:
        if f.type == "person":
            p = st.people.get(f.id); label = (p.name if p else f.id); ai = False
            name = f"<a href='/person?id={_e(f.id)}'>{_e(label)}</a>"
        else:
            pa = st.personas.get(f.id); label = (pa.name if pa else f.id); ai = True
            name = f"{_e(label)} (AI)"
        prev = f" <span class='muted' style='font-size:.8rem'>· {_e(f.focus)}</span>" if f.focus else ""
        rows += (
            f"<div class='frow'>"
            f"<details class='ffocus' style='flex:1'>"
            f"<summary>{_avatar(label, ai)} {name}{prev}</summary>"
            f"<form method='post' action='/action' style='margin:.3rem 0 .2rem 30px'>{hid()}"
            f"<input type='hidden' name='filler' value='{f.type}:{_e(f.id)}'>"
            f"<input name='focus' value='{_e(f.focus)}' placeholder='Focus (optional)' "
            f"style='padding:.3rem .4rem;border:1px solid var(--border);border-radius:var(--radius)'> "
            f"<button class='btn' type='submit' name='action' value='role_focus'>Save focus</button>"
            f"</form></details>"
            f"<form method='post' action='/action' style='display:inline'>{hid()}"
            f"<input type='hidden' name='filler' value='{f.type}:{_e(f.id)}'>"
            f"<button class='dellink' type='submit' name='action' value='role_unassign'>remove</button>"
            f"</form></div>")
    if not rows:
        rows = "<p class='muted'>No one assigned yet.</p>"
    # Alleen mensen vervullen een rol; AI koppel je per accountability (niet hier).
    opts = "<option value=''>— pick person —</option>"
    opts += "".join(f"<option value='person:{_e(p.id)}'>{_e(p.name)}</option>" for p in st.people.all())
    add = (f"<div class='pf' style='margin-top:.6rem'><form method='post' action='/action'>{hid()}"
           f"<label>Add to {_e(_name(rec))}</label>"
           f"<select name='filler'>{opts}</select>"
           f"<button class='btn ok' type='submit' name='action' value='role_assign' "
           f"style='margin-top:.4rem'>Assign</button></form></div>")
    frag = (f"<h2 style='margin-top:0'>Manage role fillers — {_e(_name(rec))}</h2>"
            f"<div>{rows}</div>{add}")
    if fragment:
        return frag
    main = (f"<div class='c2-main' style='max-width:560px'>"
            f"<div class='c2-bar'><a href='{_e(back)}'>← back</a></div>{frag}</div>")
    return _page("Role fillers", f"{_DS_LINK}<div class='c2-wrap'>{main}</div>")


def render_aitask(st: _Stores, role_id: str, acc_id: str, csrf_token: str = "",
                  fragment: bool = False) -> str:
    rec = st.records.get(role_id)
    acc_text = acc_ids.text_for(rec.definition, acc_id) if rec else ""
    back = f"/node?id={role_id}&tab=overview"

    def hid():
        return (f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
                f"<input type='hidden' name='role' value='{_e(role_id)}'>"
                f"<input type='hidden' name='acc_id' value='{_e(acc_id)}'>"
                f"<input type='hidden' name='next' value='{_e(back)}'>")

    def pickform(agent: str, skill: str, label: str, cls: str) -> str:
        return (f"<form method='post' action='/action' style='display:inline'>{hid()}"
                f"<input type='hidden' name='pick' value='{_e(agent)}::{_e(skill)}'>"
                f"<button class='{cls}' type='submit' name='action' value='aitask_add'>{label}</button></form>")

    # 1) Voorgesteld: (AI, skill) die lexicaal bij deze accountability past (het cadeautje).
    sugg = _suggest_for_acc(st, role_id, acc_id, acc_text)
    sugg_html = ""
    if sugg:
        items = "".join(f"<div class='frow'><span style='flex:1'>🤖 {_e(p.name)} · {_e(sk)}</span>"
                        f"{pickform(p.id, sk, 'link', 'btn ok')}</div>" for p, sk in sugg)
        sugg_html = (f"<div class='sugg'><div class='sugg-h'>🎁 Suggested</div>{items}</div>")

    # 2) Al gekoppeld: verwijderbaar. Autonome AI-taken en dorpsmiddelen delen dezelfde
    #    verwijder-route; het chip-label verschilt.
    def delform(tid: str) -> str:
        return (f"<form method='post' action='/action' style='display:inline'>"
                f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
                f"<input type='hidden' name='tid' value='{_e(tid)}'>"
                f"<input type='hidden' name='next' value='{_e(back)}'>"
                f"<button class='dellink' type='submit' name='action' value='aitask_remove'>remove</button>"
                f"</form>")

    rows = ""
    for t in st.ai.for_acc(role_id, acc_id):
        chip = _link_chip(t) if t.kind == KIND_MIDDEL else _ai_chip(st, t)
        rows += (f"<div class='frow'><span style='flex:1'>{chip}</span>{delform(t.id)}</div>")

    # 2b) Middelen koppelen: registry-skills die deze rol nog niet voert. De domeinpoort filtert
    #     beslis-skills weg bij een rol die het domein niet houdt — geen uitzonderingsroute.
    middel = _middel_picker(st, rec, role_id, acc_id, hid)

    # 3) Selecteren uit een rugzakje (geen vrije tekst): combinaties AI · skill, niet al gekoppeld.
    personas = st.personas.all()
    attached = {(t.agent, t.wat) for t in st.ai.for_acc(role_id, acc_id)}
    combos = [(p, sk) for p in personas for sk in (p.skills or []) if (p.id, sk) not in attached]
    if combos:
        opts = "".join(f"<option value='{_e(p.id)}::{_e(sk)}'>🤖 {_e(p.name)} · {_e(sk)}</option>"
                       for p, sk in combos)
        select = (f"<div class='pf'><form method='post' action='/action'>{hid()}"
                  f"<label>Pick a skill from an AI's backpack</label>"
                  f"<select name='pick'>{opts}</select>"
                  f"<button class='btn ok' type='submit' name='action' value='aitask_add' "
                  f"style='margin-top:.4rem'>Link</button></form></div>")
    elif personas:
        select = "<p class='muted'>All AI skills are already linked here, or the backpacks are empty.</p>"
    else:
        select = ("<p class='muted'>There are no AI inhabitants yet. Create one first, "
                  "then you can link a skill.</p>")

    # 4) Rugzak uitbreiden (set-up): een nieuwe skill aan een AI toevoegen.
    bag = ""
    if personas:
        popts = "".join(f"<option value='{_e(p.id)}'>🤖 {_e(p.name)}</option>" for p in personas)
        bag = (f"<details class='bagadd'><summary>Expand an AI's backpack</summary>"
               f"<form method='post' action='/action'>"
               f"<input type='hidden' name='csrf' value='{_e(csrf_token)}'>"
               f"<input type='hidden' name='next' value='{_e(back + '&_aitask=' + acc_id)}'>"
               f"<label>AI inhabitant</label><select name='agent'>{popts}</select>"
               f"<label>New skill</label><input name='skill' placeholder='e.g. writes the code'>"
               f"<button class='btn' type='submit' name='action' value='persona_skill_add' "
               f"style='margin-top:.4rem'>Add to backpack</button></form></details>")

    frag = (f"<h2 style='margin-top:0'>AI on this accountability</h2>"
            f"<p class='muted'>Accountability: {_e(acc_text) or '—'}</p>"
            f"<p style='font-size:.82rem;color:var(--gray)'>The human stays responsible; the AI "
            f"autonomously runs a skill from its backpack. You type nothing, you "
            f"<b>select</b> a skill.</p>{sugg_html}{rows}{middel}{select}{bag}")
    if fragment:
        return frag
    main = (f"<div class='c2-main' style='max-width:560px'>"
            f"<div class='c2-bar'><a href='{_e(back)}'>← back</a></div>{frag}</div>")
    return _page("AI on accountability", f"{_DS_LINK}<div class='c2-wrap'>{main}</div>")

