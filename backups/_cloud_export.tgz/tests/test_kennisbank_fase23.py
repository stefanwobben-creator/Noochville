"""Kennisbank fase 2 (intake) en fase 3 (het spel) — alles met een fake reason_fn,
geen netwerk. De principes die hier vastliggen: intake blijft dom (geen trust van de
LLM), idempotent op hash(content+bron) — zelfde claim uit een ándere bron blijft een
aparte stem — en het spel munt via de bestaande fase-1 functies (versie-bump, history)."""
from __future__ import annotations

import json

import pytest

from nooch_village.kennisbank import KennisbankStore
from nooch_village.kennisbank_intake import (build_intake_prompt, parse_intake,
                                             stable_id, intake, SUBJECTS)
from nooch_village.kennisbank_spel import (SpelStore, clusters, gather, ongebonden,
                                           spel_finish, steun_onafhankelijk, subject_van)
from nooch_village.notes_store import NotesStore


# ── fase 2: intake ───────────────────────────────────────────────────────────

_LLM_ATOMS = [
    {"content": "Leer en wol zouden veeteelt winstgevend maken (betwist).",
     "subject": "leer", "provenance": "advocacy", "source": "Patched-column",
     "flags": [], "link_hints": ["ethiek"]},
    {"content": "PETA (Camilli): wolschapen gaan na jaren alsnog naar de slacht.",
     "subject": "wol", "provenance": "advocacy", "source": "Patched-column, quote PETA",
     "flags": ["quote"], "link_hints": []},
    {"content": "Eén studie: 90% van looierij-arbeiders sterft voor hun 50e.",
     "subject": "ethiek", "provenance": "media", "source": "Patched-column, 'one study'",
     "flags": ["verificatie_vereist"], "link_hints": []},
    {"content": "Iets zonder herkenbaar onderwerp.", "subject": "iets-nieuws",
     "provenance": "gevoel", "source": "x", "flags": ["raar"], "link_hints": []},
]


def _fake_reason(prompt, **kw):
    return json.dumps(_LLM_ATOMS)


@pytest.mark.smoke
def test_intake_idempotent_en_dom(tmp_path):
    dd = str(tmp_path)
    nieuw, dubbel = intake("ruwe column", "Patched", dd, reason_fn=_fake_reason)
    assert len(nieuw) == 4 and dubbel == 0
    # re-run: NIETS dubbel, en de LLM wordt niet eens meer geraakt (input-ledger) —
    # dit vangt ook LLM-non-determinisme af (zelfde input, nét andere splitsing)
    def _boem(*a, **k):
        raise AssertionError("LLM mag bij identieke input niet opnieuw draaien")
    nieuw2, dubbel2 = intake("ruwe column", "Patched", dd, reason_fn=_boem)
    assert nieuw2 == [] and dubbel2 == 4

    notes = NotesStore(f"{dd}/notes.json")
    kaarten = {n.id: n for n in notes.all()}
    assert len(kaarten) == 4
    quote = next(n for n in kaarten.values() if "PETA" in n.claim)
    assert "quote" in quote.tags and subject_van(quote.model_dump()) == "wol"
    negentig = next(n for n in kaarten.values() if "90%" in n.claim)
    assert "verificatie_vereist" in negentig.tags
    # validator fail-closed: onbekend subject → ongesorteerd; onbekende provenance → unknown
    los = next(n for n in kaarten.values() if "zonder herkenbaar" in n.claim)
    assert subject_van(los.model_dump()) == "" and los.provenance == "unknown"
    assert "raar" not in los.tags
    # intake is dom: geen veld/zekerheid op de kaart
    for n in kaarten.values():
        assert not hasattr(n, "trust") or getattr(n, "trust", None) is None


def test_stable_id_zelfde_claim_andere_bron_is_aparte_stem():
    a = stable_id("Leer is een bijproduct.", "Patched-column")
    b = stable_id("Leer is een bijproduct.", "landbouweconomie")
    c = stable_id("Leer is een BIJPRODUCT!", "patched column")   # normalisatie
    assert a != b            # andere bron → aparte stem (woozle-guard heeft dit nodig)
    assert a == c            # zelfde content + zelfde bron → idempotent


def test_parse_intake_fail_closed():
    assert parse_intake(None) == []
    assert parse_intake("geen json") == []
    assert parse_intake('{"niet": "een array"}') == []
    ok = parse_intake('```json\n[{"content": "x", "subject": "leer", '
                      '"provenance": "media", "source": "s"}]\n```')
    assert len(ok) == 1 and ok[0]["subject"] == "leer"
    assert "ONDERWERP-lijst" in build_intake_prompt("x") and SUBJECTS[0] in build_intake_prompt("x")


def test_intake_faalt_closed_zonder_llm(tmp_path):
    assert intake("tekst", "", str(tmp_path), reason_fn=lambda *a, **k: None) is None
    assert intake("", "", str(tmp_path), reason_fn=_fake_reason) == ([], 0)


# ── fase 3: opritten ─────────────────────────────────────────────────────────

def _atoms():
    return {
        "z1": {"claim": "PLA composteert volledig industrieel", "source": "WUR",
               "tags": ["materiaal"]},
        "z2": {"claim": "Cellulosediacetaat composteert wisselend", "source": "WUR",
               "tags": ["materiaal"]},
        "z3": {"claim": "Soleic PU bruikbaar in composteerbare zolen", "source": "rc.eu",
               "tags": ["materiaal"]},
        "w1": {"claim": "Mensen wachten maanden en kopen toch", "source": "shop",
               "tags": ["vraag"]},
        "w2": {"claim": "Winkelwagen-verlaters nemen toe na zes weken wachten",
               "source": "shop", "tags": ["vraag"]},
        "los": {"claim": "Iets ongesorteerds", "source": "x", "tags": []},
    }


@pytest.mark.smoke
def test_clusters_bottom_up_alleen_ongebonden():
    atoms = _atoms()
    cl = clusters(atoms, [], min_size=3)
    assert len(cl) == 1 and cl[0]["hub"] == "materiaal"
    assert set(cl[0]["atom_ids"]) == {"z1", "z2", "z3"}
    # eenmaal gebonden aan een inzicht → geen cluster meer (emergentie is voor vrij werk)
    inzicht = {"evidence": [{"atom_id": "z1"}, {"atom_id": "z2"}]}
    assert clusters(atoms, [inzicht], min_size=3) == []
    assert "los" in ongebonden(atoms, [])


def test_ongesorteerd_bakje_alleen_kennisbank_atomen(tmp_path):
    """Legacy Librarian-kaartjes (geen provenance) overspoelen het bakje niet;
    een kennisbank-atoom zonder onderwerp staat er wél in."""
    import types
    from nooch_village.views.kennisbank import _ongesorteerd_bakje
    atoms = {
        "legacy": {"claim": "an english librarian card", "source": "gsc", "tags": ["vegan"]},
        "kb_los": {"claim": "notitie zonder onderwerp", "source": "x",
                   "provenance": "unknown", "tags": []},
        "kb_hub": {"claim": "notitie met hub", "source": "x",
                   "provenance": "media", "tags": ["leer"]},
    }
    html = _ongesorteerd_bakje(atoms, [], csrf="t")
    assert "Unsorted (1)" in html
    assert "notitie zonder onderwerp" in html
    assert "librarian card" not in html and "notitie met hub" not in html


def test_gather_stance_via_llm_fail_closed():
    atoms = _atoms()
    stance_llm = lambda prompt, **kw: '[{"nr": 1, "stance": "support"}, {"nr": 2, "stance": "counter"}]'
    kand = gather("wachten is een feature geen kost", atoms, reason_fn=stance_llm)
    ids = [k["atom_id"] for k in kand]
    assert "w1" in ids and "w2" in ids
    assert any(k["stance"] == "counter" for k in kand)          # de tegen-sectie bestaat
    # zonder LLM: alles support (mens draait zelf), geen crash
    kand2 = gather("wachten is een feature", atoms, reason_fn=lambda *a, **k: None)
    assert kand2 and all(k["stance"] == "support" for k in kand2)


# ── fase 3: het copy-paste-spel + munten ─────────────────────────────────────

_BLOK = ("Goed gescherpt. Hier is het blok:\n\n=== INZICHT ===\n"
         "TITEL: Wachttijd bindt\nCLAIM: Wachttijd bindt de kern-doelgroep.\n"
         "REFRAME: Wachttijd is een kost die we mooi inpakken.\n"
         "FALSIFIER: Een kortere wachttijd verhoogt de conversie zichtbaar.\n=== EINDE ===")


@pytest.mark.smoke
def test_spel_copypaste_munten_v10(tmp_path):
    dd = str(tmp_path)
    store = SpelStore(f"{dd}/spel.json")
    kb = KennisbankStore(f"{dd}/kennisbank.json")
    sid = store.start("wachttijd is een feature",
                      [{"atom_id": "w1", "stance": "support"},
                       {"atom_id": "w2", "stance": "counter"}], by="test")

    assert spel_finish(store, sid, kb, "geen blok hier") is None   # onleesbaar → niet munten
    assert store.get(sid)["status"] == "open"                      # en niets verloren

    iid, versie = spel_finish(store, sid, kb, _BLOK)
    assert versie == "1.0"
    ins = kb.get(iid)
    assert ins["title"] == "Wachttijd bindt de kern-doelgroep."
    assert ins["falsifier"].startswith("Een kortere wachttijd")
    assert [l["atom_id"] for l in ins["evidence"]] == ["w1", "w2"]     # verankerd aan de set
    assert store.get(sid)["status"] == "gemunt"
    assert spel_finish(store, sid, kb, _BLOK) is None              # idempotent: nooit dubbel munten


def test_spel_herformuleer_bumpt_versie_met_history(tmp_path):
    dd = str(tmp_path)
    store = SpelStore(f"{dd}/spel.json")
    kb = KennisbankStore(f"{dd}/kennisbank.json")
    iid = kb.add("Prijs blokkeert onze kern-doelgroep", subject="prijs")
    kb.link(iid, "p1", "support")

    sid = store.start("prijs", [{"atom_id": "p1", "stance": "support"}],
                      reformulate_of=iid, by="test")
    blok = _BLOK.replace("Wachttijd bindt de kern-doelgroep.",
                         "Prijs is de drempel voor de Idealist.")
    iid2, versie = spel_finish(store, sid, kb, blok)
    assert iid2 == iid and versie == "1.1"
    ins = kb.get(iid)
    assert ins["title"] == "Prijs is de drempel voor de Idealist."
    assert ins["history"][0]["title"] == "Prijs blokkeert onze kern-doelgroep"
    assert [l["atom_id"] for l in ins["evidence"]] == ["p1"]      # evidence stroomt door


@pytest.mark.smoke
def test_spel_hand_uitbreiden_en_nudge(tmp_path):
    """Taak 2: start dun (2 kaarten), breid uit via de hand; de nudge-teller kijkt
    naar ONAFHANKELIJKE steunbronnen (woozle) en komt op 3 zodra de derde losse
    bron erbij zit."""
    store = SpelStore(str(tmp_path / "spel.json"))
    atoms = _atoms()  # z1/z2: bron WUR (één groep!), z3: rc.eu, w1/w2: shop
    sid = store.start("composteerbare zool", [{"atom_id": "z1", "stance": "support"},
                                              {"atom_id": "w2", "stance": "counter"}])
    assert steun_onafhankelijk(store.get(sid), atoms) == 1

    assert store.add_kaart(sid, "z2", "support")       # zelfde bron (WUR) → geen extra stem
    assert steun_onafhankelijk(store.get(sid), atoms) == 1
    assert store.add_kaart(sid, "z3", "support", annotation="onafhankelijk")
    assert store.add_kaart(sid, "w1", "support")
    assert steun_onafhankelijk(store.get(sid), atoms) == 3          # nudge-drempel gehaald

    assert store.add_kaart(sid, "z2", "counter")       # idempotent: richting draait, geen dubbel
    assert sum(1 for k in store.get(sid)["set"] if k["atom_id"] == "z2") == 1
    assert store.flip_kaart(sid, "z2")                 # één klik terug naar support
    assert next(k for k in store.get(sid)["set"] if k["atom_id"] == "z2")["stance"] == "support"
    assert store.remove_kaart(sid, "w2")
    assert store.add_kaart(sid, "x", "gek") is False   # ongeldige richting → geweigerd


# ── taak 4: signalen-backfill ────────────────────────────────────────────────

def test_backfill_idempotent_en_batcht(tmp_path):
    import json as _json
    dd = str(tmp_path)
    radar = {"items": {f"s{i}": {"id": f"s{i}", "status": "goedgekeurd", "at": f"2026-07-{10+i}",
                                 "content": f"signaal {i}", "rationale": "context",
                                 "feed": "Materialen"} for i in range(5)}}
    (tmp_path / "radar.json").write_text(_json.dumps(radar))

    from nooch_village.kennisbank_backfill import backfill, _batch_raw
    calls = []
    def fake_intake(raw, hint, data_dir):
        calls.append(raw)
        return [f"atom_{len(calls)}"], 0
    rap = backfill(dd, apply=True, batch_size=2, intake_fn=fake_intake)
    assert len(calls) == 3                                  # 5 signalen à batch 2 → 3 calls
    assert "[bron: Materialen]" in calls[0]                 # bron inline per signaal
    assert any("✓ batch 3/3" in r for r in rap)

    calls.clear()
    rap2 = backfill(dd, apply=True, batch_size=2, intake_fn=fake_intake)
    assert calls == []                                      # her-run: state slaat alles over
    assert any("5 al verwerkt | 0 te doen" in r for r in rap2)


def test_backfill_gefaalde_batch_komt_terug(tmp_path):
    import json as _json
    dd = str(tmp_path)
    radar = {"items": {f"s{i}": {"id": f"s{i}", "status": "goedgekeurd", "at": "2026-07-17",
                                 "content": f"signaal {i}", "feed": "f"} for i in range(2)}}
    (tmp_path / "radar.json").write_text(_json.dumps(radar))
    from nooch_village.kennisbank_backfill import backfill
    rap = backfill(dd, apply=True, batch_size=2, intake_fn=lambda *a: None)
    assert any("✗ batch" in r for r in rap)
    rap2 = backfill(dd, apply=False)
    assert any("2 te doen" in r for r in rap2)              # niets geregistreerd → her-run pakt ze


# ── taak 5: source-adapters ──────────────────────────────────────────────────

def test_chunker_verliest_de_staart_niet():
    from nooch_village.kennisbank_sources import _chunk
    alineas = [f"Alinea {i}: " + ("x" * 900) for i in range(20)]
    tekst = "\n\n".join(alineas)
    blokken = _chunk(tekst, maat=3000)
    assert all(len(b) <= 3000 + 950 for b in blokken)       # ~maat, nooit hard afgekapt
    assert "Alinea 19" in blokken[-1]                       # de staart is er
    plat = "\n\n".join(blokken)
    for i in range(20):
        assert f"Alinea {i}" in plat                        # niets verloren
    assert _chunk("één korte alinea") == ["één korte alinea"]


def test_van_pdf_scan_zonder_tekstlaag_meldt(tmp_path):
    from nooch_village.kennisbank_sources import van_pdf
    assert van_pdf(b"geen pdf") is None                     # rommel → None, geen halve data
    # echte maar lege PDF (geen tekstlaag) → None
    from pypdf import PdfWriter
    import io as _io
    w = PdfWriter(); w.add_blank_page(width=200, height=200)
    buf = _io.BytesIO(); w.write(buf)
    assert van_pdf(buf.getvalue(), "scan.pdf") is None


def test_van_url_faalt_netjes_zonder_netwerk():
    from nooch_village.kennisbank_sources import van_url
    assert van_url("ftp://x") is None and van_url("") is None
    assert van_url("javascript:alert(1)") is None


# ── addendum A+B: samengestelde kaarten + schone citaties ────────────────────

def test_parse_intake_body_en_reference():
    rows = parse_intake(json.dumps([{
        "content": "In de leerschoenproductie zijn 19 micro-stappen met kinderarbeid geïdentificeerd.",
        "body": "1. huiden sorteren\n2. ontharen\n…\n19. afwerken",
        "subject": "ethiek", "provenance": "peer_reviewed",
        "source": "IDS 2021", "reference": "DOI 10.19088/CLARISSA.2021.005"}]))
    assert len(rows) == 1
    a = rows[0]
    assert a["body"].startswith("1. huiden") and a["reference"].startswith("DOI")
    from nooch_village.kennisbank_intake import atoom_kaart
    kaart = atoom_kaart(a)
    assert kaart.body and kaart.reference and kaart.provenance == "peer_reviewed"
    assert "©" not in kaart.claim and "ISBN" not in kaart.claim
    p = build_intake_prompt("x")
    assert "ENUMERATIE" in p and "glossarium" in p and "reference" in p


# ── addendum C: merge + archiveren ───────────────────────────────────────────

def test_merge_en_archiveren_append_only(tmp_path):
    from nooch_village.insight import Insight
    from nooch_village.kennisbank import load_atoms
    dd = str(tmp_path)
    notes = NotesStore(f"{dd}/notes.json")
    for i in range(3):
        notes.add(Insight(id=f"stap{i}", claim=f"Stap {i}: iets met huiden",
                          source="IDS 2021", provenance="peer_reviewed" if i else "media",
                          tags=["ethiek"]))

    kaart = notes.merge(["stap0", "stap1", "stap2"], "19 micro-stappen (samengevat)")
    assert kaart is not None
    assert kaart.merged_from == ["stap0", "stap1", "stap2"]
    assert kaart.provenance == "peer_reviewed"           # de hoogste van de delen
    assert "Stap 1" in (kaart.body or "")
    # originelen bestaan nog, maar gearchiveerd (append-only)
    assert notes.get("stap0").archived is True
    atoms = load_atoms(dd)                                # default: archief onzichtbaar
    assert "stap0" not in atoms and kaart.id in atoms
    assert "stap0" in load_atoms(dd, include_archived=True)
    # terugzetten kan
    assert notes.archive("stap0", archived=False)
    assert "stap0" in load_atoms(dd)
    # zelfde delen + zelfde kop nogmaals → geweigerd (idempotent)
    assert notes.merge(["stap0", "stap1", "stap2"], "19 micro-stappen (samengevat)") is None
    # merge vereist ≥2 delen en een kop
    assert notes.merge(["stap0"], "kop") is None
    assert notes.merge(["stap0", "stap1"], "") is None


def test_gearchiveerd_blijft_uit_clusters_en_zoek(tmp_path):
    from nooch_village.insight import Insight
    from nooch_village.kennisbank import load_atoms
    dd = str(tmp_path)
    notes = NotesStore(f"{dd}/notes.json")
    notes.add(Insight(id="ruis", claim="de term ripit betekent iets", source="glossarium",
                      provenance="unknown", tags=["materiaal"]))
    notes.add(Insight(id="echt", claim="composteerbare zool haalbaar", source="lab",
                      provenance="internal_data", tags=["materiaal"]))
    notes.archive("ruis")
    atoms = load_atoms(dd)
    assert clusters(atoms, [], min_size=1)[0]["atom_ids"] == ["echt"]
    assert all(k["atom_id"] != "ruis" for k in gather("ripit betekent", atoms,
                                                      reason_fn=lambda *a, **k: None))


def test_schoon_reference():
    from nooch_village.kennisbank_intake import _schoon_reference, parse_intake
    import json as _j
    assert _schoon_reference("https://scientias.nl/artikel-slug/?utm_source=x") is None
    assert _schoon_reference("https://doi.org/10.1016/j.x?utm=1") == "https://doi.org/10.1016/j.x"
    assert _schoon_reference("10.19088/CLARISSA.2021.005") == "10.19088/CLARISSA.2021.005"
    assert _schoon_reference("ISBN 978-1-78118-821-7") == "ISBN 978-1-78118-821-7"
    assert _schoon_reference("") is None
    # via de validator: een kale artikel-URL in reference verdwijnt, een DOI blijft
    rows = parse_intake(_j.dumps([
        {"content": "x", "subject": "leer", "provenance": "media", "source": "Scientias.nl",
         "reference": "https://scientias.nl/slug/?utm=1"},
        {"content": "y", "subject": "leer", "provenance": "peer_reviewed", "source": "Water Research",
         "reference": "https://doi.org/10.1016/j.watres.2026.005"}]))
    assert rows[0]["reference"] is None and rows[1]["reference"].startswith("https://doi.org/10.")
