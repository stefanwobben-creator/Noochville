# Field Note 2026-06-20

# Field Note — Nooch.earth
**Week: 7 dagen | Bron: Plausible + Google Trends**

---

## Wat opvalt

101 bezoekers, 171 paginaweergaven, gemiddelde bezoekduur 67 seconden. De homepage trekt 93 van de 101 bezoekers — productpagina's en blogs blijven ver achter (max. 4 bezoekers per pagina). Verkeer komt voornamelijk via Direct/None (42), Google (31) en bluemarble (6 via UTM). Instagram levert 4 bezoekers via UTM-tag `ig`. Het merendeel van de bezoekers komt uit Nederland (73), gevolgd door VS (8) en België (5).

In de zoektermen valt **soberheid** op: interest 100, stijgend, zonder gerelateerde zoekopdrachten beschikbaar. **Veganistisch** stijgt ook (45, stijgend). **Duurzaam** scoort 73 maar daalt. **Plasticvrij** en **regeneratief** dalen beide, met respectievelijk interest 12 en 31.

---

## Wat dit betekent

Bijna alle bezoekers verlaten de site via de homepage zonder dieper te gaan. Met 67 seconden gemiddelde duur is er weinig ruimte voor missie-overdracht. Bluemarble levert gerichte bezoekers met UTM-tracking — een partnerschap dat werkt. Soberheid is een stijgend zoekwoord dat inhoudelijk aansluit bij Nooch's kernwaarden (geen externaliteiten, op bestelling), maar er bestaat nog geen pagina die dit woord serieus oppakt.

---

## Actie voor morgen

Schrijf één blogartikel of pagina rond het zoekwoord **soberheid** — gekoppeld aan het on-demand productiemodel van Nooch. Dat verbindt een stijgend zoekwoord direct aan een concrete kernwaarde.
