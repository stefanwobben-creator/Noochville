# Field Note 2026-06-29

**Field Note – Nooch.earth (7 dagen)**

**Verkeer & trends**
De site had 107 unieke bezoekers (191 pageviews, gem. bezoekduur 107 sec). De homepage domineert met 97 bezoekers; andere pagina’s zoals /collections (4) en /cart (2) scoren laag. Google levert 45 bezoekers (42%), gevolgd door direct verkeer (33%) en Instagram (9). Nederland (56) en Spanje (12) zijn de sterkste landen. Opvallend: 2 bezoekers via *cobbledgoods.com* en *cosh.eco*, en 1 via ChatGPT. UTM-gebruik is minimaal (alleen *ig* met 9 bezoekers).

**Missie-gedreven groei**
De focus op ethisch ondernemen trekt vooral Nederlandse en Spaanse bezoekers, wat past bij de kernwaarden (geen externaliteiten, transparantie). Direct verkeer en Google tonen interesse in de missie, maar de lage pageviews per bezoeker (1,78) en korte bezoekduur (107 sec) duiden op oppervlakkige oriëntatie. De homepage is de enige pagina met volume; product- en collectiepagina’s worden nauwelijks bezocht.

**Actie voor morgen**
Verhoog de diepgang van verkeer naar productpagina’s via gerichte Google Ads (missie-gedreven keywords zoals *"duurzame schoenen Europa"* of *"ethische sneakers op bestelling"*) en optimaliseer de homepage voor doorverwijzing naar /collections met duidelijke CTA’s. Meet impact via UTM-links (bijv. *utm_source=google_ads*).
