# Field Note 2026-06-14

# Field Note — Nooch.earth
**Week van vandaag | 7-daags venster**

---

**Wat valt op**

165 bezoekers, 268 pageviews. Gemiddeld 1,6 pagina's per bezoeker — mensen kijken even rond maar haken snel af. Geen paniek, maar het is mager voor organische groei richting 1000 klanten/jaar.

In de trends springt één ding eruit: *veganistisch* scoort 64 en stijgt. Relevant, want Nooch maakt leervrije producten — dat is concreet veganistisch, niet alleen "duurzaam". *Regeneratief* stijgt ook (45), maar mensen zoeken vooral naar de betekenis ervan. Ze kennen het woord nog niet.

*Duurzaam* daalt. Dat woord is uitgehold — iedereen gebruikt het, niemand gelooft het meer. Goed nieuws voor Nooch: onze specificiteit (geen plastic, op bestelling, Europa) is precies wat "duurzaam" niet meer zegt.

*Soberheid* is dood in de data. Loslaten als insteek.

---

**Actie voor morgen**

Schrijf één pagina die expliciet de verbinding legt tussen *veganistisch* en leervrije productie — concreet, zonder preek. Dat is de zoekvraag die nu leeft.
