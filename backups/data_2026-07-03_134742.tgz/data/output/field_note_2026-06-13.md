# Field Note 2026-06-13


## Verkeer (Plausible)
- Bezoekers (7d): 177 (vorige puls: 177)

## Trends
- **duurzame sneakers**: interesse 6 (dalend); opkomend: duurzame sneakers dames
- **vegan schoenen**: interesse 22 (stijgend); opkomend: vegan schoenen dames
- **plastic free shoes**: interesse None (onbekend); opkomend: geen
- **duurzame sneakers dames**: interesse None (onbekend); opkomend: geen
- **plastic free footwear**: interesse 0 (vlak); opkomend: geen
- **plastic free sneakers**: interesse None (onbekend); opkomend: geen
- **plasticvrije sneakers**: interesse None (onbekend); opkomend: geen

## Duiding
- Geen alarmsignaal in het verkeer.
- (Zet een LLM-key in .env voor een rijkere, missie-gedreven duiding.)
