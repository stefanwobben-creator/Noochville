# Field Note 2026-07-01

> ⚠️ SPANNING: Bezoekers gedaald van 107 naar 78 (27%).

**Field Note – Nooch.earth (7 dagen)**

**Verkeer & trends**
De site trekt 78 bezoekers (129 pageviews) met een gemiddelde bezoekduur van 97 seconden. De homepage domineert met 69 bezoekers; andere pagina’s zoals /cart, /collections en productpagina’s scoren laag (1–2 bezoekers). Verkeer komt vooral via Google (28 bezoekers), directe bezoeken (24) en Instagram (9). Nederland levert de meeste bezoekers (41), gevolgd door Spanje (9) en de VS (8).

De zoektermen "conscious consumer", "leather free", "LØCI", "Lane Eight" en "Alohas" konden niet opgehaald worden door een API-fout. Geen data beschikbaar.

**Betekenis voor missie-gedreven groei**
De lage bezoekersaantallen op product- en collectiepagina’s duiden op een gebrek aan organische zoekintentie of zichtbaarheid. De focus op directe bezoeken en Google toont dat merkbekendheid (via Instagram) en zoekmachineoptimalisatie (SEO) nog onvoldoende renderen. De geografische spreiding is beperkt tot West-Europa en de VS, met weinig groeipotentieel in andere regio’s.

**Actie voor morgen**
1. **SEO-audit**: Controleer of de missie-gedreven keywords ("leather free", "conscious consumer") in de site-structuur en metadata staan. Pas zo nodig aan.
2. **Content-upgrade**: Voeg korte, gerichte teksten toe aan productpagina’s met deze keywords (bv. "leather-free sneakers").
3. **Instagram-analyse**: Meet welke posts de 9 bezoekers genereerden en optimaliseer voor meer verkeer.
