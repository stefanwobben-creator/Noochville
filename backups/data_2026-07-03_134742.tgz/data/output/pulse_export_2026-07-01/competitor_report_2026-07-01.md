# Competitor Field Report
*Gegenereerd op: 2026-07-01 20:36 UTC*

Monitor van strategische ontwikkelingen (funding, materiaalinnovatie, winkelopeningen, B-Corp, lanceringen) bij directe concurrenten. Getrapt venster per merk: 30/90/365 dagen (het kortste met nieuws).

---

## 👟 Veja  _(laatste maand)_
- **[How Tmall is opening China’s door to VEJA - Dao Insights](https://news.google.com/rss/articles/CBMiW0FVX3lxTFB3V1lXaDZ5WmNYamdyVmhQZldFckhaMjZmeGFQZ3Q5aGFqX1plT2lTbERBMTZWV2F4UGotMkNiX2kxRTJBNDBPcDJrM2ZmVFk0bm80S21sejFvQTQ?oc=5)**
  - *Publicatiedatum:* 2026-06-30

## 👟 Moea  _(laatste jaar)_
- _Geen ontwikkelingen in het afgelopen jaar._

## 👟 Flamingos Life  _(laatste maand)_
- **[The Ultimate Guide to More Ethical and Sustainable Shoes - Good On You](https://news.google.com/rss/articles/CBMiX0FVX3lxTE9CS0ZYVU13eVBGdW9SdENrZE5obVdaeHFzQjJ1eGNhMk9Da0xVelVfLU1TQVNBRlVwMk9yczlwQ2VXMnc4NHpRRG1OWkdTTVFfZ3UtVnNJNWRwZUxJSF80?oc=5)**
  - *Publicatiedatum:* 2026-06-16

## 👟 Komrads  _(laatste maand)_
- **[10 Best Ethical & Sustainable Sneakers 2024 - Causeartist](https://news.google.com/rss/articles/CBMiY0FVX3lxTFBaMXFibGFFZmpQTDFHcG03NlkwakQtVXp5TzJCdFVVZDlNbUs4WVJVdURhaXRkNHJBeUxWb1Q1Ykg4S2U0TnB5UjNDbC11Z2RZa3RzRkJUeTBIT1k4M2RKa2JwTQ?oc=5)**
  - *Publicatiedatum:* 2026-06-04
- **[20 Ethical and Sustainable Shoe Brands - Causeartist](https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBDcUNTT3VZVHQ0NkdYUmtUd2JrRkJQOEh5VVZnLVBldmR6UV9FVkpPZWVCTHNWV1RJY0c2Tko4RXVxTW53QTdjMVhGTlhqY2sxU1VOSXU2UmhpYUNvdzhmdlNLc1Vzb3M?oc=5)**
  - *Publicatiedatum:* 2026-06-04

## 👟 LØCI  _(laatste jaar)_
- **[French Champagne House Maison Telmont and British Brand LØCI Launch Limited-Edition Vegan Sneakers - Oui Speak Fashion (OSF)](https://news.google.com/rss/articles/CBMia0FVX3lxTE1NZWRJbkRKRWNIempvYjNtWi1zLXVJNG1CRWNGRzV0S01YcnhCZDhwNktDVVYzekpZU0otU3dyQmF3Z202ZnlrSlpOTjNSSDRUQ0N4ZkpLbVpxVmVoc1d5OVVjd0QyNnczUm9J?oc=5)**
  - *Publicatiedatum:* 2025-10-13

## 👟 Lane Eight  _(laatste jaar)_
- _Geen ontwikkelingen in het afgelopen jaar._

## 👟 Alohas  _(laatste maand)_
- **[Spanish Alohas Expands in the U.S.: Opens Second NYC Store Following L.A. Launch - Modaes](https://news.google.com/rss/articles/CBMi1gFBVV95cUxNUW9vcV9Wb1RQWGZtN3ZPNVRWeExPS0Q3bUNTMlBibXduRDJwbTBOSkJYWkZ4M0V3OVA4SW9Idm4tUjZIZkhBZHZ4ZW9lSG50cVpXMkFrRGZTWjd0Rlh6cDFMMFVyUzdMLVNIWGRyaFFkSWcxNGtiN0pkb2tWcXh1Q1VOQXIybEE3OGQ3RTd2MXB5bVNGaWVJT0tyVnFqVWJPS2JmUmowM3VxQTBjRzBkUVdjSEFtUnExOXk0T1NpT2kzVEhxeUt4b2lINXVJZnp0b291c0Vn?oc=5)**
  - *Publicatiedatum:* 2026-07-01
- **[The LG Hot List: June - SheerLuxe](https://news.google.com/rss/articles/CBMiakFVX3lxTE1VOC0tLU14TFRlbGlRNWwwNHNKMVU3MVJfc2J2VU1sVkp2bXNYejdYOVM1aGNIOS1NOWhOUjM1Zng4WXdSOVcwSlhiWG16dmlFTFRZSTdtZHBaSncxZzYzSlNGbGxuY3FWbXc?oc=5)**
  - *Publicatiedatum:* 2026-06-09
- **[7 Unexpected Ways to Style Red Sneakers This Summer - glamour.com](https://news.google.com/rss/articles/CBMiZkFVX3lxTE1FQ0Y2bkRfdmVONE40WjBhZFZRcEtvZDF5Rm9mUWN6eWdGZEE5a0tPTzRmeVJvTEVhWGs3NnJ1RFlPYlNPcXl2Wkl2RXFZelVtT0NWdV9JdzgtelE3cE1oU090ak5SUQ?oc=5)**
  - *Publicatiedatum:* 2026-06-05
- **[In pictures: Alohas curates new colourways for World Cup collection - Drapers](https://news.google.com/rss/articles/CBMiowFBVV95cUxPcnQxaldEY3VmSmZCZ3ZaVE5CT281aTFqb0RwQnFBb3BWZFg1NkhQSDJMaVBnLWQwV1BXakNGQTNwT0lqeGpoeTRqbzU2b29TN2RyT1pYWXFIRWxrOGlmZGJadzlmTEdkM1JjNlk0ZExxQ3d6OEhLRFlLc1hCTU42OWptaW53bGpPQkgyN01vRHhlZzdlVGJEOU03bHExdVFCWVpR?oc=5)**
  - *Publicatiedatum:* 2026-06-15

## 👟 Merrell  _(laatste maand)_
- **[Wolverine Worldwide CEO on Merrell’s Legacy and Why He’s Not Leaning on the Past - wwd.com](https://news.google.com/rss/articles/CBMirgFBVV95cUxOMkU0N1NMeE1qM1ZmUGd3VlFhOHU5aXY1UHhUZEphSEdsTTRSQXdoZlFQeDlxeWlkTnQzUndXTFJwUjFoZUpGWDFBN2toYWxacWhXRXVZbExSOXhobkdTaG5zVVV2TGlSU19uRlRBOEVnc1NtcDhGUDdZczZvV19fUjRkRFBxUmFWTHh0XzRubHgySzlhVXY3dXBhZFgwMFVoY2NyN1ZJZ1hOTTMyU2c?oc=5)**
  - *Publicatiedatum:* 2026-06-02
- **[Merrell's futuristic hiking shoes just got the GORE-TEX treatment courtesy of a cult Japanese outdoor brand - t3.com](https://news.google.com/rss/articles/CBMioAFBVV95cUxPRWhwanB1MHNTd2ZtTVVENU9pZi1FdWd3VElXcmUxUU16dFhhNDFrN1lqVHhRTmdfbFg3a3FWWlJiUW5vb1lDUWFjVUlyU0VoNS1VdmxLX0lZa2I4ajZ0eGVUS2VQNWlrUlZqX3NVRDhneFZGelpOTDNueFVJa0RqaWFKSXFXeU1WTHRpNTlaSGh0UDk3M0trNnZrcF92N04t?oc=5)**
  - *Publicatiedatum:* 2026-06-22
- **[Hiking Boots Snow Peak Slippers Snow Peak And Merrell Unveil Third Collaboration - consumerthai](https://news.google.com/rss/articles/CBMiWEFVX3lxTE14OVBSamNjSnNnRjBCSHNueDdpNjhQbGEtSlVmU19vTDhCUXMyQ1FKMkNwYTVqdlNKcWlsQnlDYmlFMHdWYjdCc3lXdVpfWFlESEItdmlicmY?oc=5)**
  - *Publicatiedatum:* 2026-06-17

## 👟 Nooch.earth  _(laatste jaar)_
- _Geen ontwikkelingen in het afgelopen jaar._

## 👟 Good On You  _(laatste maand)_
- **[56 More Affordable Sustainable Fashion Brands - Good On You](https://news.google.com/rss/articles/CBMibEFVX3lxTFBDMlAxZElSOFRGb05ILURDRWZ1VW9BYkpScGxROWZGVGlCaFFVdkZieHRBRHVUX1FjdE53ZVJWY1U0dnlGMDB4cFhONU8wVDRaVWdLNmFVWDJuSkZOMWdNeEpnYmtoWFRyZGhnSA?oc=5)**
  - *Publicatiedatum:* 2026-06-17
- **[Our Top Brands for More Sustainable Wedding Guest Outfits - Good On You](https://news.google.com/rss/articles/CBMiZ0FVX3lxTFB3dFpaX0NrZWN3Tlo4bkFGOUVicFZmQUdjUjBLbUVJY1FZclQxMlE5dGkybFNZUW5FRUFQMERTa25LNmR2YWFpZXl2bVBHN1R0VzA2eG15N3lIMmpnSjNGY2lTVjJELUE?oc=5)**
  - *Publicatiedatum:* 2026-06-10
