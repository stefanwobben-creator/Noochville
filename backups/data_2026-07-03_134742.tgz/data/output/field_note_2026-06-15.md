# Field Note 2026-06-15

# Field Note — Nooch.earth
**Week 28 mei · 7-dagenvenster**

---

**Wat valt op**

153 bezoekers, 257 pageviews. Gemiddeld 1,7 pagina's per bezoek — mensen klikken door, maar het volume is klein.

Van de vijf kernzoektermen beweegt alleen *veganistisch* omhoog (interest 56, stijgend). De rest daalt of staat op nul. Opvallend: *soberheid* genereert letterlijk geen zoekverkeer. *Bewuste consument* heeft geen meetbare data in NL.

**Wat dit betekent**

De taal die Nooch intern gebruikt — soberheid, regeneratief, bewuste consument — sluit niet aan op wat mensen daadwerkelijk intypen. Dat is geen probleem met de missie, wel met de vindbaarheid. *Veganistisch* is de enige brug die nu werkt, maar de gerelateerde zoekopdrachten (eten, restaurant, recept) wijzen op leefstijl, niet op producten.

**Actie voor morgen**

Schrijf één concrete pagina of blogartikel rondom **"veganistisch leven zonder plastic"** — dat combineert de enige stijgende term met een onderscheidende kernwaarde. Geen theorie, wel een concreet product of keuze als ankerpunt.
