# Field Note 2026-06-26

**Field Note – Nooch.earth (7 dagen)**

**Verkeer & trends**
Het verkeer is laag maar stabiel: 122 bezoekers, 206 pageviews en een gemiddelde bezoektijd van 65 seconden. De homepage domineert met 118 bezoekers (97% van het totaal). Slechts 5 bezoekers gingen naar de collectie-overzichtspagina, 3 naar de voorwaarden en 2 naar productpagina’s. De top-verkeersbron is Google (54 bezoekers), gevolgd door direct verkeer (38) en Instagram (9). Nederland levert de meeste bezoekers (68), met België (10) en de VS (14) als opvallende buitenlandse markten. Opvallend: 1 bezoeker kwam via ChatGPT.

**Missie-gedreven groei**
De data toont een sterke focus op de homepage, wat suggereert dat de core message (missie, waarden) goed aanslaat, maar productpagina’s onderbenut blijven. Direct verkeer en Google zijn de belangrijkste kanalen, maar organische zoekopdrachten ontbreken in de data. De lage bezoektijd op productpagina’s wijst mogelijk op een gebrek aan overtuigende content of een te complexe navigatie.

**Actie voor morgen**
Verfijn de productpagina’s met duidelijke uitleg over duurzaamheid (bijv. materialen, productieproces) en voeg een duidelijke call-to-action toe. Test een kortstondige campagne op Instagram om verkeer naar de collectie te sturen.
