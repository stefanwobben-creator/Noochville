# Field Note 2026-06-24

**Field Note – Nooch.earth (7 dagen)**

**Verkeer & trends**
De site trekt 115 bezoekers (204 pageviews) met een gemiddelde bezoekduur van 89 seconden. De homepage domineert met 111 bezoekers; andere pagina’s scoren marginaal (max. 5 bezoekers op /collections). Verkeer komt vooral uit Google (48 bezoekers) en direct (45), met Nederland als grootste markt (69 bezoekers). LinkedIn en Instagram leveren elk 3 bezoekers, terwijl ChatGPT 1 bezoeker genereert.

Zoektermen: *vegan* (48, stabiel), *sustainable* (23, stijgend), *regenerative* (32, dalend), *sufficiency* (31, dalend) en *plastic-free* (16, dalend). *Sustainable* is de enige term met een stijgende trend.

**Implicaties voor missie-gedreven groei**
De focus op *sustainable* en *vegan* sluit aan bij de kernwaarden, maar de lage bezoekersaantallen op product- en collectiepagina’s wijzen op een gebrek aan zichtbaarheid in zoekopdrachten. De dalende trends voor *sufficiency* en *regenerative* suggereren dat deze termen minder relevant zijn voor de doelgroep. De hoge directe verkeersbron en Nederlandse markt benadrukken de noodzaak om lokale, missiegedreven zoekopdrachten te versterken.

**Actie voor morgen**
Optimaliseer de homepage en productpagina’s voor de zoektermen *sustainable* en *vegan* door deze expliciet in titels, meta-beschrijvingen en content op te nemen. Analyseer de zoekintentie achter *sufficiency* en *regenerative* om te bepalen of deze termen nog relevant zijn voor de doelgroep.
