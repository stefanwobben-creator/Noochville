# Field Note 2026-07-03

**Field Note – Nooch.earth (7 dagen)**

**Verkeer & trends**
De site trok 60 bezoekers (108 pageviews, gem. 107 seconden per bezoek). De homepage domineert met 50 bezoekers (83% van het verkeer), gevolgd door *collections* (3) en *terms of service* (3). Slechts 2 bezoekers bezochten de winkelwagen, wat wijst op lage conversie naar aankoop.

De belangrijkste bronnen zijn *Direct* (22 bezoekers) en *Google* (20). Instagram en DuckDuckGo leverden elk 3 bezoekers, terwijl PETA’s link naar *petaapprovedvegan.peta.org* 2 bezoekers stuurde. Nederland is veruit de grootste markt (31 bezoekers), gevolgd door Spanje (9) en Frankrijk (4). De UTM-campagne *ig* (Instagram) scoorde 2 bezoekers.

**Missie-gedreven groei**
De data toont een sterke focus op de homepage en een lage doorstroom naar productpagina’s. De combinatie van directe bezoekers en organische zoekopdrachten (Google) suggereert bekendheid, maar de lage tijd op de site en beperkte productbezoeken duiden op een gebrek aan engagement. De internationale verdeling (met name Spanje en Frankrijk) biedt kansen, maar de UTM-tracking is minimaal.

**Actie voor morgen**
Optimaliseer de homepage om bezoekers direct naar productpagina’s te leiden: voeg duidelijke call-to-actions toe (bijv. "Shop nu" naar *collections/all*) en test een kortingsaanbod voor nieuwe bezoekers. Monitor de impact op bezoekduur en winkelwagenverkeer.
