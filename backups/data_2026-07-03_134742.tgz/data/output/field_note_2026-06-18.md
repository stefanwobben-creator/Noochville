# Field Note 2026-06-18

# Field Note – Nooch.earth | Weekoverzicht

**Verkeer & trends**

121 bezoekers, 192 pageviews, gemiddelde bezoekduur 27 seconden. Die bezoekduur is laag: mensen landen, kijken even, en vertrekken. Van alle bezoekers gaat 92% direct naar de homepage — productpagina's (269 Hi Natural: 4 bezoekers, 269 Off-White: 3) en blogartikelen trekken nauwelijks verkeer. Google levert 36 bezoekers, direct/none 52 — dat laatste wijst op terugkerende bekenden of gedeelde links zonder tracking. Bluemarble (6 via UTM, 9 totaal inclusief thebluemarble.club) en hetkanwel.nl (5) zijn opvallend actief als verwijzende partners. Nederland domineert met 87 bezoekers; België (5) en Duitsland (2) zijn bescheiden maar aanwezig.

In de trends-data stijgt *veganistisch* (interest: 48, stijgend) als enige term. De zoekvolumes draaien volledig rond eten en restaurants — niet rond schoenen of mode. Regeneratief (21) en plasticvrij (14) dalen allebei. Soberheid heeft nul interest.

**Wat dit betekent**

De missie-gedreven zoektermen die Nooch gebruikt dalen of hebben geen massa. *Veganistisch* heeft tractie, maar de doelgroep zoekt recepten — geen sneakers. De partnerkanalen (Bluemarble, hetkanwel.nl) presteren relatief goed; organisch zoekverkeer is nog dun.

**Actie voor morgen**

Schrijf één blogpost die *veganistisch* verbindt aan schoenen — niet als truc, maar inhoudelijk: waarom veganistisch ook buiten het bord telt, met de 269 als concreet voorbeeld. Dat bouwt aan de juiste zoekintentie zonder de missie te versmallen.
