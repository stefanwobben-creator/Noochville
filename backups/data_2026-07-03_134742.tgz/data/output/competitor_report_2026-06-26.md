# Competitor Field Report
*Gegenereerd op: 2026-06-26 22:45 UTC*

Monitor van strategische ontwikkelingen (funding, materiaalinnovatie, winkelopeningen, B-Corp, lanceringen) bij directe concurrenten. Getrapt venster per merk: 30/90/365 dagen (het kortste met nieuws).

---

## 👟 Veja  _(laatste jaar)_
- **[CFCL x VEJA V‑90: The New Epoch Of Sustainable Luxury Sneakers - Luxferity](https://news.google.com/rss/articles/CBMidkFVX3lxTFBVWENrbjNnYzBUeEw1QU1HYlpWZzFFelNoQ2dsNGF1aHczMzRlcmV4TC1MdDdWVWxOYVc3NGp0bG5oMnlJTWdleUw1SGJYeklRR2J3WkxPQ0ZSbGdlcmVTUldLU0t0TGI1TzFzUzZwaG9WNExIdVE?oc=5)**
  - *Publicatiedatum:* 2026-01-21
- **[Power 100 2025: who are this year’s Footwear’s Finest? - Drapers](https://news.google.com/rss/articles/CBMikgFBVV95cUxOZ3VYbGRzR05kVzVUc0ptWmswX19wMWhxMkxGTXhJUjZWbkFQTmFoVlA5U1F4UUkxVXY3RGpybHJaR2dXUVBJMzZiZGNKYlp2TzRLU2JTQi1nQ2xTMENXN2R4Y2VlMUNtQm92eFFTZFlMakVDaGNNVlFXZWNsUFR5UmlNc1JKLVE5RW1QYUhiSkFvdw?oc=5)**
  - *Publicatiedatum:* 2025-12-04

## 👟 Moea  _(laatste jaar)_
- _Geen ontwikkelingen in het afgelopen jaar._

## 👟 Flamingos Life  _(laatste maand)_
- **[The Ultimate Guide to More Ethical and Sustainable Shoes - Good On You](https://news.google.com/rss/articles/CBMiX0FVX3lxTE9CS0ZYVU13eVBGdW9SdENrZE5obVdaeHFzQjJ1eGNhMk9Da0xVelVfLU1TQVNBRlVwMk9yczlwQ2VXMnc4NHpRRG1OWkdTTVFfZ3UtVnNJNWRwZUxJSF80?oc=5)**
  - *Publicatiedatum:* 2026-06-16

## 👟 Komrads  _(laatste maand)_
- **[10 Best Ethical & Sustainable Sneakers 2024 - Causeartist](https://news.google.com/rss/articles/CBMiY0FVX3lxTFBaMXFibGFFZmpQTDFHcG03NlkwakQtVXp5TzJCdFVVZDlNbUs4WVJVdURhaXRkNHJBeUxWb1Q1Ykg4S2U0TnB5UjNDbC11Z2RZa3RzRkJUeTBIT1k4M2RKa2JwTQ?oc=5)**
  - *Publicatiedatum:* 2026-06-04
- **[20 Ethical and Sustainable Shoe Brands - Causeartist](https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBDcUNTT3VZVHQ0NkdYUmtUd2JrRkJQOEh5VVZnLVBldmR6UV9FVkpPZWVCTHNWV1RJY0c2Tko4RXVxTW53QTdjMVhGTlhqY2sxU1VOSXU2UmhpYUNvdzhmdlNLc1Vzb3M?oc=5)**
  - *Publicatiedatum:* 2026-06-04

## 👟 LØCI  _(laatste jaar)_
- **[French Champagne House Maison Telmont and British Brand LØCI Launch Limited-Edition Vegan Sneakers - Oui Speak Fashion (OSF)](https://news.google.com/rss/articles/CBMia0FVX3lxTE1NZWRJbkRKRWNIempvYjNtWi1zLXVJNG1CRWNGRzV0S01YcnhCZDhwNktDVVYzekpZU0otU3dyQmF3Z202ZnlrSlpOTjNSSDRUQ0N4ZkpLbVpxVmVoc1d5OVVjd0QyNnczUm9J?oc=5)**
  - *Publicatiedatum:* 2025-10-13

## 👟 Lane Eight  _(laatste jaar)_
- _Geen ontwikkelingen in het afgelopen jaar._

## 👟 Alohas  _(laatste maand)_
- **[The LG Hot List: June - SheerLuxe](https://news.google.com/rss/articles/CBMiakFVX3lxTE1VOC0tLU14TFRlbGlRNWwwNHNKMVU3MVJfc2J2VU1sVkp2bXNYejdYOVM1aGNIOS1NOWhOUjM1Zng4WXdSOVcwSlhiWG16dmlFTFRZSTdtZHBaSncxZzYzSlNGbGxuY3FWbXc?oc=5)**
  - *Publicatiedatum:* 2026-06-09
- **[7 Unexpected Ways to Style Red Sneakers This Summer - glamour.com](https://news.google.com/rss/articles/CBMiZkFVX3lxTE1FQ0Y2bkRfdmVONE40WjBhZFZRcEtvZDF5Rm9mUWN6eWdGZEE5a0tPTzRmeVJvTEVhWGs3NnJ1RFlPYlNPcXl2Wkl2RXFZelVtT0NWdV9JdzgtelE3cE1oU090ak5SUQ?oc=5)**
  - *Publicatiedatum:* 2026-06-05

## 👟 Merrell  _(laatste maand)_
- **[Wolverine Worldwide CEO on Merrell’s Legacy and Why He’s Not Leaning on the Past - WWD](https://news.google.com/rss/articles/CBMirgFBVV95cUxOMkU0N1NMeE1qM1ZmUGd3VlFhOHU5aXY1UHhUZEphSEdsTTRSQXdoZlFQeDlxeWlkTnQzUndXTFJwUjFoZUpGWDFBN2toYWxacWhXRXVZbExSOXhobkdTaG5zVVV2TGlSU19uRlRBOEVnc1NtcDhGUDdZczZvV19fUjRkRFBxUmFWTHh0XzRubHgySzlhVXY3dXBhZFgwMFVoY2NyN1ZJZ1hOTTMyU2c?oc=5)**
  - *Publicatiedatum:* 2026-06-02
- **[Merrell's futuristic hiking shoes just got the GORE-TEX treatment courtesy of a cult Japanese outdoor brand - t3.com](https://news.google.com/rss/articles/CBMioAFBVV95cUxPRWhwanB1MHNTd2ZtTVVENU9pZi1FdWd3VElXcmUxUU16dFhhNDFrN1lqVHhRTmdfbFg3a3FWWlJiUW5vb1lDUWFjVUlyU0VoNS1VdmxLX0lZa2I4ajZ0eGVUS2VQNWlrUlZqX3NVRDhneFZGelpOTDNueFVJa0RqaWFKSXFXeU1WTHRpNTlaSGh0UDk3M0trNnZrcF92N04t?oc=5)**
  - *Publicatiedatum:* 2026-06-22
- **[Hiking Boots Snow Peak Slippers Snow Peak And Merrell Unveil Third Collaboration - consumerthai](https://news.google.com/rss/articles/CBMiWEFVX3lxTE14OVBSamNjSnNnRjBCSHNueDdpNjhQbGEtSlVmU19vTDhCUXMyQ1FKMkNwYTVqdlNKcWlsQnlDYmlFMHdWYjdCc3lXdVpfWFlESEItdmlicmY?oc=5)**
  - *Publicatiedatum:* 2026-06-17

## 👟 Nooch.earth  _(laatste jaar)_
- _Geen ontwikkelingen in het afgelopen jaar._

## 👟 Good On You  _(laatste maand)_
- **[56 More Affordable Sustainable Fashion Brands - Good On You](https://news.google.com/rss/articles/CBMibEFVX3lxTFBDMlAxZElSOFRGb05ILURDRWZ1VW9BYkpScGxROWZGVGlCaFFVdkZieHRBRHVUX1FjdE53ZVJWY1U0dnlGMDB4cFhONU8wVDRaVWdLNmFVWDJuSkZOMWdNeEpnYmtoWFRyZGhnSA?oc=5)**
  - *Publicatiedatum:* 2026-06-17
- **[Our Top Brands for More Sustainable Wedding Guest Outfits - Good On You](https://news.google.com/rss/articles/CBMiZ0FVX3lxTFB3dFpaX0NrZWN3Tlo4bkFGOUVicFZmQUdjUjBLbUVJY1FZclQxMlE5dGkybFNZUW5FRUFQMERTa25LNmR2YWFpZXl2bVBHN1R0VzA2eG15N3lIMmpnSjNGY2lTVjJELUE?oc=5)**
  - *Publicatiedatum:* 2026-06-10
- **[22 Sustainable Gender Neutral Brands and Gender Inclusive Clothing for Every Body - Good On You](https://news.google.com/rss/articles/CBMic0FVX3lxTE0wa0c3VUhHbjJOb29zMjhKMEhpMDNhcU9aSmZLdVN6NllTNnB1U0lfcVZjcFJfR0FWWWpydnVEcTBGNEtkcER6aGpqNGRHdmplTjBBT3NTb0xYOW1TRGQ5QUxKUThJT3dwS0thdTRWN1BSc1U?oc=5)**
  - *Publicatiedatum:* 2026-06-24
