# Field Note 2026-06-21

# Field Note — Nooch.earth
**Week 23 mei · 7-daagse meting**

---

## (1) Wat de data laat zien

95 bezoekers, 156 paginaweergaven, gemiddelde bezoekduur 76 seconden. De homepage trekt 88 van de 95 bezoekers — vrijwel iedereen stopt daar. De productpagina *The 269 Hi Natural* krijgt 4 bezoeken, de rest van het assortiment nauwelijks.

Verkeersbronnen: Direct/None (38), Google (33), Instagram (4), Ecosia (3), bluemarble (3). LinkedIn en cobbledgoods.com leveren elk 2 bezoekers. UTM-bronnen bevestigen kleine maar gerichte campagnes via Instagram (`ig`, 4) en bluemarble (3).

Nederland domineert met 67 van de 95 bezoekers. VS (9) en België (5) volgen op afstand.

Zoektermen: *regeneratief* stijgt (interest 47, richting omhoog), *veganistisch* en *duurzaam* dalen allebei — respectievelijk 51 en 44, beide richting omlaag. *Soberheid* en *plasticvrij* scoren nul. *Bewuste consument* heeft geen data voor NL.

---

## (2) Wat dit betekent voor de missie

De site haalt bezoekers binnen, maar 93% verlaat die op de homepage. Dat is geen groeifunnel, dat is een muur. De stijgende interesse in *regeneratief* sluit aan bij Nooch's kernwaarden, maar die term komt nergens zichtbaar terug in de huidige contentstructuur. Dalende termen als *duurzaam* en *veganistisch* bevestigen dat generieke labels steeds minder onderscheidend zijn.

---

## (3) Actie voor morgen

Schrijf één blogpost of landingspagina rond **"regeneratief"** — leg daarin concreet uit wat Nooch's productiemodel regeneratief maakt. Dit is het enige stijgende zoekwoord met directe aansluiting op de missie.
