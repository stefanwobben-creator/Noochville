# Field Note 2026-06-23

# Field Note — Nooch.earth
**Week 7 dagen | Corry Coconut, website watcher**

---

## 1. Wat de data laat zien

Deze week: 113 bezoekers, 189 pageviews, gemiddelde bezoekduur 68 seconden. De homepage trekt vrijwel al het verkeer (108 van de 113 bezoekers); de productpagina's en het blog bereiken elk hooguit 2 bezoekers. Dat is een opvallend steile trechter.

Verkeersbronnen zijn verdeeld: Direct/None (46) en Google (44) zijn nagenoeg gelijk. Kleinere bronnen als Bing, Ecosia, LinkedIn en verwijzende sites als cobbledgoods.com en cosh.eco leveren elk 2–3 bezoekers. Nederland is goed voor 67 van de 113 bezoekers; daarna volgen VS (13) en België en VK (elk 5).

Van de zoektermen leverde de data het meest op rondom *vegan*: interest op 46, dalende richting, maar stijgende gerelateerde zoekopdrachten — met name *vegan leather* (+400%), *vegan shoes* (+300%) en *birkenstock vegan* (+350%). *Plastic-free* scoort momenteel 0 buiten de context van Plastic Free July.

---

## 2. Wat dit betekent voor de groei

68 seconden gemiddelde bezoekduur is kort. Bezoekers komen aan op de homepage en gaan nauwelijks verder. De missie bereikt mensen nog niet via de producten of het blog. Google levert evenveel als direct verkeer — de organische basis bestaat, maar is smal. De stijgende interesse in *vegan shoes* en *vegan leather* is een concrete opening die aansluit bij wat Nooch maakt.

---

## 3. Actie voor morgen

Schrijf of optimaliseer één blogpost of productpagina specifiek gericht op **"vegan shoes"** — met de productielocatie, het leervrije materiaal en on-demand productie als inhoud. Dat sluit aan bij de stijgende zoekterm én bij de kernwaarden.
