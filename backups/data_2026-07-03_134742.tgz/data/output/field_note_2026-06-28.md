# Field Note 2026-06-28

**Field Note – Nooch.earth (7d data)**

**1. Verkeer en trends**
De homepage domineert met 112 van de 119 bezoekers (94%), gevolgd door /collections (5) en /policies/terms-of-service (5). Gemiddelde bezoekduur: 63 seconden. Google levert de meeste bezoekers (53), direct verkeer volgt (37). Nederland (60) en de VS (14) zijn de sterkste landen. Instagram en Ecosia scoren hoger dan Bing en DuckDuckGo. Opvallend: slechts 1 bezoeker via ChatGPT, ondanks de missie-gedreven focus op transparantie en ethiek. Zoektermen ontbreken in de data.

**2. Missie-gedreven groei**
De hoge concentratie op de homepage suggereert dat bezoekers vooral via directe kanalen (Google, direct) komen en niet via gerichte zoekopdrachten. De lage bezoekersaantallen op product- en collectiepagina’s (max. 5) wijzen op een gebrek aan organische discoverability. De sterke positie in Nederland en de VS biedt kansen voor lokale missie-gedreven keywords (bv. "duurzame schoenen Nederland").

**3. Actie voor morgen**
Focus op het optimaliseren van de homepage voor missie-gedreven zoekopdrachten (bv. "ethische schoenen", "duurzaam schoeisel") en het vergroten van de zichtbaarheid van productpagina’s via interne links en UTM-campagnes (Instagram, Ecosia). Prioriteit: testen welke keywords de meeste relevante bezoekers trekken.
