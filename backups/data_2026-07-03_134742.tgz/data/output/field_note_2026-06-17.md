# Field Note 2026-06-17

# Field Note — Nooch.earth · week 21

**Wat opvalt**

124 unieke bezoekers in zeven dagen, 206 paginaweergaven. De gemiddelde bezoekduur van 38 seconden is laag — bezoekers kijken even en vertrekken. 94% van het verkeer landt op de homepage; productpagina's (the-269-hi-natural, off-white, black) trekken elk slechts 3–4 bezoekers. De collectiepagina doet het nauwelijks beter. Dat is een trechter die te vroeg stopt.

Verkeersbronnen: Direct (47) en Google (39) zijn de koplopers. Opmerkelijk is bluemarble, goed voor 7 bezoekers via UTM — een kleine maar gerichte community-instroom. Hetkanwel.nl brengt 5 bezoekers aan. Ecosia (4) past inhoudelijk bij de doelgroep en verdient aandacht. E-mail via Shopify levert ook 4 bezoekers.

Geografisch domineert Nederland (90 van de 124 bezoekers), met België en Duitsland als bescheiden staart. De US-bezoeken (7) zijn interessant maar voorlopig ruis.

**Wat dit betekent**

De missie trekt mensen aan — ze vinden de site — maar de site overtuigt ze nog niet door te klikken naar producten. Dat is geen bereikprobleem, het is een relevantieprobleem op de homepage.

De bluemarble-koppeling werkt proportioneel goed: kleine bron, maar doelgericht. Dat model — kleine, waarde-gedeelde communities — is de juiste groeirichting voor een merk zonder externaliteiten.

**Actie voor morgen**

Voeg op de homepage één duidelijke doorklik toe richting de collectie, met een concrete missiezin erboven. Test of de bezoekduur stijgt en of het doorklikpercentage naar productpagina's verbetert.
