# Field Note 2026-06-27

**Field Note – Nooch.earth (7 dagen)**

**1. Verkeer en trends**
Het verkeer naar nooch.earth is laag maar stabiel: 122 bezoekers, 206 pageviews en een gemiddelde bezoekduur van 65 seconden. De homepage trekt 118 bezoekers (97% van het totaal), terwijl de rest van de site amper wordt bezocht. Slechts 5 bezoekers gingen naar /collections, en 3 naar /policies/terms-of-service. De productpagina’s van *The 269 Hi* (zwart/natuurlijk) kregen elk 2 bezoekers.

Google is de grootste bron (54 bezoekers), gevolgd door directe bezoeken (38). Instagram levert 9 bezoekers, Ecosia 4. Nederland domineert met 68 bezoekers, gevolgd door de VS (14) en België (10). UTM-tracking toont 9 bezoekers via Instagram en 1 via ChatGPT. Trends zijn niet beschikbaar.

**2. Missie-gedreven groei**
De data toont een sterke focus op de homepage, wat wijst op een gebrek aan diepgaande verkenning. De lage bezoekersaantallen op collectie- en productpagina’s duiden op een zwakke productdiscovery. De dominantie van Google en directe bezoeken suggereert dat merkbekendheid nog beperkt is. De internationale verdeling (NL, VS, BE) biedt groeikansen, maar de lage engagement (65s) vraagt om verbetering.

**3. Actie voor morgen**
Optimaliseer de productdiscovery: verbeter de navigatie naar /collections en productpagina’s via interne links op de homepage en duidelijke call-to-actions. Test een eenvoudige A/B-test met een banner op de homepage die bezoekers doorverwijst naar de collecties.
