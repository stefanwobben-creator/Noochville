# Field Note 2026-06-19

# Field Note — Nooch.earth | 7-dagenrapport

## 1. Wat opvalt

117 bezoekers, 189 pageviews, gemiddelde bezoekduur 58 seconden. Die bezoekduur is laag: mensen kijken en vertrekken snel. De homepage trekt 107 van de 117 bezoekers — vrijwel niemand bereikt de collectie of productpagina's. De twee blogteksten over maatvoering en on-demand productie halen elk slechts 2 bezoekers.

Google (36) is de grootste meetbare organische bron, gevolgd door bluemarble (6 via UTM) en hetkanwel.nl (5). Instagram levert 3 bezoekers, bevestigd door de ig-UTM. 88 van de 117 bezoekers komen uit Nederland; België (5) en de VS (8) zijn kleine maar opvallende staarten.

In de trenddata stijgen **soberheid** (interest 100, stijgend) en **duurzaam** (79, stijgend) en **veganistisch** (57, stijgend). Dat zijn precies de termen die passen bij de Nooch-koper: iemand die minder maar bewuster koopt. **Regeneratief** (41) en **plasticvrij** (13) dalen allebei.

## 2. Wat dit betekent

De missie resoneert bij een kleine, gerichte groep — maar de site converteert nauwelijks door naar producten. De stijgende trend rond *soberheid* en *duurzaam* toont dat de doelgroep groeit; Nooch is er nog niet zichtbaar voor.

## 3. Actie voor morgen

Schrijf één blogpost die *soberheid* en *duurzame schoenen* combineert, met een directe interne link naar een productpagina. Geen lange tekst — 400 woorden is genoeg om de zoekterm te raken en de doorklik te testen.
