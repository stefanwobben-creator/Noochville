# Field Note 2026-06-25

**Field Note – Nooch.earth (7 dagen)**

**Verkeer & trends**
De site trekt 115 bezoekers (198 pageviews) met een gemiddelde bezoekduur van 97 seconden. De homepage domineert met 111 bezoekers; de rest van de pagina’s scoren onder de 5. Google levert de meeste bezoekers (54), gevolgd door directe bezoeken (39). Nederland is veruit de grootste markt (68 bezoekers), met België (8) en de VS (12) als opvallende buitenlandse bezoekers. Instagram en LinkedIn genereren elk 2 bezoekers via UTM-tracking, terwijl ChatGPT 1 bezoeker stuurt.

**Missie-gedreven groei**
De focus op de homepage en directe bezoeken suggereert dat merkbekendheid en mond-tot-mondreclame nog de belangrijkste groeidrijvers zijn. De lage bezoekersaantallen op product- en collectiepagina’s wijzen op een gebrek aan organische zoekintentie of onvoldoende zichtbaarheid in relevante zoekopdrachten. De internationale verdeling toont potentie in Nederland/België, maar de VS en andere markten blijven onderbenut.

**Actie voor morgen**
Versterk de zichtbaarheid van de collectie- en productpagina’s via interne links op de homepage en optimaliseer de UTM-tracking voor sociale media om de impact van campagnes beter te meten.
