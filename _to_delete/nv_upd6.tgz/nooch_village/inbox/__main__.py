"""CLI voor de human inbox — het geauthenticeerde lokale approval-oppervlak.

Gebruik:
    python -m nooch_village.inbox          # toon pending items
    python -m nooch_village.inbox list     # idem
    python -m nooch_village.inbox all      # toon alle items incl. gesloten
    python -m nooch_village.inbox show <id>

    python -m nooch_village.inbox approve <id> [reden]
    python -m nooch_village.inbox reject  <id> [reden]
    python -m nooch_village.inbox amend   <id> <tekst>
    python -m nooch_village.inbox defer   <id> [reden]

Beveiligingsgrens:
    Approvals en activaties mogen UITSLUITEND op dit geauthenticeerde lokale
    oppervlak bevestigd worden. Geen extern of ongeauthenticeerd kanaal mag
    een approval triggeren — notificaties zijn altijd alleen een heads-up.
"""
from __future__ import annotations
import os, sys, time
from datetime import datetime


def _data_dir() -> str:
    # __file__ = .../nooch_village/inbox/__main__.py → project root is two levels up
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data"))


def _inbox_only():
    """Laad HumanInbox direct uit JSON — geen Village, geen sync_unmanned."""
    from nooch_village.human_inbox import HumanInbox
    return HumanInbox(os.path.join(_data_dir(), "human_inbox.json"))


def _records_only():
    """Laad Records direct — voor archiveren bij reject activation."""
    from nooch_village.governance import Records
    return Records(os.path.join(_data_dir(), "governance_records.json"))


def _fmt_ts(ts) -> str:
    if ts is None:
        return "—"
    return datetime.fromtimestamp(float(ts)).strftime("%Y-%m-%d %H:%M")


def _status_icon(status: str) -> str:
    return {"pending": "⏳", "approved": "✅", "rejected": "❌",
            "amended": "✏️ ", "deferred": "⏸️ ", "resolved": "✔️ ",
            "withdrawn": "⟲"}.get(status, "?")


def _type_icon(typ: str) -> str:
    return {"escalation": "🏛️", "activation": "🔧", "keyword": "📚",
            "keyword_batch": "📊"}.get(typ, "?")


def _print_item_summary(item: dict) -> None:
    icon   = _type_icon(item["type"])
    status = _status_icon(item["status"])
    print(f"  {item['id']}  {icon} {item['type']:<11} {status} {item['status']:<10} "
          f"{item['subject']:<22} {_fmt_ts(item['created_at'])}")


def _print_item_full(item: dict) -> None:
    icon = _type_icon(item["type"])
    print(f"\n{'─'*65}")
    print(f"{icon}  {item['type'].upper()}  [{item['id']}]")
    print(f"{'─'*65}")
    print(f"Status    : {_status_icon(item['status'])} {item['status']}")
    print(f"Subject   : {item['subject']}")
    print(f"Aangemaakt: {_fmt_ts(item['created_at'])}")

    pr = item.get("proposed_resolution")
    if pr:
        print(f"\n📝 Voorstel tot sluiten door {pr['by']}: {pr['reason']}")
        print(f"   Bevestig met: python -m nooch_village.inbox confirm {item['id']}")

    ctx = item.get("context", {})

    if item["type"] == "escalation":
        print(f"\n── Voorstel ──")
        print(f"Voorstel-ID : {ctx.get('proposal_id')}")
        print(f"Proposer    : {ctx.get('proposer_role')}")
        print(f"Change-kind : {ctx.get('change_kind')}")
        purpose = ctx.get("purpose")
        if purpose:
            print(f"Purpose     : {purpose[:80]}")
        accs = ctx.get("add_accountabilities", [])
        if accs:
            print(f"Accountabilities ({len(accs)}):")
            for a in accs:
                print(f"  · {a[:80]}")
        doms = ctx.get("add_domains", [])
        if doms:
            print(f"Domeinen    : {doms}")
        tension = ctx.get("tension")
        if tension:
            print(f"\nTension  : {tension[:120]}")
        trigger = ctx.get("trigger_example")
        if trigger:
            print(f"Trigger  : {trigger[:120]}")
        rationale = ctx.get("rationale")
        if rationale:
            print(f"Rationale: {rationale[:120]}")
        print(f"\n── Gate-uitkomst ──")
        print(f"Poort    : {ctx.get('gate')}")
        print(f"Reden    : {ctx.get('gate_reason')}")
        print(f"\n── Acties ──")
        print(f"  approve <id> [reden]   → governance_verdict approve → Secretary adopteert")
        print(f"  reject  <id> [reden]   → afgewezen, gesloten")
        print(f"  amend   <id> <tekst>   → gewijzigd voorstel opnieuw door de poort")
        print(f"  defer   <id> [reden]   → uitgesteld, blijft geregistreerd")

    elif item["type"] == "activation":
        print(f"\n── Rol ──")
        print(f"Source    : {ctx.get('source')}")
        print(f"Purpose   : {ctx.get('purpose','')[:100]}")
        accs = ctx.get("accountabilities", [])
        if accs:
            print(f"Accountabilities ({len(accs)}):")
            for a in accs:
                print(f"  · {a[:80]}")
        doms = ctx.get("domains", [])
        if doms:
            print(f"Domeinen  : {doms}")
        skills_now = ctx.get("current_skills", [])
        print(f"Skills nu : {skills_now or '(geen — nog te schrijven)'}")

        plan = ctx.get("activation_plan", {})
        if plan:
            print(f"\n── Activatieplan (beschrijving; code schrijf je daarna per hand) ──")
            print(f"Klasse-naam  : {plan.get('class_name')}")
            print(f"Klasse-bestand: {plan.get('class_file')}")
            skills_to_write = plan.get("skills_to_write", [])
            if skills_to_write:
                print(f"Skills te schrijven ({len(skills_to_write)}):")
                for s in skills_to_write:
                    print(f"  · {s['label']:<32} → {s['file']}")
                    print(f"    klasse: {s['class_name']}")
            else:
                print("Skills te schrijven: (geen externe API's gevonden in accountabilities)")
            print(f"CLASS_MAP-entry : {plan.get('class_map_entry')}")
            print(f"\n⚠  {plan.get('note','')}")

        print(f"\n── Acties ──")
        print(f"  approve <id> [reden]   → green-light; code daarna handmatig + code-review")
        print(f"  reject  <id> [reden]   → niet implementeren, gesloten")
        print(f"  amend   <id> <tekst>   → plan aanpassen, item bijwerken")
        print(f"  defer   <id> [reden]   → uitstellen, blijft geregistreerd")

    elif item["type"] == "means_gap":
        print(f"\n── Capaciteitsgrens ──")
        print(f"Gap-key     : {ctx.get('gap_key', item['subject'])}")
        desc = ctx.get("description", "")
        if desc:
            print(f"Beschrijving: {desc}")

    elif item["type"] == "verband":
        print(f"\n── Verband-voorstel (3c) ──")
        print(f"Kaart A   : {ctx.get('kaart_a_id')}")
        print(f"Kaart B   : {ctx.get('kaart_b_id')}")
        claim = ctx.get("voorstel_claim", "")
        if claim:
            print(f"Voorstel  : {claim}")
        print(f"\n── Acties ──")
        print(f"  approve <id> [reden]   → touwtje leggen tussen de twee kaartjes")
        print(f"  reject  <id> [reden]   → geen touwtje, gesloten")
        print(f"  defer   <id> [reden]   → uitstellen, blijft geregistreerd")

    elif item["type"] == "content_suggestion":
        print(f"\n── Content-kans (model C) ──")
        print(f"Cluster   : {ctx.get('seed_id')}")
        print(f"Kaartjes  : {', '.join(ctx.get('cluster_ids', []))}")
        if ctx.get("reason"):
            print(f"Waarom    : {ctx.get('reason')}")
        print(f"\n── Acties ──")
        print(f"  approve <id>           → kies lezer + soort, de strateeg maakt een draft")
        print(f"  reject  <id> [reden]   → geen draft, gesloten")

    elif item["type"] == "content_draft":
        print(f"\n── Content-draft (eerste draft, jij herschrijft) ──")
        print(f"Cluster   : {ctx.get('seed_id')}  |  Soort: {ctx.get('kind')}")
        print(f"\n{ctx.get('text', '')}\n")
        print(f"── Acties ──")
        print(f"  check <id> <bestand>   → eindcheck op jouw herschreven tekst (claim-gate + copyregels)")
        print(f"  approve <id>           → markeer als gebruikt/klaar")
        print(f"  reject  <id> [reden]   → verworpen, gesloten")

    elif item["type"] == "keyword":
        ctx = item.get("context", {})
        demand = ctx.get("demand", {})
        src    = demand.get("source", "?")
        signal = demand.get("signal", "?")
        interest = demand.get("interest")
        print(f"\n── Woord ──")
        print(f"Woord     : {ctx.get('word')}")
        print(f"Bron      : {src}  |  Signaal: {signal}"
              + (f"  |  Interest: {interest}" if interest else ""))
        pos = demand.get("position")
        if pos:
            print(f"Positie   : {pos:.1f}  (bucket: {demand.get('bucket','?')})")
        locale = demand.get("locale")
        if locale:
            print(f"Locale    : {locale}")
        print(f"\n── Reden escalatie ──")
        print(f"{ctx.get('reason','')}")
        print(f"\n── Acties ──")
        print(f"  approve <id> [reden]   → goedkeuren → in bibliotheek als 'approved'")
        print(f"  reject  <id> [reden]   → verbieden → in bibliotheek als 'forbidden'")
        print(f"  amend   <id> <tekst>   → notitie toevoegen, opnieuw beoordelen")
        print(f"  defer   <id> [reden]   → uitstellen, blijft geregistreerd")

    elif item["type"] == "keyword_batch":
        ctx        = item.get("context", {})
        candidates = ctx.get("candidates", [])
        print(f"\n── Batch ──")
        print(f"Markt       : {ctx.get('market')}")
        print(f"Tier        : {ctx.get('tier')}")
        print(f"Credits     : {ctx.get('estimated_credits')} (geschat, 1 credit per keyword)")
        print(f"Kandidaten ({len(candidates)}):")
        for c in candidates:
            print(f"  · {c}")
        print(f"\n── Acties ──")
        print(f"  approve <id> [reden]   → credits uitgeven + meten + publiceren naar curatie-lus")
        print(f"  reject  <id> [reden]   → afwijzen, geen credits uitgegeven")
        print(f"  defer   <id> [reden]   → uitstellen, blijft geregistreerd")

    res = item.get("resolution")
    if res:
        print(f"\n── Beslissing ──")
        print(f"Actie     : {res.get('action')}")
        if res.get("reason"):
            print(f"Reden     : {res['reason']}")
        if res.get("amendment"):
            print(f"Wijziging : {res['amendment']}")
        print(f"Opgelost  : {_fmt_ts(item.get('resolved_at'))}")
    print()


def _load():
    from nooch_village.village import Village
    v = Village(heartbeat_seconds=86400)
    return v.human_inbox, v


def _approve_keyword_batch(inbox, item, iid: str, reason: str, _load_fn=None) -> None:
    """Approve een keyword_batch: meet via KE, publiceer levende termen naar curatie-lus.

    Spiegelt de means_gap-lifecycle: Village laden → start → actie → poll/timeout → stop.
    De uitvoeringskern (run_approved_keyword_batch) is al getest; dit is dunne glue.
    """
    from nooch_village.keyword_integration import run_approved_keyword_batch
    from nooch_village.keyword_runner import make_keywords_runner
    from nooch_village.skills_impl.keywords_everywhere import KeywordsEverywhereSkill

    ctx   = item["context"]
    batch = {
        "market":            ctx["market"],
        "country":           ctx.get("geo") or ctx["market"],   # meet in de juiste geo
        "locale":            ctx.get("locale"),                 # label de taal correct
        "tier":              ctx["tier"],
        "data_source":       "cli",
        "candidates":        ctx["candidates"],
        "estimated_credits": ctx["estimated_credits"],
    }

    load_fn = _load_fn or _load
    _, v    = load_fn()

    min_volume = int(v.context.settings.get("keyword_batch_min_volume", "100"))
    decided: list[str] = []

    def _on_decided(e):
        decided.append(e.data.get("word", ""))

    v.bus.subscribe("keyword_decided", _on_decided)

    v.start()
    time.sleep(0.1)

    skill   = KeywordsEverywhereSkill()
    runner  = make_keywords_runner(skill, v.context)
    library = v.context.library

    try:
        summary = run_approved_keyword_batch(
            batch, runner, v.bus, library,
            from_id="trends",
            min_volume=min_volume,
            approved_by="human",
        )
    except Exception as exc:
        v.stop()
        print(f"\n  ✘ Meting mislukt: {exc}")
        print(f"     Item blijft pending — controleer het creditplafond of de API-sleutel.")
        return

    # Wacht tot Librarian de gepubliceerde termen verwerkt heeft
    _timeout = int(v.context.settings.get("inbox_approve_timeout", "5"))
    expected = len(summary["published"])
    for _ in range(_timeout * 10):
        if len(decided) >= expected:
            break
        time.sleep(0.1)

    v.stop()

    inbox.resolve(iid, "approved", reason=reason, extra=summary)
    market = ctx["market"]
    tier   = ctx["tier"]
    print(f"\n✅ Batch {market}/{tier} goedgekeurd.")
    print(f"   Credits uitgegeven : {summary['credits_spent']}")
    print(f"   Gemeten            : {summary['measured']}")
    print(f"   Boven min_volume   : {summary['live']} (drempel: {min_volume})")
    print(f"   Gepubliceerd       : {len(summary['published'])}")
    for w in summary["published"]:
        print(f"     · {w}")
    if summary["skipped_dedup"]:
        print(f"   Al bekend (dedup)  : {len(summary['skipped_dedup'])}")
    if summary["errors"]:
        print(f"   Fouten             : {len(summary['errors'])}")
        for e in summary["errors"]:
            print(f"     · {e['word']}: {e['error']}")


def _content_suggestion_event(item: dict, kind: str, audience: str, outcome: str) -> dict:
    """Bouw de payload voor content_suggestion_approved: de brief waarmee de strateeg
    draft. De mens kiest lezer (audience) en soort (kind) bij het goedkeuren."""
    ctx = item.get("context", {})
    return {
        "seed_id":         ctx.get("seed_id"),
        "kind":            kind or "blog",
        "audience":        audience,
        "desired_outcome": outcome,
    }


def _content_check_report(item: dict, text: str, context) -> dict:
    """Draai de eindcheck (content_check-skill) op de door de mens herschreven tekst,
    met de kind + claim-ids van de draft. Geeft het rapport-dict terug."""
    from nooch_village.skills_impl.content_check import ContentCheckSkill
    ctx = item.get("context", {})
    return ContentCheckSkill().run({
        "text":              text,
        "claim_insight_ids": ctx.get("claim_insight_ids", []),
        "kind":              ctx.get("kind", "blog"),
    }, context)


def _approve_verband(inbox, item, iid: str, notes, reason: str = "") -> bool:
    """Approve een verband (3c): sluit het item en schrijf het touwtje tussen de twee
    kaartjes (notes.link). Retourneert True als de link gelegd is (beide kaartjes
    bestaan), anders False (het item is dan wel netjes afgesloten)."""
    ctx = item.get("context", {})
    a, b = ctx.get("kaart_a_id"), ctx.get("kaart_b_id")
    inbox.resolve(iid, "approved", reason=reason)
    if not (a and b):
        return False
    return notes.link(a, b) is not None


def _approve_means_gap(inbox, item, _load_fn=None):
    """Approve een means_gap: prompt voor skill-details, dien amend_role in, wacht op gate."""
    from nooch_village.models import Proposal, GovernanceChange, ChangeKind

    ctx         = item["context"]
    gap_key     = ctx.get("gap_key", item["subject"])
    description = ctx.get("description", "")
    role_id     = ctx.get("role_id")

    if not role_id:
        # Oud item zonder role_id: afleiden via classify_gap
        try:
            from nooch_village.gap_classifier import classify_gap
            recs = _records_only()
            _, role_id, _ = classify_gap(description, recs.all())
        except Exception:
            role_id = None
        if not role_id:
            print(f"  ✘ Kan role_id niet afleiden voor gap '{gap_key}'.")
            print(f"    Herstart de village zodat het item wordt ververst, of amend het item.")
            return

    print(f"\n── Skill toevoegen aan '{role_id}' ──")
    print(f"Gap         : {gap_key}")
    print(f"Omschrijving: {description[:120]}")
    print()

    try:
        skill_name = ""
        while not skill_name:
            skill_name = input("Skill-naam (bijv. 'english_ngram_2024'): ").strip()
            if not skill_name:
                print("  ✘ Skill-naam mag niet leeg zijn.")

        rationale = ""
        while len(rationale) < 10:
            rationale = input("Reden (min. 10 tekens): ").strip()
            if len(rationale) < 10:
                print(f"  ✘ Rationale te kort ({len(rationale)} tekens, min. 10).")

        alternatives = ""
        while not alternatives:
            alternatives = input("Alternatieven overwogen? (of 'geen'): ").strip()
            if not alternatives:
                print("  ✘ Dit veld is verplicht.")
    except (KeyboardInterrupt, EOFError):
        print("\n  (afgebroken)")
        return

    proposal = Proposal(
        proposer_role="human-cli",
        change=GovernanceChange(
            kind=ChangeKind.AMEND_ROLE,
            role_id=role_id,
            add_skills=[skill_name],
        ),
        tension=description,
        trigger_example=f"means_gap:{gap_key}",
        rationale=rationale,
        source="sensed",
    )

    load_fn = _load_fn or _load
    _, v    = load_fn()
    outcome: dict = {}
    target_pid    = proposal.id

    def _on_changed(e):
        if e.data.get("proposal_id") == target_pid:
            outcome["ok"] = True

    def _on_invalid(e):
        if e.data.get("proposal_id") == target_pid:
            outcome["gate"]   = e.data.get("gate", "G0")
            outcome["reason"] = e.data.get("reason", "")

    def _on_review(e):
        if e.data.get("proposal_id") == target_pid:
            outcome["gate"]   = e.data.get("gate", "?")
            outcome["reason"] = e.data.get("reason", "")

    v.bus.subscribe("governance_changed",          _on_changed)
    v.bus.subscribe("proposal_invalid",            _on_invalid)
    v.bus.subscribe("governance_review_requested", _on_review)

    v.start()
    time.sleep(0.1)
    v.submit_proposal(proposal)

    _timeout = int(v.context.settings.get("inbox_approve_timeout", "5"))
    for _ in range(_timeout * 10):
        if outcome:
            break
        time.sleep(0.1)

    v.stop()

    if outcome.get("ok"):
        inbox.resolve(item["id"], "approved", reason=rationale, extra={
            "skill_added":             skill_name,
            "rationale":               rationale,
            "alternatives_considered": alternatives,
            "resolved_by":             "human-cli",
        })
        print(f"\n✅ Skill '{skill_name}' toegevoegd aan '{role_id}' — voorstel aangenomen.")
    elif "gate" in outcome:
        gate        = outcome["gate"]
        reason_text = outcome["reason"]
        print(f"\n  ✘ Voorstel geblokkeerd door poort {gate}: {reason_text}")
        print(f"     Item blijft pending — kies een andere skill of pas het voorstel aan.")
    else:
        print(f"\n  ✘ Geen uitkomst ontvangen binnen timeout. Controleer het village-log.")


def main(argv: list[str]) -> None:
    cmd = argv[0] if argv else "list"

    if cmd in ("list", "pending"):
        inbox = _inbox_only()
        items = inbox.pending()
        print(f"\n⏳ Human inbox — {len(items)} pending item(s)\n")
        if not items:
            print("  (leeg — geen beslissingen nodig)\n")
        else:
            print(f"  {'ID':<14} {'Type':<13} {'Status':<12} {'Subject':<24} Aangemaakt")
            print("  " + "─" * 72)
            for item in items:
                _print_item_summary(item)
            print()

    elif cmd == "all":
        inbox = _inbox_only()
        items = inbox.all()
        print(f"\n📋 Human inbox — alle {len(items)} item(s)\n")
        if not items:
            print("  (leeg)\n")
        else:
            print(f"  {'ID':<14} {'Type':<13} {'Status':<12} {'Subject':<24} Aangemaakt")
            print("  " + "─" * 72)
            for item in sorted(items, key=lambda x: x["created_at"]):
                _print_item_summary(item)
            print()

    elif cmd == "show":
        if len(argv) < 2:
            print("Gebruik: inbox show <id>"); sys.exit(1)
        inbox = _inbox_only()
        item = inbox.get(argv[1])
        if item is None:
            print(f"Item '{argv[1]}' niet gevonden."); sys.exit(1)
        _print_item_full(item)

    elif cmd == "approve":
        if len(argv) < 2:
            print("Gebruik: inbox approve <id> [reden]"); sys.exit(1)
        iid    = argv[1]
        reason = " ".join(argv[2:])

        # Lees item zonder Village (geen sync_unmanned side-effect)
        inbox = _inbox_only()
        item = inbox.get(iid)
        if item is None:
            print(f"Item '{iid}' niet gevonden."); sys.exit(1)
        if item["status"] != "pending":
            print(f"Item '{iid}' is al '{item['status']}', niet pending."); sys.exit(1)

        if item["type"] == "escalation":
            # Escalatie vereist de bus (governance_verdict-event)
            from nooch_village.event_bus import Event
            _, v = _load()
            v.start()
            time.sleep(0.1)
            ok = v.approve_escalation(iid, reason=reason)
            time.sleep(0.5)
            v.stop()
            if ok:
                print(f"✅ Escalatie {iid} goedgekeurd → governance_verdict approve gestuurd.")
                pid = item["context"].get("proposal_id")
                rec = v.records.get(pid.split(":")[0] if pid and ":" in pid else item["subject"])
                if rec:
                    print(f"   Record v{rec.version} opgeslagen voor '{rec.id}'.")
            else:
                print(f"✘ Kon escalatie {iid} niet goedkeuren (item niet pending of niet gevonden).")

        elif item["type"] == "activation":
            inbox.resolve(iid, "approved", reason=reason)
            plan = item["context"].get("activation_plan", {})
            print(f"✅ Activatie '{item['subject']}' green-light gegeven [{iid}].")
            print(f"\nVolgende stappen (handmatig, volgorde telt):")
            for i, s in enumerate(plan.get("skills_to_write", []), 1):
                print(f"  {i}. Schrijf {s['file']}")
                print(f"     klasse: {s['class_name']}, skill_id: {s['skill_id']}")
            n = len(plan.get("skills_to_write", []))
            print(f"  {n+1}. Schrijf klasse {plan.get('class_name')} in {plan.get('class_file')}")
            print(f"  {n+2}. Registreer skills in Village.__init__")
            print(f"  {n+3}. Voeg toe aan CLASS_MAP: {plan.get('class_map_entry')}")
            print(f"\n⚠  Approval green-light de implementatie.")
            print(f"   Iedere stap hierboven passeert daarna nog de normale per-edit code-review.")

        elif item["type"] == "means_gap":
            _approve_means_gap(inbox, item)

        elif item["type"] == "keyword":
            # Eén gedeeld gevalideerd pad (ook gebruikt door de cockpit): sluit het item
            # en cureer het woord. Geen volledige Village nodig, alleen de bibliotheek.
            from nooch_village.library import Library
            from nooch_village.inbox_actions import decide_keyword
            library = Library(os.path.join(_data_dir(), "library.json"))
            res = decide_keyword(inbox, library, iid, "approve", reason=reason)
            if res["ok"]:
                print(f"✅ '{res['word']}' goedgekeurd → in bibliotheek als 'approved'.")
            else:
                print(f"✘ {res['error']}")

        elif item["type"] == "keyword_batch":
            _approve_keyword_batch(inbox, item, iid, reason)

        elif item["type"] == "verband":
            # Verband vereist de notes-store via Village-context
            _, v = _load()
            a = item["context"].get("kaart_a_id")
            b = item["context"].get("kaart_b_id")
            ok = _approve_verband(inbox, item, iid, v.context.notes, reason)
            if ok:
                print(f"✅ Verband goedgekeurd → touwtje gelegd: {a} ↔ {b}.")
            else:
                print(f"✘ Item gesloten, maar touwtje niet gelegd (kaartje ontbreekt): {a}, {b}.")

        elif item["type"] == "content_suggestion":
            # Mens kiest de brief; de levende strateeg draft op het event.
            from nooch_village.event_bus import Event
            kind = input("Soort (blog/sales_page/passport) [blog]: ").strip() or "blog"
            audience = input("Lezer/persona: ").strip()
            outcome = input("Gewenste emotie/uitkomst: ").strip()
            payload = _content_suggestion_event(item, kind, audience, outcome)
            inbox.resolve(iid, "approved", reason=reason)
            _, v = _load()
            v.start()
            time.sleep(0.1)
            v.bus.publish(Event("content_suggestion_approved", payload, "human"))
            seed = item["context"].get("seed_id")
            timeout = int(v.context.settings.get("inbox_approve_timeout", "5"))
            for _ in range(timeout * 10):
                if any(x["type"] == "content_draft" and x["context"].get("seed_id") == seed
                       for x in v.human_inbox.all()):
                    break
                time.sleep(0.1)
            v.stop()
            print(f"✅ Content-kans goedgekeurd → strateeg draft cluster '{seed}'. "
                  f"Bekijk de draft met 'inbox list'.")

        elif item["type"] == "content_draft":
            inbox.resolve(iid, "approved", reason=reason)
            print(f"✅ Content-draft '{item['subject']}' gemarkeerd als gebruikt. "
                  f"Tip: 'inbox check <id> <bestand>' voor de eindcheck op je herschreven tekst.")

        elif item["type"] == "suggestion":
            # Gap C: kandidaat voor een nieuw voorstel. Approve = de mens accepteert/pakt dit op;
            # een nieuwe rol of means bouwen loopt apart via governance (geen automatische geboorte).
            inbox.resolve(iid, "approved", reason=reason)
            print(f"✅ Suggestie '{item['subject']}' geaccepteerd [{iid}].")
            print("   (Een nieuwe rol/means hiervoor loopt via het governance-proces.)")

        else:
            # Vangnet: geen type-specifieke afhandeling → toch sluiten met reden, zodat geen
            # enkel item-type stil blijft hangen bij approve.
            inbox.resolve(iid, "approved", reason=reason)
            print(f"✅ Item '{item['subject']}' [{iid}] goedgekeurd (type: {item['type']}).")

    elif cmd == "check":
        if len(argv) < 3:
            print("Gebruik: inbox check <id> <pad-naar-tekstbestand>"); sys.exit(1)
        iid, path = argv[1], argv[2]
        inbox = _inbox_only()
        item = inbox.get(iid)
        if item is None or item["type"] != "content_draft":
            print(f"Item '{iid}' is geen content_draft."); sys.exit(1)
        if not os.path.exists(path):
            print(f"Bestand niet gevonden: {path}"); sys.exit(1)
        text = open(path, encoding="utf-8").read()
        _, v = _load()
        report = _content_check_report(item, text, v.context)
        print(f"\n── Eindcheck ──")
        print(f"Gate ok          : {report['gate_ok']}")
        if report["forbidden_words"]:
            print(f"Verboden woorden : {report['forbidden_words']}")
        for ci in report["claim_issues"]:
            print(f"Claim-issue      : {ci['insight_id']} — {ci['reason']}")
        print(f"\nSuggesties:\n{report.get('suggestions') or '(geen / geen LLM)'}")

    elif cmd == "reject":
        if len(argv) < 2:
            print("Gebruik: inbox reject <id> [reden]"); sys.exit(1)
        iid    = argv[1]
        reason = " ".join(argv[2:])

        # Lees item zonder Village (geen sync_unmanned side-effect)
        inbox = _inbox_only()
        item = inbox.get(iid)
        if item is None:
            print(f"Item '{iid}' niet gevonden."); sys.exit(1)
        if item["status"] != "pending":
            print(f"Item '{iid}' is al '{item['status']}'."); sys.exit(1)

        if item["type"] == "escalation":
            # Escalatie vereist de bus (governance_verdict-event)
            from nooch_village.event_bus import Event
            pid = item["context"].get("proposal_id")
            _, v = _load()
            v.start()
            time.sleep(0.1)
            inbox.resolve(iid, "rejected", reason=reason)
            v.bus.publish(Event(
                "governance_verdict",
                {"proposal_id": pid, "decision": "reject", "reason": reason},
                "human"))
            time.sleep(0.3)
            v.stop()
            print(f"❌ Item {iid} afgewezen. Reden: {reason or '(geen)'}")

        elif item["type"] == "activation":
            # Archiveer het onderliggende sensed record zodat sync_unmanned het niet opnieuw oppervlakt
            records = _records_only()
            inbox.resolve(iid, "rejected", reason=reason)
            role_id = item["subject"]
            rec = records.get(role_id)
            if rec and rec.source == "sensed" and not rec.archived:
                rec.archived = True
                rec.version += 1
                records.put(rec)
                print(f"❌ Activatie '{role_id}' afgewezen en gearchiveerd (v{rec.version}). "
                      f"Reden: {reason or '(geen)'}")
            else:
                print(f"❌ Activatie '{role_id}' afgewezen. Reden: {reason or '(geen)'}")

        elif item["type"] == "keyword":
            # Eén gedeeld gevalideerd pad (ook gebruikt door de cockpit).
            from nooch_village.library import Library
            from nooch_village.inbox_actions import decide_keyword
            library = Library(os.path.join(_data_dir(), "library.json"))
            res = decide_keyword(inbox, library, iid, "reject", reason=reason)
            if res["ok"]:
                print(f"❌ '{res['word']}' verboden → in bibliotheek als 'forbidden'.")
            else:
                print(f"✘ {res['error']}")

        elif item["type"] == "keyword_batch":
            # Geen credits uitgegeven, niets om terug te draaien
            inbox.resolve(iid, "rejected", reason=reason)
            print(f"❌ Batch '{item['subject']}' afgewezen. Geen credits uitgegeven.")
            if reason:
                print(f"   Reden: {reason}")

        else:
            inbox.resolve(iid, "rejected", reason=reason)
            print(f"❌ Item {iid} afgewezen. Reden: {reason or '(geen)'}")

    elif cmd == "amend":
        if len(argv) < 3:
            print("Gebruik: inbox amend <id> <wijziging-tekst>"); sys.exit(1)
        iid       = argv[1]
        amendment = " ".join(argv[2:])
        inbox     = _inbox_only()
        item = inbox.get(iid)
        if item is None:
            print(f"Item '{iid}' niet gevonden."); sys.exit(1)
        if item["status"] != "pending":
            print(f"Item '{iid}' is al '{item['status']}'."); sys.exit(1)
        inbox.resolve(iid, "amended", amendment=amendment)
        print(f"✏️  Item {iid} gemarkeerd als amended.")
        print(f"   Wijziging: {amendment}")
        if item["type"] == "escalation":
            print(f"\nVolgende stap: pas het voorstel aan en dien het opnieuw in via")
            print(f"  Village.submit_proposal() met de wijziging verwerkt.")
        elif item["type"] == "activation":
            print(f"\nVolgende stap: werk de rol-definitie bij en dien opnieuw in via")
            print(f"  inbox.add_activation() na aanpassing van het governance-record.")

    elif cmd == "defer":
        if len(argv) < 2:
            print("Gebruik: inbox defer <id> [reden]"); sys.exit(1)
        iid    = argv[1]
        reason = " ".join(argv[2:])
        inbox  = _inbox_only()
        item = inbox.get(iid)
        if item is None:
            print(f"Item '{iid}' niet gevonden."); sys.exit(1)
        if item["status"] != "pending":
            print(f"Item '{iid}' is al '{item['status']}'."); sys.exit(1)
        inbox.resolve(iid, "deferred", reason=reason)
        print(f"⏸️  Item {iid} uitgesteld. Reden: {reason or '(geen)'}")
        print(f"   Item blijft geregistreerd in data/human_inbox.json.")

    elif cmd == "confirm":
        # Bevestig met één klik een door een rol voorgestelde sluiting ("ik dek dit nu").
        if len(argv) < 2:
            print("Gebruik: inbox confirm <id>"); sys.exit(1)
        iid   = argv[1]
        inbox = _inbox_only()
        item  = inbox.get(iid)
        if item is None:
            print(f"Item '{iid}' niet gevonden."); sys.exit(1)
        pr = item.get("proposed_resolution")
        if not pr:
            print(f"Item '{iid}' heeft geen voorgestelde sluiting om te bevestigen."); sys.exit(1)
        if inbox.confirm_resolution(iid):
            print(f"✅ Item {iid} gesloten. Voorgesteld door {pr['by']}: {pr['reason']}")
        else:
            print(f"Kon item {iid} niet sluiten (al gesloten?)."); sys.exit(1)

    else:
        print(f"Onbekend commando: '{cmd}'")
        print("Gebruik: list | all | show <id> | approve | reject | amend | defer | confirm")
        sys.exit(1)


if __name__ == "__main__":
    main(sys.argv[1:])
