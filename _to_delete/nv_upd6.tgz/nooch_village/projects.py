"""ProjectLedger — de proces-store: volgt de status van lopend en gepland werk.

Opslag: data/projects.json (atomic write). Elke entry is een project-record:
  id, owner, scope, trigger, status, blocked_on, created_at, updated_at, outcome.
Governance-records en human_inbox blijven ongemoeid.
"""
from __future__ import annotations
import os, time, uuid
from nooch_village.util import atomic_write_json, read_json, synchronized as _synchronized

# MODELWIJZIGING (scope harry_hemp keyword_research): 'role' toegevoegd als geldige trigger voor een
# project dat een ROL autonoom initieert (niet 'human'/UI, niet 'clock'/puls, niet 'tension', niet
# 'noochie'/assistent). Eerste gebruiker: HarryHemp._on_keyword_decided.
# De titel van de checklist die de daemon als uitvoerplan herkent (prep schrijft 'm, _execute_checklist
# draait 'm). Eén authoritatieve bron: Inhabitant._PREP_CHECKLIST_TITLE en de cockpit-match verwijzen
# hiernaar (reference, don't copy) i.p.v. de literal "Uitvoerplan" te herhalen.
PREP_CHECKLIST_TITLE = "Uitvoerplan"

_VALID_TRIGGERS = {"clock", "human", "noochie", "tension", "role"}
_TERMINAL       = {"done"}
# Optionele impact-labels: een hulpmiddel, geen verplichting. Leeg = ongelabeld en dwingt niets af (een
# ongelabeld project mag elke statuswissel maken). De guard weigert alleen een niet-lege ongeldige waarde.
_MISSIE_IMPACT   = {"versterkt", "neutraal", "verzwakt"}
_BUSINESS_IMPACT = {"hoog", "medium", "laag"}
# effort (optionele inschatting): vervangt op termijn de #effort-hashtag-conventie (bestaande hashtags
# worden in deze scope NIET gemigreerd). Leeg = geen inschatting.
_EFFORT          = {"1u", "1d", "2d", "1w"}


class ProjectLedger:

    def __init__(self, path: str):
        self.path = path
        self._projects: dict[str, dict] = {}
        self._mtime: float = 0.0
        self._load()

    def _load(self) -> None:
        self._projects = read_json(self.path, {})
        if os.path.exists(self.path):
            self._mtime = os.path.getmtime(self.path)

    def _maybe_reload(self) -> None:
        """Herlaad van schijf als het bestand door een extern proces is gewijzigd."""
        try:
            if os.path.exists(self.path) and os.path.getmtime(self.path) > self._mtime:
                self._load()
        except Exception:
            pass

    def _save(self) -> None:
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        atomic_write_json(self.path, self._projects)
        if os.path.exists(self.path):
            self._mtime = os.path.getmtime(self.path)   # in-memory mtime bij → geen spurious _maybe_reload

    def _touch(self, project: dict) -> None:
        project["updated_at"] = time.time()

    # ── schrijven ──────────────────────────────────────────────────────────────

    def create(self, owner: str, scope, trigger: str,
               hypothesis: str = "", business_case: dict | None = None,
               status: str = "queued", origin: str = "",
               dod_outcome: str = "", done_when: str = "", goes_to: str = "",
               links: list[str] | None = None, parent: str | None = None,
               person: str | None = None, agent: str | None = None,
               private: bool = False, description: str = "", label: str = "",
               missie_impact: str = "", business_impact: str = "", effort: str = "",
               keyword: str = "") -> str:
        if trigger not in _VALID_TRIGGERS:
            raise ValueError(f"ongeldig trigger: '{trigger}'")
        if status not in ("queued", "draft", "future"):
            raise ValueError(f"ongeldige start-status: '{status}'")
        if missie_impact and missie_impact not in _MISSIE_IMPACT:
            raise ValueError(f"ongeldige missie_impact: '{missie_impact}'")
        if business_impact and business_impact not in _BUSINESS_IMPACT:
            raise ValueError(f"ongeldige business_impact: '{business_impact}'")
        if effort and effort not in _EFFORT:
            raise ValueError(f"ongeldige effort: '{effort}'")
        pid = uuid.uuid4().hex[:12]
        now = time.time()
        # Cluster-lidmaatschap: een kind erft de cluster-root van zijn ouder (master-switch werkt
        # zo op de hele keten). Geen ouder → eigen cluster (root/standalone).
        par = self._projects.get(parent) if parent else None
        cluster = (par.get("cluster") or parent) if par else pid
        self._projects[pid] = {
            "id":         pid,
            "owner":      owner,            # rol- of cirkel-id (GlassFrog: project hoort bij een rol/cirkel)
            "person":     person,           # optioneel: de mens die het project trekt
            "agent":      agent,            # optioneel: AI-inwoner (persona-id) als trekker (beter dan GlassFrog)
            "private":    bool(private),    # 'alleen zichtbaar voor de cirkel' (GlassFrog-zichtbaarheid)
            "description": description or "",  # omschrijving (kaartdetail)
            "label":      label or "",      # kleurlabel (koppeling met organisatiedoel, later)
            "missie_impact":   missie_impact or "",    # optioneel: versterkt/neutraal/verzwakt (leeg = ongelabeld)
            "business_impact": business_impact or "",  # optioneel: hoog/medium/laag (leeg = ongelabeld)
            "effort":          effort or "",           # optioneel: 1u/1d/2d/1w (leeg = geen inschatting)
            "checklist":  [],               # [{id, text, done}] — één checklist per project
            "archived":   False,            # gearchiveerd = blijft bestaan, uit het actieve zicht
            "scope":      scope,
            "trigger":    trigger,
            "status":     status,
            "blocked_on": None,
            "created_at": now,
            "updated_at": now,
            "outcome":    None,              # geleverde eind-uitkomst (gevuld bij done)
            "hypothesis":    hypothesis or "",
            "business_case": business_case,
            "origin":     origin or "",      # "experiment" = stolt later tot accountability bij herhaling;
            #                                  "keyword_research" = autonoom door een rol aangemaakt
            "keyword":    keyword or "",      # gestructureerd + opvraagbaar bronwoord (dedup-sleutel bij keyword_research)
            "executions": 0,                 # hoe vaak een rol dit experiment heeft uitgevoerd
            "formalized": False,             # al voorgesteld als accountability? (dedup)
            "comments":   [],                # stuur-opmerkingen van de mens (de rol leest ze mee)
            "log":        [],                # gesprek: {who: 'mens'|'rol', text, at} — chat-weergave
            # DoD-contract: de rol weet hiermee wanneer hij klaar is (docs/ONTWERP_prikbord_kanban.md)
            "dod_outcome": dod_outcome or "",   # gewenste uitkomst in één zin
            "done_when":   done_when or "",     # checkbaar criterium (lege/nee-uitkomst telt ook)
            "goes_to":     goes_to or "",       # wie de uitkomst consumeert (rol/bord/mens)
            "links":       list(links or []),   # verwante projecten (de keten/het gesprek)
            "attachments": [],                  # verrijking-cards: links/bijlagen (Trello-stijl)
            "due":         None,                # deadline (ISO datum 'YYYY-MM-DD'), optioneel
            "parent":      parent,              # ouder-project (None = root/standalone)
            "cluster":     cluster,             # cluster-root id (master-switch werkt hierop)
            "waiting_on":  None,                # project/briefje waarop dit wacht (resume-trigger)
        }
        self._save()
        return pid

    def open_scopes(self) -> set:
        """Scopes van niet-afgeronde projecten (voor dedup van kans-voorstellen)."""
        return {str(p.get("scope")) for p in self._projects.values()
                if p.get("status") not in _TERMINAL}

    def start(self, pid: str) -> bool:
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["status"] = "running"
        p["blocked_on"] = None
        self._touch(p)
        self._save()
        return True

    def set_due(self, pid: str, due: str) -> bool:
        """Zet of wis de deadline (ISO 'YYYY-MM-DD'); lege string wist 'm."""
        p = self._projects.get(pid)
        if p is None:
            return False
        p["due"] = (due or "").strip() or None
        self._touch(p)
        self._save()
        return True

    def add_reaction(self, pid: str, entry_id: str, emoji: str) -> bool:
        """Voeg een emoji-reactie toe aan een feed-entry (per emoji een teller). Alleen entries met
        een id (nieuw schema) kunnen reacties dragen."""
        p = self._projects.get(pid)
        emoji = (emoji or "").strip()
        if p is None or not emoji or not entry_id:
            return False
        for entry in p.get("log", []):
            if entry.get("id") == entry_id:
                r = entry.setdefault("reactions", {})
                r[emoji] = int(r.get(emoji, 0)) + 1
                self._touch(p)
                self._save()
                return True
        return False

    def attach_add(self, pid: str, url: str = "", title: str = "", kind: str = "link") -> dict | None:
        """Voeg een verrijking-card toe (Trello-stijl bijlage). Nu: een link met optionele titel.
        Geeft de toegevoegde card terug."""
        p = self._projects.get(pid)
        url = (url or "").strip()
        if p is None or not url:
            return None
        card = {"id": uuid.uuid4().hex[:10], "kind": kind, "url": url[:500],
                "title": (title or "").strip()[:200], "at": time.time()}
        p.setdefault("attachments", []).append(card)
        self._touch(p)
        self._save()
        return card

    def attach_file(self, pid: str, name: str, stored: str, title: str = "") -> dict | None:
        """Registreer een geupload bestand (het bestand zelf is al weggeschreven door de handler).
        `stored` = pad relatief aan de data-map."""
        p = self._projects.get(pid)
        if p is None or not stored:
            return None
        card = {"id": uuid.uuid4().hex[:10], "kind": "file", "name": (name or "bestand")[:200],
                "stored": stored, "title": (title or "").strip()[:200], "at": time.time()}
        p.setdefault("attachments", []).append(card)
        self._touch(p)
        self._save()
        return card

    def attach_remove(self, pid: str, aid: str) -> bool:
        p = self._projects.get(pid)
        if p is None:
            return False
        lst = p.get("attachments", [])
        for c in list(lst):
            if c.get("id") == aid:
                lst.remove(c)
                self._touch(p)
                self._save()
                return True
        return False

    def reopen(self, pid: str) -> bool:
        """Heropen een afgerond project: haal 'done' eraf zodat het weer naar actief/wacht/toekomst
        kan. No-op als het project niet bestaat of niet afgerond is."""
        p = self._projects.get(pid)
        if p is None or p["status"] not in _TERMINAL:
            return False
        p["status"] = "running"
        p["outcome"] = None
        self._touch(p)
        self._save()
        return True

    def block(self, pid: str, on_role: str) -> bool:
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["status"] = "blocked"
        p["blocked_on"] = on_role
        self._touch(p)
        self._save()
        return True

    def unblock(self, pid: str) -> bool:
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["status"] = "running"
        p["blocked_on"] = None
        self._touch(p)
        self._save()
        return True

    def complete(self, pid: str, outcome: str | None = None) -> bool:
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["status"] = "done"
        p["outcome"] = outcome
        # blocked_on blijft bewust staan: een review-goedkeuring is 'done' MÉT blocked_on=="review".
        # De board-watch (village._poll_board) leest die marker om cross-proces project_completed te vuren.
        self._touch(p)
        self._save()
        return True

    def mark_awaiting_review(self, pid: str) -> bool:
        """Checklist volledig af → wacht-op-review: status=blocked, blocked_on='review', plus het
        PERSISTENTE `review_raised`-vlag (restart-bestendig; gewist bij elke checklist-mutatie). Dat vlag
        voorkomt dat een volgende puls herblokkeert nadat de review is afgewezen en de rol doorwerkt.
        GEEN outcome — die wordt pas bij Done-toekenning (mens sleept wacht→done) gezet."""
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["status"] = "blocked"
        p["blocked_on"] = "review"
        p["review_raised"] = True
        self._touch(p)
        self._save()
        return True

    # Named checklists (Trello-stijl, meervoudig): p["checklists"] = [{id,title,items:[{id,text,done}]}]
    def _checklists(self, p) -> list:
        return p.setdefault("checklists", [])

    def _checklist(self, p, clid):
        for cl in self._checklists(p):
            if cl.get("id") == clid:
                return cl
        return None

    def checklist_add(self, pid: str, title: str = "") -> dict | None:
        p = self._projects.get(pid)
        if p is None:
            return None
        cl = {"id": uuid.uuid4().hex[:8], "title": (title or "").strip()[:80] or "Checklist", "items": []}
        self._checklists(p).append(cl)
        p.pop("review_raised", None)                  # checklist-mutatie → review-vlag wissen (Q2)
        self._touch(p); self._save()
        return cl

    def checklist_remove(self, pid: str, clid: str) -> bool:
        p = self._projects.get(pid)
        if p is None:
            return False
        before = len(self._checklists(p))
        p["checklists"] = [cl for cl in self._checklists(p) if cl.get("id") != clid]
        if len(p["checklists"]) != before:
            p.pop("review_raised", None)              # checklist-mutatie → review-vlag wissen (Q2)
            self._touch(p); self._save()
            return True
        return False

    def check_add(self, pid: str, clid: str, text: str, *,
                  skill: str | None = None, query: str = "", reason: str = "",
                  payload: dict | None = None, payload_ok: bool = True) -> bool:
        p = self._projects.get(pid)
        text = (text or "").strip()
        cl = self._checklist(p, clid) if p else None
        if cl is None or not text:
            return False
        item = {"id": uuid.uuid4().hex[:8], "text": text[:200], "done": False}
        if skill:  item["skill"]  = skill            # uitvoer-primitief: welke skill dit item draait
        if isinstance(payload, dict) and payload:
            item["payload"] = payload                # de LLM-gevormde input, in de vorm van input_schema
        if query:  item["query"]  = query[:200]      # legacy back-compat (→ {term: query} bij uitvoer)
        if reason: item["reason"] = reason[:300]     # 'geen skill' of 'payload onvolledig' → waarom (blijft open)
        if not payload_ok:
            item["payload_ok"] = False               # payload mist een verplicht veld → niet uitvoerbaar
        cl.setdefault("items", []).append(item)
        p.pop("review_raised", None)                  # checklist-mutatie → review-vlag wissen (Q2)
        self._touch(p); self._save()
        return True

    def check_toggle(self, pid: str, clid: str, item_id: str) -> bool:
        p = self._projects.get(pid)
        cl = self._checklist(p, clid) if p else None
        if cl is None:
            return False
        for it in cl.get("items", []):
            if it["id"] == item_id:
                it["done"] = not it.get("done")
                p.pop("review_raised", None)          # checklist-mutatie → review-vlag wissen (Q2)
                self._touch(p); self._save()
                return True
        return False

    def check_remove(self, pid: str, clid: str, item_id: str) -> bool:
        p = self._projects.get(pid)
        cl = self._checklist(p, clid) if p else None
        if cl is None:
            return False
        n = len(cl.get("items", []))
        cl["items"] = [it for it in cl.get("items", []) if it["id"] != item_id]
        if len(cl["items"]) != n:
            p.pop("review_raised", None)              # checklist-mutatie → review-vlag wissen (Q2)
            self._touch(p); self._save()
            return True
        return False

    def set_item_offer(self, pid: str, clid: str, item_id: str, offer: dict) -> bool:
        """Hang een STIL skill-aanbod aan een item: een suggestie (skill+payload), NOG geen skill. Alleen
        als het item nog geen skill heeft. `offer` = {skill, payload, payload_ok}. Accepteren gebeurt via
        accept_item_offer; negeren = afwijzen (het aanbod blijft staan tot acceptatie)."""
        p = self._projects.get(pid)
        cl = self._checklist(p, clid) if p else None
        if cl is None or not (offer or {}).get("skill"):
            return False
        for it in cl.get("items", []):
            if it["id"] == item_id and not it.get("skill"):
                pl = offer.get("payload")
                it["offer"] = {"skill": offer["skill"],
                               "payload": pl if isinstance(pl, dict) else {},
                               "payload_ok": bool(offer.get("payload_ok", True))}
                self._touch(p); self._save()
                return True
        return False

    def accept_item_offer(self, pid: str, clid: str, item_id: str) -> bool:
        """Accepteer het aanbod: hang skill+payload aan het item via het bestaande checklist-model en
        verwijder het aanbod. payload_ok=False (onvolledige payload) markeert het item als niet-uitvoerbaar
        (de daemon slaat het dan over) — identiek aan het prep-pad."""
        p = self._projects.get(pid)
        cl = self._checklist(p, clid) if p else None
        if cl is None:
            return False
        for it in cl.get("items", []):
            if it["id"] == item_id and it.get("offer"):
                off = it.pop("offer")
                it["skill"] = off.get("skill")
                pl = off.get("payload")
                if isinstance(pl, dict) and pl:
                    it["payload"] = pl
                if off.get("payload_ok") is False:
                    it["payload_ok"] = False
                p.pop("review_raised", None)          # checklist-mutatie → review-vlag wissen (Q2)
                self._touch(p); self._save()
                return True
        return False

    def edit(self, pid: str, scope=None, owner: str | None = None,
             person: str | None = None, agent: str | None = None,
             private: bool | None = None, description: str | None = None,
             label: str | None = None, missie_impact: str | None = None,
             business_impact: str | None = None, effort: str | None = None,
             allow_done: bool = False) -> bool:
        """Bewerk de inhoud van een project (scope, owner, trekker mens/AI, zichtbaarheid).
        Status blijft ongemoeid; done-projecten zijn standaard vergrendeld. Met `allow_done=True`
        mag je inhoud (titel/omschrijving/...) van een afgerond project nog aanpassen. Lege strings
        voor person/agent wissen de trekker; None laat het veld ongemoeid. Geeft True bij succes."""
        p = self._projects.get(pid)
        if p is None or (p["status"] in _TERMINAL and not allow_done):
            return False
        if scope is not None and str(scope).strip():
            p["scope"] = scope
        if owner is not None and str(owner).strip():
            p["owner"] = owner
        if person is not None:
            p["person"] = person or None
        if agent is not None:
            p["agent"] = agent or None
        if private is not None:
            p["private"] = bool(private)
        if description is not None:
            p["description"] = description
        if label is not None:
            p["label"] = label
        if missie_impact is not None:      # '' = ongelabeld (wissen); validatie op de actie/create-grens
            p["missie_impact"] = missie_impact
        if business_impact is not None:
            p["business_impact"] = business_impact
        if effort is not None:
            p["effort"] = effort
        self._touch(p)
        self._save()
        return True

    def approve(self, pid: str) -> bool:
        """Keur een concept-project (draft) goed → het komt op het bord van de rol (queued).
        Alleen drafts. Zo zie je eerst de (AI-)formulering en geef je akkoord vóór het live gaat."""
        p = self._projects.get(pid)
        if p is None or p.get("status") != "draft":
            return False
        p["status"] = "queued"
        self._touch(p)
        self._save()
        return True

    def discard(self, pid: str) -> bool:
        """Gooi een concept-project (draft) weg dat je niet wilt. Alleen drafts; nooit een
        project dat al op het bord staat. Geeft True als verwijderd."""
        p = self._projects.get(pid)
        if p is None or p.get("status") != "draft":
            return False
        del self._projects[pid]
        self._save()
        return True

    def archive(self, pid: str) -> bool:
        """Archiveer een project: het blijft bestaan maar verdwijnt uit het actieve zicht."""
        p = self._projects.get(pid)
        if p is None:
            return False
        p["archived"] = True
        self._touch(p)
        self._save()
        return True

    def unarchive(self, pid: str) -> bool:
        p = self._projects.get(pid)
        if p is None:
            return False
        p["archived"] = False
        self._touch(p)
        self._save()
        return True

    def remove(self, pid: str) -> bool:
        """Verwijder een project definitief (GlassFrog: project deleten). Geeft True als verwijderd."""
        if pid in self._projects:
            del self._projects[pid]
            self._save()
            return True
        return False

    def drafts(self) -> list[dict]:
        """Concept-projecten die op jouw akkoord wachten (status draft)."""
        self._maybe_reload()
        return [p for p in self._projects.values() if p.get("status") == "draft"]

    def record_progress(self, pid: str, note: str) -> bool:
        """Leg autonome voortgang vast: een rol heeft (omkeerbaar, met eigen skills) aan dit
        project gewerkt. Zet status queued→running, bewaart de uitkomst en markeert 'worked'
        (idempotent: niet nog eens oppakken). Done-projecten blijven ongemoeid."""
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["progress"] = note
        p.setdefault("log", []).append({"who": "rol", "text": note, "at": time.time()})
        p["worked"] = True
        p["executions"] = int(p.get("executions", 0)) + 1   # telt mee voor 'stollen na 3x'
        if p["status"] == "queued":
            p["status"] = "running"
        self._touch(p)
        self._save()
        return True

    def mark_tended(self, pid: str, date_iso: str) -> bool:
        """Idempotentie-anker voor het uitvoer-primitief: leg vast dat de eigenaar-rol dit project op deze
        dag heeft uitgevoerd, zodat een tweede puls dezelfde dag het niet opnieuw oppakt (geen dubbele
        notes). Done-projecten blijven ongemoeid."""
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["last_tended"] = date_iso
        self._touch(p); self._save()
        return True

    def add_comment(self, pid: str, text: str) -> bool:
        """Plaats een stuur-opmerking op een project (de eigenaar-rol leest deze mee bij het werken).
        Bijv. 'richt je op technisch onderzoek naar een natuurlijke elastaan-vervanger'."""
        p = self._projects.get(pid)
        text = (text or "").strip()
        if p is None or not text:
            return False
        now = time.time()
        p.setdefault("comments", []).append({"text": text[:500], "at": now})
        p.setdefault("log", []).append({"who": "mens", "text": text[:500], "at": now})
        p["worked"] = False           # nieuwe sturing → de rol pakt het opnieuw op
        self._touch(p)
        self._save()
        return True

    def add_role_message(self, pid: str, text: str) -> str | None:
        """Voeg een DIRECT antwoord van de rol toe aan het gesprek (chat-reply op een opmerking).
        Anders dan record_progress telt dit NIET als een experiment-uitvoering en raakt het de
        'worked'-vlag niet — het is conversatie, geen puls-werk.

        Geeft het note-`id` terug (of None bij lege input) — het id-patroon van add_feed_entry, zodat
        een specifieke note adresseerbaar/linkbaar is (bijv. een deliverable-store die ernaar verwijst).
        Bestaande notes zonder id blijven geldig (geen migratie); lezers filteren op `who`/`text`, niet op id."""
        p = self._projects.get(pid)
        text = (text or "").strip()
        if p is None or not text:
            return None
        nid = uuid.uuid4().hex[:10]
        p.setdefault("log", []).append({"id": nid, "who": "rol", "text": text[:1500], "at": time.time()})
        p["progress"] = text
        self._touch(p)
        self._save()
        return nid

    # Gestructureerde feed-entry (Trello-stijl kaart-discussie). Anders dan de oude {who} draagt
    # een entry nu een echte auteur (mens/persoon/AI/rol) en een soort (update vs reactie), zodat
    # zowel mensen als AI's kunnen meepraten en rol-voortgang herkenbaar in dezelfde stroom landt.
    _FEED_KINDS = ("update", "comment", "system")   # "system" = neutrale audit-entry (geen worked/progress-neveneffect)
    _AUTHOR_TYPES = ("human", "person", "persona", "role")

    def add_feed_entry(self, pid: str, text: str, *, kind: str = "comment",
                       author_type: str = "human", author_id: str = "") -> dict | None:
        """Voeg een feed-item toe. `kind`: 'update' (voortgang door een rol/AI) of 'comment'
        (reactie/sturing). `author_type` ∈ human|person|persona|role. Geeft de entry terug."""
        p = self._projects.get(pid)
        text = (text or "").strip()
        if p is None or not text:
            return None
        if kind not in self._FEED_KINDS:
            kind = "comment"
        if author_type not in self._AUTHOR_TYPES:
            author_type = "human"
        entry = {
            "id": uuid.uuid4().hex[:10],
            "kind": kind,
            "author": {"type": author_type, "id": author_id or ""},
            "text": text[:1500],
            "at": time.time(),
        }
        p.setdefault("log", []).append(entry)
        # Een menselijke reactie is sturing: de rol pakt het opnieuw op (zoals add_comment).
        if kind == "comment" and author_type == "human":
            p["worked"] = False
        elif kind == "update":
            p["progress"] = text[:1500]
        self._touch(p)
        self._save()
        return entry

    def feed_edit(self, pid: str, entry_id: str, text: str) -> bool:
        """Wijzig de tekst van een feed-entry (eigen comment). Lege tekst doet niets."""
        p = self._projects.get(pid)
        text = (text or "").strip()
        if p is None or not text:
            return False
        for e in p.get("log", []):
            if e.get("id") == entry_id:
                e["text"] = text[:1500]
                self._touch(p); self._save()
                return True
        return False

    def feed_remove(self, pid: str, entry_id: str) -> bool:
        p = self._projects.get(pid)
        if p is None:
            return False
        n = len(p.get("log", []))
        p["log"] = [e for e in p.get("log", []) if e.get("id") != entry_id]
        if len(p["log"]) != n:
            self._touch(p); self._save()
            return True
        return False

    def wait_for(self, pid: str, need: str, on_id: str = "") -> bool:
        """Zet een project op WACHTEN met een gestructureerde behoefte: WAT is nodig (need) en
        WAAROP het wacht (on_id = een ander project of een prikbord-briefje). De scheduler hervat
        het zodra `on_id` klaar is. Done-projecten blijven ongemoeid."""
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["status"] = "blocked"
        p["blocked_on"] = need or "wacht"
        p["waiting_on"] = on_id or None
        self._touch(p)
        self._save()
        return True

    def link(self, a: str, b: str) -> bool:
        """Verbind twee projecten tot een keten/gesprek (wederzijds, zoals de notes-graaf). Geen
        zelf-link, dedup. Geeft True als er iets is bijgekomen."""
        if a == b:
            return False
        pa, pb = self._projects.get(a), self._projects.get(b)
        if pa is None or pb is None:
            return False
        changed = False
        for x, y in ((pa, b), (pb, a)):
            x.setdefault("links", [])
            if y not in x["links"]:
                x["links"].append(y); changed = True
        if changed:
            self._save()
        return changed

    def neighbors(self, pid: str) -> list[dict]:
        """De direct gelinkte projecten (beide richtingen), oudste eerst."""
        p = self._projects.get(pid)
        if p is None:
            return []
        ids = set(p.get("links", []))
        for q in self._projects.values():
            if pid in q.get("links", []):
                ids.add(q["id"])
        ids.discard(pid)
        return sorted((self._projects[i] for i in ids if i in self._projects),
                      key=lambda q: q.get("created_at", 0))

    def mark_formalized(self, pid: str) -> bool:
        """Markeer een experiment als 'voorgesteld om te stollen' (accountability op de agenda).
        Voorkomt dat hetzelfde experiment tweemaal wordt voorgedragen."""
        p = self._projects.get(pid)
        if p is None:
            return False
        p["formalized"] = True
        self._touch(p)
        self._save()
        return True

    def to_future(self, pid: str) -> bool:
        """Park een project als 'future' (later oppakken als er ruimte is). Niet-terminaal:
        het kan later weer naar running/blocked. Done-projecten blijven done."""
        p = self._projects.get(pid)
        if p is None or p["status"] in _TERMINAL:
            return False
        p["status"] = "future"
        p["blocked_on"] = None
        self._touch(p)
        self._save()
        return True

    # ── lezen ──────────────────────────────────────────────────────────────────

    def get(self, pid: str) -> dict | None:
        self._maybe_reload()
        return self._projects.get(pid)

    def all(self) -> list[dict]:
        self._maybe_reload()
        return list(self._projects.values())

    def by_status(self, status: str) -> list[dict]:
        self._maybe_reload()
        return [p for p in self._projects.values() if p["status"] == status]

    def open(self) -> list[dict]:
        self._maybe_reload()
        return [p for p in self._projects.values() if p["status"] not in _TERMINAL]


# ── Concurrency-poort: ALLE schrijfpaden lopen door _synchronized (slot + verse read onder het slot).
# Eén auditbare lijst (1-op-1 met de methodes die self._save() aanroepen). Een NIEUW schrijfpad MOET hier
# bij — de guard-test tests/test_projectledger_concurrency.py::test_alle_schrijfpaden_gesynchroniseerd
# faalt zodra een methode die _save aanroept niet in deze lijst staat. Reads staan er bewust NIET in.
_WRITE_METHODS = (
    "create", "start", "set_due", "add_reaction", "attach_add", "attach_file", "attach_remove",
    "reopen", "block", "unblock", "complete", "mark_awaiting_review", "checklist_add", "checklist_remove", "check_add",
    "check_toggle", "check_remove", "set_item_offer", "accept_item_offer", "edit", "approve",
    "discard", "archive", "unarchive", "remove", "record_progress", "mark_tended", "add_comment",
    "add_role_message", "add_feed_entry", "feed_edit", "feed_remove", "wait_for", "link",
    "mark_formalized", "to_future",
)
for _m in _WRITE_METHODS:
    setattr(ProjectLedger, _m, _synchronized(getattr(ProjectLedger, _m)))
