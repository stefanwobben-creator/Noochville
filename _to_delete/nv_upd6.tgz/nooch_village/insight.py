from __future__ import annotations
from datetime import datetime
from enum import StrEnum
from typing import Self
from pydantic import BaseModel, Field, model_validator


class GroundingStatus(StrEnum):
    UNRESOLVED = "unresolved"
    SUPPORTED = "supported"
    VERIFIED = "verified"


class EvidenceType(StrEnum):
    CLAIMED = "claimed"
    REPORTED = "reported"
    MEASURED = "measured"
    CERTIFIED = "certified"
    PEER_REVIEWED = "peer_reviewed"


class ClaimKind(StrEnum):
    """De SOORT van een kaartje (verandert nooit; alleen de sterkte evolueert).
    Zie docs/ONDERZOEK_kennismodel.md.
      - SIGNAAL   : trend/mening/nieuws; gaat over aandacht/cultuur. Roept een vraag op.
      - BEVINDING : empirie; gaat over de wereld. Beantwoordt een vraag.
      - KADER     : norm/regel; bindend (draagt zijn eigen bewijsdrempel).
      - STANDPUNT : wat Nooch zelf beweert/wil claimen; beweerd, niet bewezen (erft sterkte).
    None = (nog) onbeslist → mens-review (definities horen niet hier maar in het Lexicon)."""
    SIGNAAL = "signaal"
    BEVINDING = "bevinding"
    KADER = "kader"
    STANDPUNT = "standpunt"


def _filled(value: str | None) -> bool:
    return value is not None and value.strip() != ""


class Insight(BaseModel):
    id: str
    claim: str
    source: str
    word: str | None = None
    source_date: str | None = None
    created_at: datetime = Field(default_factory=datetime.now)
    grounding_count: int = 1
    last_updated_at: datetime | None = None
    links_to: list[str] = Field(default_factory=list)
    # Getypeerde bewijs-relaties (kennislaag): welke claims dit kaartje STEUNT of TEGENSPREEKT.
    # Een bevinding die een standpunt steunt zet het standpunt-id in `supports`. Sterkte wordt
    # hieruit berekend (knowledge.py), niet opgeslagen — zo kan hij niet verouderen.
    supports: list[str] = Field(default_factory=list)
    contradicts: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    status: GroundingStatus = GroundingStatus.UNRESOLVED
    kind: ClaimKind | None = None      # soort (signaal/bevinding/kader/standpunt); None = onbeslist
    grounds: str | None = None
    warrant: str | None = None
    qualifier: str | None = None
    rebuttal: str | None = None
    evidence_type: EvidenceType | None = None
    reference: str | None = None
    concept_id: str | None = None

    @model_validator(mode="after")
    def _check_grounding(self) -> Self:
        if self.status == GroundingStatus.SUPPORTED:
            if not _filled(self.grounds):
                raise ValueError("SUPPORTED vereist een gevuld 'grounds'-veld")
        elif self.status == GroundingStatus.VERIFIED:
            missing = [
                name for name, val in [
                    ("grounds", self.grounds),
                    ("warrant", self.warrant),
                    ("rebuttal", self.rebuttal),
                ]
                if not _filled(val)
            ]
            if missing:
                raise ValueError(
                    f"VERIFIED vereist gevulde velden: {', '.join(missing)}"
                )
            if self.evidence_type is None:
                raise ValueError("VERIFIED vereist een gezet evidence_type")
            if self.evidence_type == EvidenceType.CLAIMED:
                raise ValueError(
                    "VERIFIED staat EvidenceType.CLAIMED niet toe: "
                    "een eigen claim kan nooit verified worden"
                )
        return self
